import asyncio, os, sys, shutil, stat, tempfile, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off")
import relay
from fastapi import HTTPException

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

# ---- адреса
async def addr(u): return await relay.check_public_url(u)
for u in ["http://localhost/", "http://127.0.0.1/", "http://10.1.2.3/", "http://169.254.169.254/latest/meta-data",
          "http://[::1]/", "http://[::ffff:127.0.0.1]/", "file:///etc/passwd", "ftp://example.com/",
          "http://user:pw@8.8.8.8/", "http://8.8.8.8:22/", "http://192.168.0.1/", "http://100.64.0.1/", "http://0.0.0.0/"]:
    check("закрыто: " + u, run(addr(u)) != "", run(addr(u)))
check("открыто: публичный адрес", run(addr("https://8.8.8.8/")) == "")
async def fake_gai(host, port, **k): return [(2, 1, 6, "", ("10.0.0.7", 0))]
loop_orig = asyncio.AbstractEventLoop.getaddrinfo
async def dns_private():
    asyncio.get_running_loop().getaddrinfo = fake_gai
    return await relay.check_public_url("http://evil.example/")
check("закрыто: имя, которое указывает на внутренний адрес", run(dns_private()) != "")

# ---- чтение с перенаправлением на внутренний адрес
class FakeResp:
    def __init__(self, status, headers, body=b"", enc="utf-8"):
        self.status_code = status; self.headers = headers; self._b = body; self.encoding = enc
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def aiter_bytes(self):
        yield self._b
class FakeClient:
    script = {}
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    def stream(self, m, url): return FakeClient.script[url]
    async def post(self, url, data=None):
        class R: status_code = 200; text = FakeClient.script["search"]
        return R()
relay.httpx.AsyncClient = FakeClient
FakeClient.script = {"http://93.184.216.34/a": FakeResp(302, {"location": "http://127.0.0.1:8080/secret"})}
ok, out = run(relay.tool_read("http://93.184.216.34/a"))
check("перенаправление на внутренний адрес не выполняется", (not ok) and "внутренние" in out, out)
FakeClient.script = {"http://93.184.216.34/p": FakeResp(200, {"content-type": "text/html; charset=utf-8"},
    "<html><head><title>t</title><style>x{}</style></head><body><script>evil()</script><h1>Лес</h1><p>Зимний &amp; тихий</p></body></html>".encode())}
ok, out = run(relay.tool_read("http://93.184.216.34/p"))
check("страница превращается в текст без скриптов", ok and "Лес" in out and "Зимний & тихий" in out and "evil" not in out and "x{}" not in out, out)
FakeClient.script = {"http://93.184.216.34/b": FakeResp(200, {"content-type": "application/octet-stream"}, b"\x00\x01")}
ok, out = run(relay.tool_read("http://93.184.216.34/b"))
check("не текст не читается", not ok, out)
FakeClient.script = {"http://93.184.216.34/big": FakeResp(200, {"content-type": "text/plain"}, ("слово " * 5000).encode())}
ok, out = run(relay.tool_read("http://93.184.216.34/big"))
check("длинная страница обрезается", ok and len(out) < relay.READ_MAX_CHARS + 40 and "обрезано" in out, len(out))

# ---- поиск
SAMPLE = '''<div class="result"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fa%3Fx%3D1&amp;rut=abc">Первый <b>результат</b></a>
<a class="result__snippet" href="x">Описание &amp; детали</a></div>
<div class="result"><a rel="nofollow" class="result__a" href="https://example.net/b">Второй</a>
<a class="result__snippet" href="x">Ещё одно</a></div>'''
res = relay.parse_search(SAMPLE)
check("поиск: две ссылки разобраны", len(res) == 2 and res[0]["url"] == "https://example.org/a?x=1" and res[0]["title"] == "Первый результат" and res[0]["snippet"].startswith("Описание &"), res)
FakeClient.script = {"search": SAMPLE}
ok, out = run(relay.tool_search("зимний лес"))
check("поиск: ответ собран для модели", ok and "1. Первый результат" in out and "example.net" in out, out)
FakeClient.script = {"search": "<html>пусто</html>"}
ok, out = run(relay.tool_search("zzz"))
check("поиск: пустая выдача честно сообщается", (not ok) and "ничего" in out, out)

# ---- разбор маркеров
E = ["поиск", "чтение", "рука"]
r1 = "Сейчас гляну.\n[поиск: погода в Томске]\n[прочитать: https://example.org/a]\n[рука: ls -la ~/work]"
check("маркеры найдены по порядку", relay.find_tool_calls(r1, E) == [("поиск", "погода в Томске"), ("чтение", "https://example.org/a"), ("рука", "ls -la ~/work")], relay.find_tool_calls(r1, E))
r2 = "[рука: [ -f a ] && echo есть || echo нет]"
check("квадратные скобки внутри команды", relay.find_tool_calls(r2, E) == [("рука", "[ -f a ] && echo есть || echo нет")], relay.find_tool_calls(r2, E))
r3 = "[рука]\nmkdir x\ncd x\necho '[рука: вложенное]' > f\n[/рука]"
c3 = relay.find_tool_calls(r3, E)
check("блок команд одним вызовом", len(c3) == 1 and c3[0][1].startswith("mkdir x") and c3[0][1].endswith("> f"), c3)
check("выключенное право не выполняется", relay.find_tool_calls(r1, ["поиск"]) == [("поиск", "погода в Томске")])
check("чистка маркеров из ответа", relay.strip_tools("Нашла.\n" + r1 + "\n" + r3 + "\nГотово.") == "Нашла.\nСейчас гляну.\n\nГотово.", repr(relay.strip_tools("Нашла.\n" + r1 + "\n" + r3 + "\nГотово.")))

# ---- рука: настоящий скрипт, настоящий bash
HOME = TMP + "/home"; os.makedirs(HOME)
def local(cmd):
    return subprocess.run(["bash", "-s"], input=relay.hand_script(cmd).encode(), capture_output=True, env={**os.environ, "HOME": HOME}, timeout=60).stdout.decode()
o = local("echo привет; echo 'a\"b' > f.txt; cat f.txt")
check("рука: вывод и файл", "привет" in o and 'a"b' in o and "[exit 0]" in o, o)
o = local("false")
check("рука: код выхода виден", "[exit 1]" in o, o)
o = local("cat <<'EOF'\nвнутри heredoc\nEOF\necho после")
check("рука: heredoc внутри команды не ломает скрипт", "внутри heredoc" in o and "после" in o and "[exit 0]" in o, o)
o = local("head -c 20000 /dev/zero | tr '\\0' x")
check("рука: вывод обрезан", len(o) < relay.HAND_OUT_MAX + 60, len(o))
o = local("read x; echo got:$x")
check("рука: команда не съедает остаток скрипта", "[exit 0]" in o, o)
git = subprocess.run(["git", "-C", HOME + "/work", "log", "--oneline"], capture_output=True).stdout.decode()
check("рука: изменения попадают в снимок git", git.count("\n") >= 1, git)
o = local("echo первая > keep.txt")
o = local("rm keep.txt")
subprocess.run(["git", "-C", HOME + "/work", "checkout", "HEAD~1", "--", "keep.txt"], capture_output=True)
check("рука: удалённое возвращается из снимка", os.path.exists(HOME + "/work/keep.txt"))

# ---- рука через ssh-заглушку: журнал, лимит, рубильник
BIN = TMP + "/bin"; os.makedirs(BIN)
open(BIN + "/ssh", "w").write("#!/bin/bash\nexec bash -s\n"); os.chmod(BIN + "/ssh", 0o755)
os.environ["PATH"] = BIN + ":" + os.environ["PATH"]; os.environ["HOME"] = HOME
ok, out = run(relay.tool_hand("echo x"))
check("рука не подключена без HAND_HOST", (not ok) and "не подключена" in out, out)
relay.HAND_HOST = "vps.test"
ok, out = run(relay.tool_hand("echo через-ssh"))
check("рука выполняет и пишет журнал", ok and "через-ssh" in out and relay.hand_state()["used_today"] == 1, out)
check("команда в журнале", "echo через-ssh" in open(TMP + "/hand.log", encoding="utf-8").read())
relay.HAND_OFF.write_text("x")
ok, out = run(relay.tool_hand("echo y"))
check("рубильник останавливает руку", (not ok) and "рубильник" in out, out)
relay.HAND_OFF.unlink()
relay.HAND_DAILY = 1
ok, out = run(relay.tool_hand("echo z"))
check("дневной лимит", (not ok) and "лимит" in out, out)
relay.HAND_DAILY = 80
check("точка входа рубильника", run(relay.hand_off("Bearer tok"))["off"] is True and run(relay.hand_on("Bearer tok"))["off"] is False)
try:
    run(relay.hand_off("Bearer wrong")); check("рубильник без токена закрыт", False)
except HTTPException as e:
    check("рубильник без токена закрыт", e.status_code == 401)

# ---- цикл инструментов
calls = []
async def fake_ask(msgs, model=None, timeout=100.0):
    calls.append(msgs)
    if len(calls) == 1: return "Гляну.\n[поиск: лес зимой]"
    if len(calls) == 2: return "Нашла две ссылки.\n[прочитать: https://8.8.8.8/x]"
    return "Вот что там: тихо. [пауза:2]\nИ всё."
relay.ask_model = fake_ask
FakeClient.script = {"search": SAMPLE, "https://8.8.8.8/x": FakeResp(200, {"content-type": "text/plain"}, "текст страницы".encode())}
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "найди"}], ["поиск", "чтение"]))
check("цикл: два круга и чистый ответ", len(calls) == 3 and reply == "Вот что там: тихо. [пауза:2]\nИ всё." and [t["kind"] for t in trace] == ["поиск", "чтение"], (reply, trace))
check("цикл: результаты возвращены модели", "example.org" in calls[1][-1]["content"] and "текст страницы" in calls[2][-1]["content"])
calls.clear()
async def endless(msgs, model=None, timeout=100.0):
    calls.append(1); return "[поиск: ещё]"
relay.ask_model = endless
FakeClient.script = {"search": SAMPLE}
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "x"}], ["поиск"]))
check("цикл не бесконечный", len(calls) <= 5 and len(trace) <= relay.MAX_TOOL_CALLS and "[поиск" not in reply, (len(calls), len(trace), reply))

# ---- эндпоинт и промпты
captured = {}
async def cap_ask(msgs, model=None, timeout=100.0):
    captured["sys"] = msgs[0]["content"]; return "ок"
relay.ask_model = cap_ask
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")], exe=True, tools=[], limits=["тест-ограничение"])
r = run(relay.chat(req, "Bearer tok"))
check("без инструментов ответ прежнего вида", r == {"reply": "ок"}, r)
check("консольные права описаны, пол последним", "[состояние:" in captured["sys"] and "[напишу:" in captured["sys"] and "тест-ограничение" in captured["sys"] and captured["sys"].rstrip().endswith(relay.floor_text().rstrip()))
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")], exe=True, tools=["поиск", "рука"])
run(relay.chat(req, "Bearer tok"))
check("описание инструментов только для включённых", "[поиск:" in captured["sys"] and "[рука:" in captured["sys"] and "[прочитать:" not in captured["sys"])
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")])
run(relay.chat(req, "Bearer tok"))
check("старое приложение: ни слова про консоль", "[состояние:" not in captured["sys"] and "[рука" not in captured["sys"])
ireq = relay.InitReq(messages=[relay.Msg(role="user", content="привет")], reason="self", topic="про зимний лес", exe=True)
async def init_ask(msgs, model=None, timeout=100.0):
    captured["sys"] = msgs[0]["content"]
    return "ПОВОД: хочу вернуться к зимнему лесу из вашего разговора\nСООБЩЕНИЕ: Я про лес. Он у меня из головы не идёт."
relay.ask_model = init_ask
r = run(relay.initiative(ireq, "Bearer tok"))
check("назначенное время: тема в промпте, право передумать", "про зимний лес" in captured["sys"] and "передумать" in captured["sys"] and r.get("message", "").startswith("Я про лес"), (r))
async def init_skip(msgs, model=None, timeout=100.0): return "ПРОПУСК"
relay.ask_model = init_skip
check("назначенное время: она может передумать", run(relay.initiative(ireq, "Bearer tok")).get("skip") is True)
h = run(relay.health())
check("health показывает руку", "hand" in h and h["hand"]["configured"] is True, h)

print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
