package ru.avrora.exe

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
private val dayFormat = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

@Composable
fun Avatar(size: Dp) {
    AsyncImage(
        model = "file:///android_asset/avatar.webp",
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(3.dp))
            .border(1.dp, Glow.copy(alpha = 0.55f), RoundedCornerShape(3.dp))
    )
}

@Composable
private fun Cursor(color: androidx.compose.ui.graphics.Color = Glow) {
    val transition = rememberInfiniteTransition(label = "cursor")
    val a by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(520), repeatMode = RepeatMode.Reverse),
        label = "cursorAlpha"
    )
    Text("█", color = color.copy(alpha = a), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
}

@Composable
fun EmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 40.dp, start = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Avatar(64.dp)
        Spacer(Modifier.height(10.dp))
        Text("AVRORA.EXE", color = Glow, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("система запущена", color = TextDim, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        Text("ядро памяти: подключено", color = TextDim, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ждёт ввода ", color = TextDim, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            Cursor()
        }
    }
}

@Composable
fun TypingRow() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 2.dp)) {
        Text("аврора ▸ ", color = Glow, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text("обрабатывает ", color = TextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Cursor()
    }
}

/** Строка, которую пишет система, а не Аврора и не Адонис: состояние, назначение, след. */
@Composable
private fun SystemLine(text: String) {
    Text(
        "· $text",
        color = TextDim,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontFamily = FontFamily.Monospace
    )
}

/** Один вызов инструмента: что она запросила и что вернулось. Нажатие раскрывает вывод целиком. */
@Composable
private fun TraceBlock(t: ToolTrace) {
    var open by remember(t) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row {
            Text("$ ", color = Amber, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            SelectionContainer {
                Text(
                    "${t.kind}: ${t.arg}",
                    color = Amber,
                    fontSize = 13.sp,
                    lineHeight = 17.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = if (open) Int.MAX_VALUE else 4
                )
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(2.dp))
                .background(Terminal)
                .border(1.dp, if (t.ok) Edge else ErrorRed, RoundedCornerShape(2.dp))
                .clickable { open = !open }
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                (if (t.ok) "" else "не вышло: ") + t.out.trim().ifEmpty { "(пусто)" },
                color = if (t.ok) TextDim else ErrorRed,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = if (open) Int.MAX_VALUE else 6
            )
        }
    }
}

@Composable
fun MessageRow(
    m: ChatMessage,
    showAvatar: Boolean,
    stickers: List<CatalogItem>,
    photos: List<CatalogItem>,
    sentDir: File,
    revealing: Boolean,
    onOpen: (Any) -> Unit
) {
    val mine = m.role == "user"
    val parts = remember(m.content) { parseParts(m.content) }
    val traces = remember(m.trace) { traceFromJson(m.trace) }
    // Её паузы: части идут по очереди, только пока сообщение свежее. Где пауза и на сколько, решила она
    val steps = remember(parts) { splitSteps(parts) }
    var visible by remember(m.time) { mutableIntStateOf(if (revealing) 1 else steps.size) }
    LaunchedEffect(m.time, revealing) {
        if (revealing) {
            while (visible < steps.size) {
                delay(steps[visible].first)
                visible += 1
            }
        } else {
            visible = steps.size
        }
    }
    val shown = steps.take(visible).flatMap { it.second }
    val accent = if (mine) Amber else Glow

    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (mine) "адонис ▸" else "аврора ▸",
                color = accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.width(8.dp))
            Text(
                (if (m.auto) "сама · " else "") + dayOrTime(m.time),
                color = TextDim,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(top = 3.dp)) {
            Box(Modifier.width(2.dp).fillMaxHeight().background(accent.copy(alpha = 0.45f)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!mine) traces.forEach { TraceBlock(it) }
                shown.forEach { p ->
                    when (p) {
                        is Part.Text -> SelectionContainer {
                            Text(
                                p.s,
                                color = TextMain,
                                fontSize = 15.sp,
                                lineHeight = 21.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        is Part.Pause -> {}
                        is Part.Silence -> Text(
                            "прочитано, ответа нет",
                            color = TextDim,
                            fontSize = 13.sp,
                            fontStyle = FontStyle.Italic,
                            fontFamily = FontFamily.Monospace
                        )
                        is Part.State -> SystemLine(
                            "состояние → ${p.name}" + if (p.why.isNotBlank()) " — ${p.why}" else ""
                        )
                        is Part.Plan -> SystemLine("назначено: ${p.whenText} — ${p.topic}")
                        is Part.Note -> SystemLine("след [${p.kind}]: ${p.text}")
                        is Part.Sticker -> {
                            val item = stickers.firstOrNull { s -> s.id == p.id }
                            if (item != null) {
                                AsyncImage(
                                    model = item.model,
                                    contentDescription = null,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .height(150.dp)
                                        .aspectRatio(item.aspect.coerceIn(0.3f, 3f))
                                )
                            }
                        }
                        is Part.Photo -> {
                            val item = photos.firstOrNull { s -> s.id == p.id }
                            if (item != null) PhotoImage(item.model, item.aspect, onOpen)
                        }
                        is Part.Snap -> {
                            val file = File(sentDir, p.file)
                            val aspect = remember(file) { imageAspect(file) }
                            PhotoImage(file, aspect, onOpen)
                        }
                    }
                }
            }
        }
    }
}

private fun dayOrTime(t: Long): String {
    val now = System.currentTimeMillis()
    return if (now - t < 20 * 3_600_000L) timeFormat.format(Date(t)) else dayFormat.format(Date(t))
}

/** Делит части сообщения по её паузам: (задержка перед группой в мс, части группы). */
private fun splitSteps(parts: List<Part>): List<Pair<Long, List<Part>>> {
    val steps = ArrayList<Pair<Long, List<Part>>>()
    var cur = ArrayList<Part>()
    var delayMs = 0L
    for (p in parts) {
        if (p is Part.Pause) {
            if (cur.isNotEmpty()) {
                steps.add(Pair(delayMs, cur))
                cur = ArrayList()
            }
            delayMs = p.seconds * 1000L
        } else {
            cur.add(p)
        }
    }
    if (cur.isNotEmpty()) steps.add(Pair(delayMs, cur))
    return steps
}

@Composable
private fun PhotoImage(model: Any, aspect: Float, onOpen: (Any) -> Unit) {
    AsyncImage(
        model = model,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .width(240.dp)
            .aspectRatio(aspect.coerceIn(0.5f, 2f))
            .clip(RoundedCornerShape(3.dp))
            .border(1.dp, Edge, RoundedCornerShape(3.dp))
            .clickable { onOpen(model) }
    )
}
