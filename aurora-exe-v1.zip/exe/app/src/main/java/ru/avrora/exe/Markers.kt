package ru.avrora.exe

/** Теги во вложениях Адониса: [стикер:id], [фото:id], [снимок:файл]. */
val TAG_RE = Regex("""\[(стикер|фото|снимок|sticker|photo)\s*:\s*([A-Za-z0-9_.\-]+)\s*\]""")

/** Её маркеры молчания и пауз. */
val PAUSE_RE = Regex("""\[пауза(?:\s*:\s*(\d{1,2}))?\s*\]""", RegexOption.IGNORE_CASE)
val SILENCE_RE = Regex("""\[молчу\s*\]""", RegexOption.IGNORE_CASE)

/**
 * Все маркеры в тексте. Группы: 1-2 вложение (вид, id), 3 секунды паузы,
 * 4-5 состояние (слово, причина), 6-7 «напишу» (когда, тема), 8-9 след (вид, текст).
 */
private val ALL_RE = Regex(
    """\[(?:(стикер|фото|снимок|sticker|photo)\s*:\s*([A-Za-z0-9_.\-]+)""" +
        """|пауза(?:\s*:\s*(\d{1,2}))?""" +
        """|состояние\s*:\s*([^\]|]{1,60})(?:\|\s*причина\s*:\s*([^\]]{1,300}))?""" +
        """|напишу\s*:\s*([^\]|]{1,40})\|\s*([^\]]{1,200})""" +
        """|след\s*:\s*([^\]|]{1,20})\|\s*([^\]]{1,300}))\s*\]""",
    RegexOption.IGNORE_CASE
)

sealed class Part {
    data class Text(val s: String) : Part()
    data class Sticker(val id: String) : Part()
    data class Photo(val id: String) : Part()
    data class Snap(val file: String) : Part()
    data class Pause(val seconds: Int) : Part()
    data class State(val name: String, val why: String) : Part()
    data class Plan(val whenText: String, val topic: String) : Part()
    data class Note(val kind: String, val text: String) : Part()
    object Silence : Part()
}

fun parseParts(content: String): List<Part> {
    // Если она ответила [молчу], остального текста не показываем: это решение промолчать
    if (SILENCE_RE.containsMatchIn(content)) return listOf(Part.Silence)
    val out = ArrayList<Part>()
    var last = 0
    for (m in ALL_RE.findAll(content)) {
        val before = content.substring(last, m.range.first).trim()
        if (before.isNotEmpty()) out.add(Part.Text(before))
        val g = m.groupValues
        when {
            g[1].isNotEmpty() -> {
                val kind = g[1].lowercase()
                when (kind) {
                    "стикер", "sticker" -> out.add(Part.Sticker(g[2]))
                    "фото", "photo" -> out.add(Part.Photo(g[2]))
                    else -> out.add(Part.Snap(g[2]))
                }
            }
            g[4].isNotEmpty() -> out.add(Part.State(g[4].trim(), g[5].trim()))
            g[6].isNotEmpty() -> out.add(Part.Plan(g[6].trim(), g[7].trim()))
            g[8].isNotEmpty() -> out.add(Part.Note(g[8].trim().lowercase(), g[9].trim()))
            else -> out.add(Part.Pause((g[3].toIntOrNull() ?: 2).coerceIn(1, 8)))
        }
        last = m.range.last + 1
    }
    val tail = content.substring(last).trim()
    if (tail.isNotEmpty()) out.add(Part.Text(tail))
    return out
}
