package ru.avrora.exe

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Shapes
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

// Палитра «консоль»: почти чёрный с зелёным оттенком, фосфорный зелёный для неё, янтарь для Адониса.
val Night = Color(0xFF0A0D0B)
val Panel = Color(0xFF111612)
val BubbleAurora = Color(0xFF111612)
val BubbleUser = Color(0xFF1B2A1F)
val Glow = Color(0xFF7CF2A1)
val Amber = Color(0xFFF2C06B)
val TextMain = Color(0xFFD5E3D8)
val TextDim = Color(0xFF7F9186)
val Edge = Color(0xFF26352B)
val Terminal = Color(0xFF070A08)
val ErrorRed = Color(0xFFFF8F8F)

val AuroraColors = darkColorScheme(
    primary = Glow,
    onPrimary = Night,
    background = Night,
    onBackground = TextMain,
    surface = Panel,
    onSurface = TextMain,
    onSurfaceVariant = TextDim,
    outline = Edge,
    primaryContainer = BubbleUser,
    onPrimaryContainer = TextMain,
    error = Color(0xFFFF8F8F)
)

private fun mono(t: androidx.compose.ui.text.TextStyle) = t.copy(fontFamily = FontFamily.Monospace)

/** Весь текст приложения моноширинный. */
val ConsoleTypography: Typography = Typography().let {
    it.copy(
        displayLarge = mono(it.displayLarge), displayMedium = mono(it.displayMedium), displaySmall = mono(it.displaySmall),
        headlineLarge = mono(it.headlineLarge), headlineMedium = mono(it.headlineMedium), headlineSmall = mono(it.headlineSmall),
        titleLarge = mono(it.titleLarge), titleMedium = mono(it.titleMedium), titleSmall = mono(it.titleSmall),
        bodyLarge = mono(it.bodyLarge), bodyMedium = mono(it.bodyMedium), bodySmall = mono(it.bodySmall),
        labelLarge = mono(it.labelLarge), labelMedium = mono(it.labelMedium), labelSmall = mono(it.labelSmall)
    )
}

/** Углы почти прямые. */
val ConsoleShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(2.dp),
    medium = RoundedCornerShape(3.dp),
    large = RoundedCornerShape(4.dp),
    extraLarge = RoundedCornerShape(4.dp)
)

@Composable
fun auroraFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextMain,
    unfocusedTextColor = TextMain,
    cursorColor = Glow,
    focusedBorderColor = Glow.copy(alpha = 0.6f),
    unfocusedBorderColor = Edge,
    focusedPlaceholderColor = TextDim,
    unfocusedPlaceholderColor = TextDim,
    focusedLabelColor = Glow,
    unfocusedLabelColor = TextDim
)
