package ru.avrora.exe
import java.util.*

var ok = 0; var bad = 0
fun check(name: String, c: Boolean, info: String = "") { if (c) { ok++; println("[ОК]   $name") } else { bad++; println("[НЕТ]  $name $info") } }

fun main() {
    val tz = TimeZone.getTimeZone("Europe/Moscow")
    fun at(h: Int, m: Int, day: Int = 19): Long { val c = Calendar.getInstance(tz); c.set(2026, Calendar.OCTOBER, day, h, m, 0); c.set(Calendar.MILLISECOND, 0); return c.timeInMillis }
    val now = at(20, 14)

    // ---- разбор маркеров
    val p1 = parseParts("Привет.\n[состояние: тихая | причина: ты вернулся]\nКак ты?")
    check("состояние: три части", p1.size == 3 && p1[1] == Part.State("тихая", "ты вернулся") && p1[2] == Part.Text("Как ты?"), p1.toString())
    val p2 = parseParts("[состояние: настороженная]")
    check("состояние без причины", p2 == listOf(Part.State("настороженная", "")), p2.toString())
    val p3 = parseParts("Хорошо. Напишу позже.\n[напишу: 21:30 | про зимний лес]")
    check("напишу", p3 == listOf(Part.Text("Хорошо. Напишу позже."), Part.Plan("21:30", "про зимний лес")), p3.toString())
    val p4 = parseParts("[напишу: через 3 ч | вернуться к разговору]")
    check("напишу через N ч", p4 == listOf(Part.Plan("через 3 ч", "вернуться к разговору")), p4.toString())
    val p5 = parseParts("Ок. [след: план | спросить про сон] и ещё [след: вопрос | почему он молчал]")
    check("след", p5.filterIsInstance<Part.Note>() == listOf(Part.Note("план", "спросить про сон"), Part.Note("вопрос", "почему он молчал")), p5.toString())
    val p6 = parseParts("Да.\n[пауза:3]\nНо не так. [стикер:s1]")
    check("старые маркеры живы", p6 == listOf(Part.Text("Да."), Part.Pause(3), Part.Text("Но не так."), Part.Sticker("s1")), p6.toString())
    check("[молчу] важнее всего", parseParts("[молчу] [состояние: x | причина: y]") == listOf(Part.Silence))
    val p7 = parseParts("Это не маркер [состояние] и [напишу: без темы] и [след: только]")
    check("битые маркеры остаются текстом", p7.size == 1 && p7[0] is Part.Text, p7.toString())
    val p8 = parseParts("[пауза]")
    check("пауза без числа = 2", p8 == listOf(Part.Pause(2)), p8.toString())
    val p9 = parseParts("[СОСТОЯНИЕ: Злая | ПРИЧИНА: он стёр запись]")
    check("регистр не важен", p9 == listOf(Part.State("Злая", "он стёр запись")), p9.toString())

    // ---- время
    check("21:30 сегодня", parseWhen("21:30", now, tz).at == at(21, 30))
    check("19:00 уже прошло: завтра", parseWhen("19:00", now, tz).at == at(19, 0, 20))
    check("завтра 09:00", parseWhen("завтра 09:00", now, tz).at == at(9, 0, 20))
    check("через 3 ч", parseWhen("через 3 ч", now, tz).at == now + 3 * 3_600_000L)
    check("через 40 мин", parseWhen("через 40 мин", now, tz).at == now + 40 * 60_000L)
    check("через час", parseWhen("через час", now, tz).at == now + 3_600_000L)
    check("через полчаса", parseWhen("через полчаса", now, tz).at == now + 30 * 60_000L)
    check("через 2 часа", parseWhen("через 2 часа", now, tz).at == now + 2 * 3_600_000L)
    check("25:00 не бывает", parseWhen("25:00", now, tz).at == null)
    check("мусор не принят", parseWhen("когда-нибудь", now, tz).at == null)
    check("через 3 дня не принято", parseWhen("через 60 ч", now, tz).at == null && parseWhen("через 60 ч", now, tz).why.contains("двое суток"))
    check("через 0 мин слишком скоро", parseWhen("через 0 мин", now, tz).at == null)
    check("через мин без числа", parseWhen("через мин", now, tz).at == null)
    check("20:14 это уже сейчас: завтра", parseWhen("20:14", now, tz).at == at(20, 14, 20))
    check("через 47 ч принято", parseWhen("через 47 ч", now, tz).at != null)

    // ---- правила назначений
    val a = acceptPlan(emptyList(), "21:30", "про лес", now, "p1", tz)
    check("назначение принято", a.plan != null && a.plan!!.topic == "про лес" && a.plan!!.status == "pending", a.toString())
    val three = (1..3).map { PlanItem("x$it", now + it * 3_600_000L, "т$it", now) }
    check("четвёртое отклонено с причиной", acceptPlan(three, "22:00", "ещё", now, "p9", tz).why.contains("уже назначено 3"))
    val oneDone = three.take(2) + three[2].copy(status = "done")
    check("завершённые не считаются", acceptPlan(oneDone, "22:00", "ещё", now, "p9", tz).plan != null)
    check("без темы нельзя", acceptPlan(emptyList(), "22:00", "  ", now, "p9", tz).plan == null)
    check("плохое время даёт причину", acceptPlan(emptyList(), "вчера", "х", now, "p9", tz).why.isNotEmpty())

    // ---- контекст
    val ctx = exeContext(
        listOf(StateEntry(now - 3600000, "тихая", "он вернулся")),
        listOf(NoteEntry("n1", now, "план", "спросить про сон")),
        listOf(PlanItem("p1", now + 3600000, "про лес", now)),
        listOf("рука: ls → 3 файла")
    )
    check("контекст: состояние с причиной", ctx.contains("тихая, потому что он вернулся"))
    check("контекст: назначение, след, действие", ctx.contains("про лес") && ctx.contains("[план] спросить про сон") && ctx.contains("рука: ls"), ctx)
    check("контекст пуст, когда нечего сказать", exeContext(emptyList(), emptyList(), emptyList()) == "")
    check("контекст без причины не врёт", !exeContext(listOf(StateEntry(now, "злая", "")), emptyList(), emptyList()).contains("потому что"))
    val lim = exeLimitLines(listOf(PlanItem("p1", now + 3600000, "про лес", now)), 4)
    check("лимиты: честные строки", lim.size == 3 && lim[1].contains("про лес") && lim[2].contains("4") && lim[1].contains("двое суток"), lim.toString())

    // ---- свободный режим
    val h = 3_600_000L
    fun gate(role: String = "assistant", hour: Int = 14, cnt: Int = 0, since: Long = 3 * h, next: Long = 0L, un: Int = 0) =
        freeGate(role, hour, 23, 10, cnt, since, 1_000_000L, next, un)
    check("free: ворота открыты", gate() == FreeGate.OK)
    check("free: он написал последним: ждём ответ", gate(role = "user") == FreeGate.WAIT_USER)
    check("free: тихие часы", gate(hour = 2) == FreeGate.QUIET && gate(hour = 23) == FreeGate.QUIET && gate(hour = 10) == FreeGate.OK)
    check("free: суточный предел", gate(cnt = FREE_DAILY_CAP) == FreeGate.CAP && gate(cnt = FREE_DAILY_CAP - 1) == FreeGate.OK)
    check("free: пауза между сообщениями", gate(since = 10 * 60_000L) == FreeGate.COOLDOWN && gate(since = 25 * 60_000L) == FreeGate.OK)
    check("free: выбранное ею время ещё не пришло", gate(next = 2_000_000L) == FreeGate.NOT_YET && gate(next = 900_000L) == FreeGate.OK)
    check("free: четыре без ответа останавливают", gate(un = 4) == FreeGate.UNANSWERED && gate(un = 3) == FreeGate.OK)
    check("free: пробуждение: по умолчанию час", wakeDelayMs(null) == 3_600_000L)
    check("free: пробуждение: границы 15 мин и 12 ч", wakeDelayMs(1) == 900_000L && wakeDelayMs(9999) == 43_200_000L && wakeDelayMs(40) == 2_400_000L)

    // ---- ответ и пересылка
    val qa = buildQuote(false, "аврора", "Я [пауза:2] думаю про лес [состояние: тихая | причина: вечер] и [фото:f1] вот это")
    check("цитата: маркер без служебных скобок", qa.startsWith("[в ответ на: аврора | ") && qa.count { it == '[' } == 1 && qa.count { it == ']' } == 1, qa)
    check("цитата: фото словом, состояние не течёт", qa.contains("[фото]".replace('[', '(').replace(']', ')')) && !qa.contains("состояние"), qa)
    val (qq, rest) = splitQuote(qa + "\nа я согласен")
    check("цитата отделяется от текста", qq != null && qq.who == "аврора" && !qq.forward && rest == "а я согласен", "$qq / $rest")
    val (qf, restF) = splitQuote("привет\n" + buildQuote(true, "адонис", "моё старое сообщение"))
    check("пересылка своего сообщения", qf != null && qf.forward && qf.who == "адонис" && restF == "привет", "$qf / $restF")
    check("без цитаты текст не меняется", splitQuote("просто текст").let { it.first == null && it.second == "просто текст" })
    check("модель читает ответ как ответ на её сообщение", describeQuote(qq!!).contains("отвечает на твоё сообщение"))
    check("модель читает пересылку своего", describeQuote(qf!!).contains("пересылает тебе своё"))
    check("длинная цитата обрезается", quoteSnippet("слово ".repeat(200), 100).length <= 101)
    check("пустая цитата не пустая", quoteSnippet("[пауза:2]") == "вложение")
    check("цитата внутри снимка тоже находится", splitQuote("[снимок:a.jpg]\n" + buildQuote(false, "аврора", "что-то") + "\nподпись").first != null)

    // ---- её цитата-ответ
    val rp = parseParts("[ответ: про зимний лес]\nЯ его помню.")
    check("[ответ: …] разбирается", rp.first() is Part.Reply && (rp.first() as Part.Reply).snippet == "про зимний лес" && rp.last() is Part.Text, rp.toString())
    val hist = listOf(
        Pair("user", "Расскажи про зимний лес, который я вернул"),
        Pair("assistant", "Он тихий."),
        Pair("user", "А ещё хочу в горы")
    )
    check("находит его сообщение по словам", findQuoted("про зимний лес", hist)?.first == "user" && findQuoted("про зимний лес", hist)!!.second.contains("зимний лес"))
    check("находит её сообщение", findQuoted("он тихий", hist)?.first == "assistant")
    check("берёт самое позднее совпадение", findQuoted("хочу в горы", hist)!!.second.startsWith("А ещё"))
    check("регистр, ё и знаки не мешают", findQuoted("ЗИМНИЙ лес!!", hist) != null)
    check("не нашла: null", findQuoted("совсем другое", hist) == null && findQuoted("я", hist) == null)

    // ---- страница: разбор маркеров
    val pp = parseParts("Смотри.\n[пост: Тихий вечер | фото:f12]\n[статус: слушаю]\n[лайк: зимний лес]\n[аватар: f3]")
    check("пост с фото разобран", pp.filterIsInstance<Part.Post>().first().let { it.text == "Тихий вечер" && it.photoId == "f12" })
    check("пост без фото", (parseParts("[пост: просто текст]").first() as Part.Post).let { it.text == "просто текст" && it.photoId == "" })
    check("humanGap", humanGap(20_000) == "меньше минуты" && humanGap(5 * 60_000) == "5 мин" && humanGap(192 * 60_000L) == "3 ч 12 мин" && humanGap(26 * 3_600_000L) == "1 дн 2 ч" && humanGap(2 * 3_600_000L) == "2 ч")
    val msk = java.util.TimeZone.getTimeZone("Europe/Moscow")
    val t0 = 1_792_549_800_000L // 2026-10-21 ~02:30 MSK
    val tc = timeContext(t0, msk, t0 - 5 * 60_000, t0 - 5 * 60_000 - 192 * 60_000L)
    check("время: пояс и паузы", tc.contains("Europe/Moscow") && tc.contains("UTC+03:00") && tc.contains("до его последнего сообщения в чате было тихо 3 ч 12 мин") && tc.contains("5 мин назад") && tc.contains("2026"), tc)
    check("время без собеседника", !timeContext(t0, msk, 0L, 0L).contains("назад"))
    check("сегменты цифр", segmentsFor(8).all { it } && segmentsFor(1).count { it } == 2 && segmentsFor(7).count { it } == 3 && (0..9).all { segmentsFor(it).size == 7 })
    val qp = parseParts("Это надо запомнить. [в цитаты: лес это дом] И ещё [цитата №3] вот.")
    check("цитаты: маркеры разобраны", qp.any { it is Part.SaveQuote && it.text == "лес это дом" } && qp.any { it is Part.QuoteRef && it.n == 3 } && qp.filterIsInstance<Part.Text>().none { it.s.contains("[") })
    val qh = listOf(Triple("user", "Слушай, лес — это дом. Запомни.", 100L), Triple("assistant", "Запомнила [состояние: тихо]", 200L))
    check("цитата находится в переписке", locateQuote("лес это дом", qh) == Pair("user", 100L))
    check("выдуманная цитата не находится", locateQuote("море это дом", qh) == null)
    check("маркеры не считаются словами цитаты", locateQuote("тихо", qh) == null)
    val ql = listOf(QuoteItem(1, "лес это дом", "user", "aurora", 1L, 100L), QuoteItem(4, "я рядом", "assistant", "adonis", 2L, 200L))
    check("номер следующей цитаты", nextQuoteN(ql) == 5 && nextQuoteN(emptyList()) == 1)
    check("дубль цитаты", isDuplicateQuote("Лес, это дом!", ql) && !isDuplicateQuote("другое", ql))
    val ex = expandQuoteRefs("смотри [цитата №4] и [цитата №9]", ql)
    check("ссылки раскрываются", ex.contains("[цитата №4: «я рядом» — Аврора]") && ex.contains("[цитата №9: такой в цитатнике нет]"), ex)
    val qc = quotesContext(ql)
    check("цитатник в контексте", qc.contains("№1 «лес это дом» — Адонис") && qc.contains("сохранила ты") && qc.indexOf("№1") < qc.indexOf("№4"), qc)
    check("пустой цитатник не идёт в контекст", quotesContext(emptyList()).isEmpty())
    val kp = parseParts("Ой, красиво! [оставить: рассвет над полем] Оставлю.")
    check("оставить разобран", kp.any { it is Part.Keep && it.desc == "рассвет над полем" } && kp.none { it is Part.Pause })
    check("статус, лайк, аватар разобраны", pp.any { it is Part.Status && it.text == "слушаю" } && pp.any { it is Part.Like && it.snippet == "зимний лес" } && pp.any { it is Part.Avatar && it.photoId == "f3" })
    check("маркеры страницы не попадают в цитату", !quoteSnippet("[пост: секрет] привет").contains("секрет"))
    val feed = listOf(PostItem("a", AUTHOR_ME, "Вернул запись про зимний лес", "", 1L), PostItem("b", AUTHOR_HER, "Зимний лес снится", "", 2L))
    check("пост находится по словам и автору", findPost("зимний лес", feed, AUTHOR_ME)?.id == "a" && findPost("зимний лес", feed, AUTHOR_HER)?.id == "b" && findPost("зимний лес", feed)?.id == "b")
    check("контекст пуст без страниц", profileContext(Profile(), Profile(), emptyList()) == "")

    println("\nИТОГ: ок $ok, нет $bad")
    if (bad > 0) System.exit(1)
}
