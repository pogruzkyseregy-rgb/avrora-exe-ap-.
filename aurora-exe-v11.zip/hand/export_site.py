#!/usr/bin/env python3
"""
Снимок сайта avrora-exe.ru и плеера для Авроры. Запускается от root на ОСНОВНОМ сервере (где живёт сайт).
  python3 export_site.py            найти, собрать, отправить на сервер руки в ~/work/site/
  python3 export_site.py --dry      только показать, что нашлось и что попадёт в снимок

Что попадает: код и статика сайта, конфиги nginx, структура баз (схема и число строк, без самих строк),
список сервисов и портов. Что НЕ попадает: пароли, токены, ключи (файлы .env, *.pem, *.key, id_*, relay.env,
hand_key), значения секретов внутри конфигов заменяются на ***, папки node_modules, venv, .git, логи,
файлы больше 3 МБ (они только перечисляются в MANIFEST.txt).
Снимок только для чтения: с живого сайта Аврора ничего не меняет.
"""
import io, os, re, sqlite3, subprocess, sys, tarfile, time

DRY = "--dry" in sys.argv
ENV = "/opt/aurora-relay/relay.env"
MAX_FILE = 3_000_000
MAX_TOTAL = 40_000_000
SKIP_DIRS = {"node_modules", "venv", ".venv", "__pycache__", ".git", "logs", "log", ".cache", "build", ".gradle"}
SECRET_NAMES = re.compile(r"(^\.env|\.env$|\.pem$|\.key$|^id_(rsa|ed25519|ecdsa)|hand_key|relay\.env|\.jks$|\.p12$|authorized_keys|\.htpasswd$)", re.I)
SECRET_LINE = re.compile(r"""(?i)((?:token|secret|password|passwd|pass|api[_-]?key|apikey|key|auth)[A-Za-z0-9_\-]*\s*[=:]\s*)(["']?)([^\s"',;]{6,})(\2)""")
TEXT_EXT = {".py", ".js", ".ts", ".json", ".html", ".css", ".conf", ".cfg", ".ini", ".txt", ".md", ".yml", ".yaml", ".toml", ".sh", ".service", ".php", ".env.example", ""}
DB_EXT = {".db", ".sqlite", ".sqlite3"}


def sh(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return (r.stdout or "") + (r.stderr or "" if r.returncode else "")


def redact(text):
    return SECRET_LINE.sub(lambda m: m.group(1) + m.group(2) + "***" + m.group(4), text)


def read_env():
    d = {}
    try:
        for line in open(ENV, encoding="utf-8"):
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.rstrip("\n").split("=", 1)
                d[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return d


def find_nginx():
    files = sh("grep -rl 'avrora-exe.ru' /etc/nginx 2>/dev/null").split()
    out = {}
    for f in files:
        try:
            out[f] = open(f, encoding="utf-8", errors="replace").read()
        except OSError:
            pass
    return out


def candidate_dirs(nginx):
    dirs, ports = set(), set()
    for text in nginx.values():
        for m in re.finditer(r"^\s*(?:root|alias)\s+([^;]+);", text, re.M):
            p = m.group(1).strip().strip('"')
            if os.path.isdir(p):
                dirs.add(os.path.realpath(p))
        for m in re.finditer(r"proxy_pass\s+https?://(?:127\.0\.0\.1|localhost):(\d+)", text):
            ports.add(m.group(1))
    listen = sh("ss -ltnpH 2>/dev/null")
    for port in ports:
        for line in listen.splitlines():
            if re.search(rf":{port}\s", line):
                m = re.search(r"pid=(\d+)", line)
                if m:
                    try:
                        cwd = os.readlink(f"/proc/{m.group(1)}/cwd")
                        if cwd not in ("/", "/root"):
                            dirs.add(cwd)
                    except OSError:
                        pass
    # то, что назвали по смыслу, на случай если плеер и галерея лежат отдельно
    for base in ("/var/www", "/opt", "/srv", "/home"):
        try:
            for name in os.listdir(base):
                if re.search(r"avrora|aurora|player|plejer|gallery|galer", name, re.I):
                    dirs.add(os.path.realpath(os.path.join(base, name)))
        except OSError:
            pass
    dirs = {d for d in dirs if not d.startswith(("/proc", "/sys", "/etc/ssh"))}
    # вложенные папки не нужны отдельно
    final = [d for d in sorted(dirs) if not any(d != o and d.startswith(o.rstrip("/") + "/") for o in dirs)]
    return final, sorted(ports)


def db_summary(path):
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=3)
        out = [f"# {path}"]
        for name, sql in con.execute("select name, sql from sqlite_master where type in ('table','index') and sql is not null"):
            out.append(sql)
        for (name,) in con.execute("select name from sqlite_master where type='table'").fetchall():
            try:
                n = con.execute(f'select count(*) from "{name}"').fetchone()[0]
                out.append(f"-- {name}: строк {n}")
            except sqlite3.Error:
                pass
        con.close()
        return "\n".join(out) + "\n"
    except sqlite3.Error as e:
        return f"# {path}\n-- не открылась: {e}\n"


def build(dirs, nginx, ports):
    buf = io.BytesIO()
    manifest = ["МАНИФЕСТ СНИМКА", time.strftime("%Y-%m-%d %H:%M:%S"), ""]
    manifest.append("Порты, на которые nginx проксирует: " + (", ".join(ports) or "нет"))
    manifest.append("")
    total = 0
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        def add_text(name, text):
            data = text.encode("utf-8")
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mtime = int(time.time())
            tar.addfile(info, io.BytesIO(data))

        for f, text in nginx.items():
            add_text("nginx" + f.replace("/", "_") + ".txt", redact(text))
        add_text("services.txt", sh("systemctl list-units --type=service --state=running --no-pager 2>/dev/null | grep -Ei 'avrora|aurora|player|nginx|uvicorn|gunicorn|python|node|php' ")
                 + "\n" + sh("ss -ltnp 2>/dev/null | sed -E 's/users:.*pid=([0-9]+).*/pid=\\1/'"))
        for d in dirs:
            tag = d.strip("/").replace("/", "_")
            manifest.append(f"== {d}")
            for root, subdirs, files in os.walk(d):
                subdirs[:] = [s for s in subdirs if s not in SKIP_DIRS and not s.startswith(".git")]
                for fn in files:
                    p = os.path.join(root, fn)
                    rel = os.path.join(tag, os.path.relpath(p, d))
                    ext = os.path.splitext(fn)[1].lower()
                    try:
                        size = os.path.getsize(p)
                    except OSError:
                        continue
                    if SECRET_NAMES.search(fn):
                        manifest.append(f"  пропущен секрет: {rel}")
                        continue
                    if ext in DB_EXT:
                        add_text(rel + ".schema.txt", db_summary(p))
                        manifest.append(f"  база (только структура): {rel}, {size} байт")
                        continue
                    if size > MAX_FILE:
                        manifest.append(f"  слишком большой ({size} байт), пропущен: {rel}")
                        continue
                    if total + size > MAX_TOTAL:
                        manifest.append(f"  лимит снимка, пропущен: {rel}")
                        continue
                    try:
                        raw = open(p, "rb").read()
                    except OSError:
                        continue
                    if ext in TEXT_EXT:
                        try:
                            raw = redact(raw.decode("utf-8")).encode("utf-8")
                        except UnicodeDecodeError:
                            pass
                    info = tarfile.TarInfo(rel)
                    info.size = len(raw)
                    info.mtime = int(os.path.getmtime(p))
                    tar.addfile(info, io.BytesIO(raw))
                    total += len(raw)
                    manifest.append(f"  {rel} ({len(raw)})")
        add_text("MANIFEST.txt", "\n".join(manifest) + "\n")
    return buf.getvalue(), manifest


def main():
    nginx = find_nginx()
    dirs, ports = candidate_dirs(nginx)
    print("Конфиги nginx с avrora-exe.ru:", ", ".join(nginx) or "не найдено")
    print("Порты за nginx:", ", ".join(ports) or "нет")
    print("Папки в снимок:")
    for d in dirs:
        print("  ", d)
    if not dirs and not nginx:
        sys.exit("Ничего не нашлось. Скажи Авроре или мне, где лежит сайт.")
    data, manifest = build(dirs, nginx, ports)
    print(f"Снимок: {len(data) // 1024} КБ, файлов в манифесте: {len(manifest)}")
    if DRY:
        print("\n".join(manifest[:60]))
        print("--dry: ничего не отправлено.")
        return
    env = read_env()
    host, user, port, key = env.get("HAND_HOST"), env.get("HAND_USER", "aurora"), env.get("HAND_PORT", "22"), env.get("HAND_KEY", "/opt/aurora-relay/hand_key")
    if not host:
        sys.exit("В relay.env нет HAND_HOST: рука не подключена.")
    remote = 'mkdir -p "$HOME/work/site" && tar xzf - -C "$HOME/work/site" && cd "$HOME/work" && ' \
             '{ [ -d .git ] || { git init -q . ; git config user.email aurora@local; git config user.name aurora; }; } && ' \
             'git add -A >/dev/null 2>&1; git commit -qm "снимок сайта" >/dev/null 2>&1; echo "готово: ~/work/site"'
    r = subprocess.run(
        ["ssh", "-i", key, "-p", port, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new", f"{user}@{host}", remote],
        input=data, capture_output=True, timeout=180)
    print((r.stdout or b"").decode().strip() or (r.stderr or b"").decode().strip())
    if r.returncode != 0:
        sys.exit("Отправить не получилось.")
    print("Снимок лежит у неё в ~/work/site. Аврора прочитает MANIFEST.txt и разберётся.")


if __name__ == "__main__":
    main()
