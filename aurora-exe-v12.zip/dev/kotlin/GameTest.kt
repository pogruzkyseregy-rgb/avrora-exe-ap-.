package ru.avrora.exe

import kotlin.random.Random

var gok = 0
var gbad = 0
fun gcheck(name: String, c: Boolean, info: String = "") { if (c) { gok++; println("[ОК]   $name") } else { gbad++; println("[НЕТ]  $name $info") } }

/** Кубики по сценарию: nextInt(from, until) отдаёт значения по очереди. */
class Seq(vararg v: Int) : Random() {
    private val vals = v.toList()
    private var i = 0
    override fun nextBits(bitCount: Int): Int = 0
    override fun nextInt(from: Int, until: Int): Int = vals[i++ % vals.size]
    override fun nextInt(until: Int): Int = vals[i++ % vals.size]
}

fun base(): GameState = newGame("g", 3, 0L).copy(phase = "roll", turn = 0, first = 0)

fun main() {
    gcheck("поле из 28 клеток", BOARD.size == BOARD_SIZE)
    gcheck("клетки по периметру не совпадают", (0 until BOARD_SIZE).map { cellPos(it) }.toSet().size == BOARD_SIZE &&
        (0 until BOARD_SIZE).all { val (r, c) = cellPos(it); r == 0 || r == 7 || c == 0 || c == 7 })
    gcheck("соседние клетки рядом", (0 until BOARD_SIZE).all { val a = cellPos(it); val b = cellPos((it + 1) % BOARD_SIZE); kotlin.math.abs(a.first - b.first) + kotlin.math.abs(a.second - b.second) == 1 })

    // очерёдность
    var s = rollOrder(newGame("g", 3, 0L), Seq(4, 4, 2, 5))
    gcheck("очерёдность: ничья перебрасывается, у кого больше, тот первый", s.first == 1 && s.turn == 1 && s.phase == "roll" && s.log.any { it.contains("перебрасываем") }, s.log.toString())

    // покупка
    s = rollMove(base(), Seq(1, 2))  // 0 → 3 (Кабели)
    gcheck("бросок ведёт на узел и ждёт решения", s.current.pos == 3 && s.phase == "buy" && s.turn == 0)
    val bought = decideBuy(s, true)
    gcheck("покупка: деньги списаны, узел мой, ход перешёл", bought.owners[3] == 0 && bought.players[0].money == START_MONEY - 60 && bought.turn == 1 && bought.phase == "roll")
    val passed = decideBuy(s, false)
    gcheck("отказ от покупки", passed.owners[3] == null && passed.players[0].money == START_MONEY && passed.turn == 1)

    // аренда и район
    var r = base().copy(owners = mapOf(3 to 1), turn = 0)
    r = rollMove(r, Seq(1, 2))
    gcheck("чужой узел: плата владельцу", r.players[0].money == START_MONEY - 12 && r.players[1].money == START_MONEY + 12)
    r = rollMove(base().copy(owners = mapOf(1 to 1, 3 to 1)), Seq(1, 2))
    gcheck("весь район у владельца: плата вдвое", r.players[0].money == START_MONEY - 24)

    // патруль
    r = rollMove(base(), Seq(3, 4))  // 0 → 7 патруль
    gcheck("патруль: пропуск хода", r.players[0].skip == 1 && r.turn == 1)
    r = rollMove(r, Seq(1, 1))  // Аврора 0 → 2: сигнал, карта по Seq: следующее значение 1 → «дрон вперёд на 3»
    val afterAurora = if (r.phase == "buy") decideBuy(r, false) else r
    gcheck("ход Авроры прошёл, Адонис пропустил и снова её ход", afterAurora.turn == 1 && afterAurora.players[0].skip == 0 && afterAurora.log.any { it.contains("Адонис пропускает ход") }, afterAurora.log.takeLast(5).toString())

    // облава и карантин
    r = rollMove(base().copy(players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 20) else p }), Seq(2, 3))  // 20 → 25 облава
    gcheck("облава: в карантин", r.players[0].pos == QUAR_INDEX && r.players[0].quarantine == QUAR_TURNS && r.turn == 1)
    var q = r.copy(turn = 0, phase = "roll")
    q = prepareTurn(q)
    gcheck("в карантине с деньгами: решение", q.phase == "jail")
    val out = decideJail(q, true)
    gcheck("выход за плату: можно ходить сразу", out.phase == "roll" && out.turn == 0 && out.players[0].quarantine == 0 && out.players[0].money == r.players[0].money - QUAR_FEE)
    val stay = decideJail(q, false)
    gcheck("остаться: ход переходит", stay.turn == 1 && stay.players[0].quarantine == QUAR_TURNS - 1)

    // портал и глитч
    r = rollMove(base(), Seq(2, 3))  // 0 → 5 портал → 12 Голо (узел)
    gcheck("портал переносит на узел", r.current.pos == 12 && r.phase == "buy")
    r = rollMove(base().copy(players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 10) else p }), Seq(2, 3))  // 10 → 15 глитч → 12
    gcheck("глитч: назад на 3 и приземление", r.current.pos == 12 && r.phase == "buy")

    // проход старта и конец партии
    var e = base().copy(laps = 2, players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 26, laps = 1) else p.copy(pos = 26, laps = 1) })
    e = rollMove(e, Seq(1, 1))  // 26 → 0 (2 клетки): старт +150, круг 2/2 → последний круг
    gcheck("проход старта: бонус и последний круг", e.players[0].money == START_MONEY + PASS_BONUS && e.players[0].laps == 2 && e.finalRound && e.turn == 1 && !e.over)
    e = rollMove(e, Seq(3, 4))  // Аврора делает свой ход → круг выравнен → конец
    if (e.phase == "buy") e = decideBuy(e, true)
    gcheck("партия заканчивается после равного числа ходов", e.over && e.winner in listOf(0, 1, -2), e.log.takeLast(3).toString())
    gcheck("в журнале есть итог", e.log.last().contains("Партия окончена"))

    // разорение
    var b = base().copy(owners = mapOf(26 to 1, 24 to 1), players = listOf(GPlayer("user", pos = 23, money = 20), GPlayer("aurora")))
    b = rollMove(b, Seq(1, 2))  // 23+3 = 26 Ядро, аренда 100 (весь район)
    gcheck("разорение: партия окончена, победил другой", b.over && b.winner == 1, b.log.takeLast(3).toString())

    // случайные партии: всегда заканчиваются, ничего не ломается
    var allEnd = true
    var maxTurns = 0
    repeat(400) { seed ->
        val rnd = Random(seed)
        var g = rollOrder(newGame("r$seed", 3, 0L), rnd)
        var steps = 0
        while (!g.over && steps < 2000) {
            g = when (g.phase) {
                "roll" -> rollMove(g, rnd)
                "buy" -> decideBuy(g, rnd.nextBoolean())
                "jail" -> decideJail(g, rnd.nextBoolean())
                else -> g
            }
            steps++
            if (g.players.any { it.pos !in 0 until BOARD_SIZE }) { allEnd = false; return@repeat }
        }
        if (!g.over) allEnd = false
        maxTurns = maxOf(maxTurns, g.turnNo)
    }
    gcheck("400 случайных партий заканчиваются", allEnd)
    gcheck("партия на 3 круга не бесконечна (ходов ≤ 80)", maxTurns <= 80, maxTurns.toString())

    // контекст и пометки
    val ctx = gameContext(base().copy(owners = mapOf(3 to 1)))
    gcheck("контекст партии для неё", ctx.contains("Аврора: 800 ₵") && ctx.contains("Переулок кабелей") && ctx.contains("Сейчас ход: Адонис"), ctx)
    gcheck("кругов из приглашения", parseInviteLaps("круги:5") == 5 && parseInviteLaps("") == GAME_DEFAULT_LAPS && parseInviteLaps("99") == 8)
    val ex = expandGameMarkers("Давай! [игра: приглашение | круги:5]")
    gcheck("приглашение понятно ей", ex.contains("на 5 круга") && ex.contains("[игра: принять]"), ex)
    gcheck("итог понятен ей", expandGameMarkers("[игра: итог | Победа: Аврора]") == "[Партия окончена: Победа: Аврора]")

    println("\nИТОГ: ок $gok, нет $gbad")
    if (gbad > 0) System.exit(1)
}
