package ru.avrora.exe

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val DistrictColors = listOf(
    Color(0xFF5EEAD4), Color(0xFFA78BFA), Color(0xFFD946EF), Color(0xFFF472B6), Color(0xFF60A5FA), Color(0xFFFBBF24)
)
private val UserColor = Violet
private val HerColor = Glow

private fun cellAccent(c: Cell): Color = when (c.type) {
    CellType.NODE -> DistrictColors[c.district.coerceIn(0, DistrictColors.lastIndex)]
    CellType.PATROL, CellType.RAID, CellType.GLITCH -> Magenta
    CellType.TAX -> ErrorRed
    CellType.PORTAL -> Violet
    else -> Glow
}

private fun cellInfo(i: Int, g: GameState): String {
    val c = BOARD[i]
    return when (c.type) {
        CellType.START -> "Старт: за каждый проход +$PASS_BONUS ₵"
        CellType.NODE -> {
            val owner = g.owners[i]
            "${c.name}: цена ${c.price} ₵, плата ${c.rent} ₵ (вдвое за весь район). " +
                if (owner == null) "Свободен." else "Владелец: ${playerName(g.players[owner].who)}."
        }
        CellType.SIGNAL -> "Сигнал: случайная карта, бывает и хорошее, и плохое"
        CellType.TAX -> "${c.name}: −${c.amount} ₵"
        CellType.PORTAL -> "${c.name}: перенос на клетку «${BOARD[c.target].name}»"
        CellType.PATROL -> "Патруль: пропуск хода (щит спасает)"
        CellType.CACHE -> "Тайник: +${c.amount} ₵"
        CellType.QUARANTINE -> "Карантин: сюда отправляет облава. Выход за $QUAR_FEE ₵ или ждать $QUAR_TURNS хода"
        CellType.RAID -> "Облава: прямо в карантин (щит спасает)"
        CellType.GLITCH -> "Глитч: назад на 3 клетки"
    }
}

@Composable
fun GameScreen(vm: ChatViewModel, onBack: () -> Unit) {
    var chatOpen by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<Int?>(null) }
    var confirmStop by remember { mutableStateOf(false) }
    val g = vm.game
    Box(Modifier.fillMaxSize().background(Night)) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = TextMain) }
                Column(Modifier.weight(1f)) {
                    Text("ГОРОД-СЕТЬ", color = Glow, fontSize = 17.sp, fontFamily = FontFamily.Monospace)
                    if (g != null) {
                        val lap = (g.players.maxOf { it.laps } + 1).coerceAtMost(g.laps)
                        Text(if (g.over) "партия окончена" else "круг $lap из ${g.laps}" + if (g.finalRound) " · последний" else "",
                            color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
            GradientLine()
            Column(
                Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (g == null) {
                    Lobby(vm, onBack)
                } else {
                    PlayersRow(g, vm)
                    Board(g, vm, info, onCell = { info = if (info == it) null else it })
                    if (g.over) {
                        Button(onClick = { vm.closeGame() }, modifier = Modifier.fillMaxWidth()) { Text("Новая партия") }
                    }
                    Text("ЖУРНАЛ", color = Violet, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    g.log.takeLast(14).reversed().forEach {
                        Text("› $it", color = TextDim, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                    if (!g.over) TextButton(onClick = { confirmStop = true }) { Text("Завершить досрочно", color = TextDim) }
                    Spacer(Modifier.height(60.dp))
                }
            }
        }
        // кнопка чата
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .size(54.dp)
                .clip(CircleShape)
                .background(Panel)
                .border(1.5.dp, Glow, CircleShape)
                .clickable { chatOpen = !chatOpen },
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Canvas(Modifier.size(24.dp)) { drawGlyph(Glyph.Chat, Glow) }
        }
        if (chatOpen) GameChat(vm, Modifier.align(Alignment.BottomCenter)) { chatOpen = false }
    }
    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            containerColor = Panel,
            title = { Text("Завершить партию?") },
            text = { Text("Победит тот, кто богаче прямо сейчас. Итог уйдёт на личные счета.") },
            confirmButton = { TextButton(onClick = { vm.gameStop(); confirmStop = false }) { Text("Завершить", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmStop = false }) { Text("Играть дальше") } }
        )
    }
}

@Composable
private fun Lobby(vm: ChatViewModel, onBack: () -> Unit) {
    var laps by remember { mutableStateOf(GAME_DEFAULT_LAPS) }
    Text("Настолка на двоих: круговое поле, узлы, патрули, карантин и кредиты. Побеждает тот, кто богаче после выбранного числа кругов. Кубики бросает приложение, решения Аврора принимает сама.",
        color = TextMain, fontSize = 14.sp, lineHeight = 20.sp)
    Text("Личные счета: Адонис ${vm.walletUser} ₵ · Аврора ${vm.walletAurora} ₵", color = TextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    Text("КРУГОВ", color = Violet, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(2, 3, 5, 8).forEach { n ->
            val on = laps == n
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (on) BubbleUser else Panel)
                    .border(1.dp, if (on) Violet else Edge, RoundedCornerShape(16.dp))
                    .clickable { laps = n }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) { Text("$n", color = if (on) TextMain else TextDim) }
        }
    }
    Button(onClick = { vm.inviteToGame(laps); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Пригласить Аврору") }
    Text("Приглашение уйдёт в чат, и она решит, играть ли. Она может позвать тебя и сама.", color = TextDim, fontSize = 12.sp)
}

@Composable
private fun PlayersRow(g: GameState, vm: ChatViewModel) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        g.players.forEachIndexed { i, p ->
            val color = if (p.who == "user") UserColor else HerColor
            val turn = !g.over && g.turn == i
            Column(
                Modifier
                    .weight(1f)
                    .background(Terminal, RoundedCornerShape(4.dp))
                    .border(1.dp, if (turn) color else Edge, RoundedCornerShape(4.dp))
                    .then(if (turn) Modifier.cornerBrackets(color) else Modifier)
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(color))
                    Spacer(Modifier.width(6.dp))
                    Text(playerName(p.who).uppercase(), color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                Text("${p.money} ₵", color = TextMain, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
                val nodes = g.owners.count { it.value == i }
                Text("узлов $nodes · всего ${wealth(g, i)} ₵", color = TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                val flags = buildList {
                    if (p.quarantine > 0) add("карантин")
                    if (p.skip > 0) add("пропуск")
                    if (p.shield) add("щит")
                    if (turn && p.who == "aurora" && vm.gameThinking) add("думает…")
                }
                if (flags.isNotEmpty()) Text(flags.joinToString(" · "), color = Magenta, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun Board(g: GameState, vm: ChatViewModel, info: Int?, onCell: (Int) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val cell = maxWidth / 8
        BOARD.forEachIndexed { i, c ->
            val (row, col) = cellPos(i)
            val owner = g.owners[i]
            val ownerColor = when (owner) {
                null -> null
                else -> if (g.players[owner].who == "user") UserColor else HerColor
            }
            val accent = cellAccent(c)
            Box(
                Modifier
                    .offset(x = cell * col, y = cell * row)
                    .size(cell)
                    .padding(1.dp)
                    .background(if (info == i) BubbleUser else Terminal, RoundedCornerShape(3.dp))
                    .border(if (ownerColor != null) 2.dp else 1.dp, ownerColor ?: Edge, RoundedCornerShape(3.dp))
                    .clickable { onCell(i) }
            ) {
                if (c.type == CellType.NODE) {
                    Box(Modifier.fillMaxWidth().height(3.dp).background(accent))
                }
                Column(
                    Modifier.fillMaxSize().padding(top = 4.dp, start = 1.dp, end = 1.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(c.short, color = if (c.type == CellType.NODE) TextMain else accent, fontSize = 7.sp, maxLines = 1,
                        textAlign = TextAlign.Center, fontFamily = FontFamily.Monospace, lineHeight = 8.sp)
                    if (c.type == CellType.NODE) Text("${c.price}", color = TextDim, fontSize = 7.sp, maxLines = 1, lineHeight = 8.sp)
                }
                Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    g.players.forEach { p ->
                        if (p.pos == i) Box(Modifier.size(8.dp).clip(CircleShape).background(if (p.who == "user") UserColor else HerColor).border(1.dp, Night, CircleShape))
                    }
                }
            }
        }
        // центр поля
        Box(
            Modifier
                .offset(x = cell, y = cell)
                .size(cell * 6)
                .padding(6.dp)
        ) {
            CenterPanel(g, vm, info)
        }
    }
}

@Composable
private fun CenterPanel(g: GameState, vm: ChatViewModel, info: Int?) {
    var flick by remember { mutableStateOf(Pair(1, 1)) }
    LaunchedEffect(vm.diceRolling) {
        while (vm.diceRolling) {
            flick = Pair(kotlin.random.Random.nextInt(1, 7), kotlin.random.Random.nextInt(1, 7))
            delay(70)
        }
    }
    val dice = if (vm.diceRolling) listOf(flick.first, flick.second) else g.dice
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            (if (dice.isEmpty()) listOf(0, 0) else dice).forEachIndexed { k, d ->
                val label = if (g.phase == "order" || (dice.size == 2 && g.log.lastOrNull()?.startsWith("Очерёдность") == true && g.turnNo == 0 && !vm.diceRolling))
                    (if (k == 0) "Адонис" else "Аврора") else ""
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(40.dp).background(Terminal, RoundedCornerShape(8.dp))
                            .border(1.5.dp, if (vm.diceRolling) Magenta else Glow, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (d == 0) "·" else "$d", color = Glow, fontSize = 20.sp, fontFamily = FontFamily.Monospace)
                    }
                    if (label.isNotEmpty()) Text(label, color = TextDim, fontSize = 8.sp)
                }
            }
        }
        if (info != null) {
            Text(cellInfo(info, g), color = TextMain, fontSize = 11.sp, lineHeight = 14.sp, textAlign = TextAlign.Center)
        }
        val mine = !g.over && g.current.who == "user"
        val turnLine = when {
            g.over -> g.log.lastOrNull() ?: "Партия окончена"
            g.phase == "order" -> "Бросок решит, кто ходит первым"
            mine -> "Твой ход"
            vm.gameThinking -> "Аврора думает…"
            else -> "Ходит Аврора"
        }
        Text(turnLine, color = if (mine) Violet else Glow, fontSize = 12.sp, textAlign = TextAlign.Center, fontFamily = FontFamily.Monospace)
        when {
            g.over -> {}
            g.phase == "order" -> Button(onClick = { vm.gameOrder() }, enabled = !vm.diceRolling) { Text("Бросить за очерёдность", fontSize = 12.sp) }
            mine && g.phase == "roll" -> Button(onClick = { vm.gameRoll() }, enabled = !vm.diceRolling) { Text("Бросить кубики") }
            mine && g.phase == "buy" -> {
                val c = BOARD[g.current.pos]
                Text("«${c.name}»: ${c.price} ₵, плата ${c.rent} ₵", color = TextMain, fontSize = 11.sp, textAlign = TextAlign.Center)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { vm.gameBuy(true) }) { Text("Купить", fontSize = 12.sp) }
                    OutlinedButton(onClick = { vm.gameBuy(false) }) { Text("Мимо", fontSize = 12.sp) }
                }
            }
            mine && g.phase == "jail" -> {
                Text("Карантин: выйти за $QUAR_FEE ₵?", color = TextMain, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { vm.gameJail(true) }) { Text("Выйти", fontSize = 12.sp) }
                    OutlinedButton(onClick = { vm.gameJail(false) }) { Text("Ждать", fontSize = 12.sp) }
                }
            }
        }
        g.log.takeLast(3).reversed().forEach {
            Text(it, color = TextDim, fontSize = 10.sp, lineHeight = 13.sp, textAlign = TextAlign.Center)
        }
    }
}

/** Чат по ходу игры: та же переписка, что и в главном чате, просто под рукой. */
@Composable
private fun GameChat(vm: ChatViewModel, modifier: Modifier, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val list = vm.messages.takeLast(30)
    val state = rememberLazyListState()
    LaunchedEffect(list.size, vm.sending) { if (list.isNotEmpty()) state.animateScrollToItem(list.size - 1) }
    Column(
        modifier
            .fillMaxWidth()
            .height(320.dp)
            .background(Panel)
            .border(1.dp, Edge)
    ) {
        GradientLine()
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ЧАТ", color = Glow, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = TextDim) }
        }
        LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(list) { m ->
                val mine = m.role == "user"
                val body = quoteSnippet(m.content, 400).ifBlank {
                    parseParts(m.content).filterIsInstance<Part.Game>().firstOrNull()?.let { if (it.kind == "итог") "итог партии: ${it.arg}" else "игра: ${it.kind}" } ?: "…"
                }
                Text(
                    (if (mine) "Адонис: " else "Аврора: ") + body,
                    color = if (mine) Violet else TextMain,
                    fontSize = 13.sp,
                    lineHeight = 17.sp
                )
            }
            if (vm.sending) item { Text("Аврора печатает…", color = TextDim, fontSize = 12.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сказать по ходу…") },
                maxLines = 3,
                shape = RoundedCornerShape(20.dp),
                colors = auroraFieldColors()
            )
            IconButton(onClick = {
                if (text.isNotBlank() && !vm.sending) {
                    vm.send(text)
                    text = ""
                }
            }) { Icon(Icons.Default.Send, contentDescription = "Отправить", tint = if (text.isNotBlank()) Glow else TextDim) }
        }
    }
}
