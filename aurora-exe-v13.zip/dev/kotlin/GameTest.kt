package ru.avrora.exe

import kotlin.random.Random

var gok = 0
var gbad = 0
fun gcheck(name: String, c: Boolean, info: String = "") { if (c) { gok++; println("[ОК]   $name") } else { gbad++; println("[НЕТ]  $name $info") } }

/** Кубики по сценарию: nextInt(from, until) отдаёт значения по очереди. */
class Seq(vararg v: Int) : Random() {
    private val vals = v.toList()
    private var i = 0
    override fun nextBits(bitCount: Int): Int = 0
    override fun nextInt(from: Int, until: Int): Int = vals[i++ % vals.size]
    override fun nextInt(until: Int): Int = vals[i++ % vals.size]
}

fun base(): GameState = newGame("g", 3, 0L).copy(phase = "roll", turn = 0, first = 0)

fun main() {
    gcheck("поле из 28 клеток", BOARD.size == BOARD_SIZE)
    val rects = (0 until BOARD_SIZE).map { cellRect(it) }
    fun overlap(a: CellRect, b: CellRect) = a.x < b.x + b.w - 0.001f && b.x < a.x + a.w - 0.001f && a.y < b.y + b.h - 0.001f && b.y < a.y + a.h - 0.001f
    gcheck("клетки не налезают друг на друга", rects.indices.all { i -> rects.indices.all { j -> i == j || !overlap(rects[i], rects[j]) } })
    gcheck("клетки внутри поля 12×12 и по краю", rects.all { it.x >= 0 && it.y >= 0 && it.x + it.w <= 12.001f && it.y + it.h <= 12.001f && (it.x == 0f || it.y == 0f || it.x + it.w >= 11.999f || it.y + it.h >= 11.999f) })
    gcheck("площадь кольца закрыта целиком", kotlin.math.abs(rects.sumOf { (it.w * it.h).toDouble() } - (144.0 - 81.0)) < 0.01)
    gcheck("четыре угла", rects.count { it.corner } == 4 && listOf(0, 10, 20, 30).all { rects[it].corner })
    gcheck("узлов 22, районов 8", BOARD.count { it.type == CellType.NODE } == 22 && BOARD.filter { it.type == CellType.NODE }.map { it.district }.toSet() == (0 until DISTRICTS).toSet())

    // очерёдность
    var s = rollOrder(newGame("g", 3, 0L), Seq(4, 4, 2, 5))
    gcheck("очерёдность: ничья перебрасывается, у кого больше, тот первый", s.first == 1 && s.turn == 1 && s.phase == "pick" && s.log.any { it.contains("перебрасываем") }, s.log.toString())
    val p1 = pickToken(s, 1)
    gcheck("первым фишку выбирает первый, потом второй", p1.players[1].token == 1 && p1.turn == 0 && p1.phase == "pick")
    gcheck("занятую фишку взять нельзя", pickToken(p1, 1) == p1)
    val p2 = pickToken(p1, 2)
    gcheck("после выбора ходит первый", p2.players[0].token == 2 && p2.turn == 1 && p2.phase == "roll" && freeTokens(p2) == listOf(0))

    // покупка
    s = rollMove(base(), Seq(1, 2))  // 0 → 3 (Кабели)
    gcheck("бросок ведёт на узел и ждёт решения", s.current.pos == 3 && s.phase == "buy" && s.turn == 0)
    val bought = decideBuy(s, true)
    gcheck("покупка: деньги списаны, узел мой, ход перешёл", bought.owners[3] == 0 && bought.players[0].money == START_MONEY - 60 && bought.turn == 1 && bought.phase == "roll")
    val passed = decideBuy(s, false)
    gcheck("отказ от покупки", passed.owners[3] == null && passed.players[0].money == START_MONEY && passed.turn == 1)

    // аренда и район
    var r = base().copy(owners = mapOf(3 to 1), turn = 0)
    r = rollMove(r, Seq(1, 2))
    gcheck("чужой узел: плата владельцу", r.players[0].money == START_MONEY - 12 && r.players[1].money == START_MONEY + 12)
    r = rollMove(base().copy(owners = mapOf(1 to 1, 3 to 1)), Seq(1, 2))
    gcheck("весь район у владельца: плата вдвое", r.players[0].money == START_MONEY - 24)

    // патруль
    r = rollMove(base(), Seq(3, 4))  // 0 → 7 патруль
    gcheck("патруль: пропуск хода", r.players[0].skip == 1 && r.turn == 1)
    r = rollMove(r, Seq(1, 1))  // Аврора 0 → 2: сигнал, карта по Seq: следующее значение 1 → «дрон вперёд на 3»
    val afterAurora = if (r.phase == "buy") decideBuy(r, false) else r
    gcheck("ход Авроры прошёл, Адонис пропустил и снова её ход", afterAurora.turn == 1 && afterAurora.players[0].skip == 0 && afterAurora.log.any { it.contains("Адонис пропускает ход") }, afterAurora.log.takeLast(5).toString())

    // облава и карантин
    r = rollMove(base().copy(players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 25) else p }), Seq(2, 3))  // 25 → 30 облава
    gcheck("облава: в карантин", r.players[0].pos == QUAR_INDEX && r.players[0].quarantine == QUAR_TURNS && r.turn == 1)
    var q = r.copy(turn = 0, phase = "roll")
    q = prepareTurn(q)
    gcheck("в карантине с деньгами: решение", q.phase == "jail")
    val out = decideJail(q, true)
    gcheck("выход за плату: можно ходить сразу", out.phase == "roll" && out.turn == 0 && out.players[0].quarantine == 0 && out.players[0].money == r.players[0].money - QUAR_FEE)
    val stay = decideJail(q, false)
    gcheck("остаться: ход переходит", stay.turn == 1 && stay.players[0].quarantine == QUAR_TURNS - 1)

    // портал и глитч
    r = rollMove(base(), Seq(2, 3))  // 0 → 5 портал → 15 (следующий портал, дальше не переносит)
    gcheck("портал переносит к следующему порталу", r.players[0].pos == 15 && r.turn == 1)
    r = rollMove(base().copy(players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 33) else p }), Seq(1, 1))  // 33 → 35 портал → 5 через Старт
    gcheck("портал через Старт даёт бонус", r.players[0].pos == 5 && r.players[0].money == START_MONEY + PASS_BONUS && r.players[0].laps == 1)
    r = rollMove(base().copy(players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 17) else p }), Seq(2, 3))  // 17 → 22 глитч → 19
    gcheck("глитч: назад на 3 и приземление", r.current.pos == 19 && r.phase == "buy")

    // проход старта и конец партии
    var e = base().copy(laps = 2, players = base().players.mapIndexed { k, p -> if (k == 0) p.copy(pos = 38, laps = 1) else p.copy(pos = 38, laps = 1) })
    e = rollMove(e, Seq(1, 1))  // 38 → 0 (2 клетки): старт +150, круг 2/2 → последний круг
    gcheck("проход старта: бонус и последний круг", e.players[0].money == START_MONEY + PASS_BONUS && e.players[0].laps == 2 && e.finalRound && e.turn == 1 && !e.over)
    e = rollMove(e, Seq(3, 4))  // Аврора делает свой ход → круг выравнен → конец
    if (e.phase == "buy") e = decideBuy(e, true)
    gcheck("партия заканчивается после равного числа ходов", e.over && e.winner in listOf(0, 1, -2), e.log.takeLast(3).toString())
    gcheck("в журнале есть итог", e.log.last().contains("Партия окончена"))

    // разорение
    var b = base().copy(owners = mapOf(37 to 1, 39 to 1), players = listOf(GPlayer("user", pos = 34, money = 20), GPlayer("aurora")))
    b = rollMove(b, Seq(1, 2))  // 34+3 = 37 Ядро, плата 140 (весь район)
    gcheck("разорение: партия окончена, победил другой", b.over && b.winner == 1, b.log.takeLast(3).toString())

    // случайные партии: всегда заканчиваются, ничего не ломается
    var allEnd = true
    var maxTurns = 0
    repeat(400) { seed ->
        val rnd = Random(seed)
        var g = rollOrder(newGame("r$seed", 3, 0L), rnd)
        g = pickToken(g, rnd.nextInt(3)); g = pickToken(g, freeTokens(g).first())
        var steps = 0
        while (!g.over && steps < 2000) {
            g = when (g.phase) {
                "roll" -> rollMove(g, rnd)
                "buy" -> decideBuy(g, rnd.nextBoolean())
                "jail" -> decideJail(g, rnd.nextBoolean())
                else -> g
            }
            steps++
            if (g.players.any { it.pos !in 0 until BOARD_SIZE }) { allEnd = false; return@repeat }
        }
        if (!g.over) allEnd = false
        maxTurns = maxOf(maxTurns, g.turnNo)
    }
    gcheck("400 случайных партий заканчиваются", allEnd)
    gcheck("партия на 3 круга не бесконечна (ходов ≤ 160)", maxTurns <= 160, maxTurns.toString())

    // журнал считает строки: приложение знает, что случилось за ход
    val before = base()
    val after = rollMove(before, Seq(3, 4))
    gcheck("счётчик строк журнала растёт", after.seq > before.seq && after.log.takeLast(after.seq - before.seq).first().contains("бросок"))

    // контекст и пометки
    val ctx = gameContext(base().copy(owners = mapOf(3 to 1)))
    gcheck("контекст партии для неё", ctx.contains("Аврора: $START_MONEY ₵") && ctx.contains("коротко") && ctx.contains("Переулок кабелей") && ctx.contains("Сейчас ход: Адонис"), ctx)
    gcheck("кругов из приглашения", parseInviteLaps("круги:5") == 5 && parseInviteLaps("") == GAME_DEFAULT_LAPS && parseInviteLaps("99") == 8)
    val ex = expandGameMarkers("Давай! [игра: приглашение | круги:5]")
    gcheck("приглашение понятно ей", ex.contains("на 5 круга") && ex.contains("[игра: принять]"), ex)
    gcheck("итог понятен ей", expandGameMarkers("[игра: итог | Победа: Аврора]") == "[Партия окончена: Победа: Аврора]")

    println("\nИТОГ: ок $gok, нет $gbad")
    if (gbad > 0) System.exit(1)
}
