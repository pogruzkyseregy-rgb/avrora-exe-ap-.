package ru.avrora.exe

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Виджет на рабочий стол: ближайший будильник, кто поставил, зачем. Нажатие открывает будильники в приложении. */
class AlarmWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = render(ctx, mgr, ids)

    companion object {
        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx) ?: return
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, AlarmWidget::class.java))
            if (ids.isNotEmpty()) render(ctx, mgr, ids)
        }

        private fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val now = System.currentTimeMillis()
            val next = nextAlarm(AlarmStore(ctx).list(), now)
            val open = PendingIntent.getActivity(
                ctx, 7101,
                Intent(ctx, MainActivity::class.java).putExtra("open", "alarms").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            for (id in ids) {
                val v = RemoteViews(ctx.packageName, R.layout.widget_alarm)
                v.setOnClickPendingIntent(R.id.widget_root, open)
                if (next == null) {
                    v.setTextViewText(R.id.widget_time, "--:--")
                    v.setTextViewText(R.id.widget_sub, "будильников нет · нажми, чтобы поставить")
                    v.setTextViewText(R.id.widget_by, "")
                } else {
                    val (a, at) = next
                    v.setTextViewText(R.id.widget_time, SimpleDateFormat("HH:mm", Locale.US).format(Date(at)))
                    v.setTextViewText(R.id.widget_sub, dayWord(at, now) + " · " + alarmDaysText(a) + if (a.label.isNotBlank()) " · ${a.label}" else "")
                    v.setTextViewText(R.id.widget_by, if (a.by == "aurora") "поставила Аврора" else "")
                }
                mgr.updateAppWidget(id, v)
            }
        }

        private fun dayWord(at: Long, now: Long): String {
            val a = Calendar.getInstance().apply { timeInMillis = at }
            val n = Calendar.getInstance().apply { timeInMillis = now }
            val diff = (a.get(Calendar.YEAR) * 400 + a.get(Calendar.DAY_OF_YEAR)) - (n.get(Calendar.YEAR) * 400 + n.get(Calendar.DAY_OF_YEAR))
            return when (diff) {
                0 -> "сегодня"
                1 -> "завтра"
                else -> SimpleDateFormat("EEE d MMM", Locale("ru")).format(Date(at))
            }
        }
    }
}
