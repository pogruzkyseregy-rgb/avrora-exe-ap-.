package ru.avrora.exe

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Виджет: крупно текущее время (при смене минуты по цифрам пробегает глитч), ниже ближайший будильник.
 * Фон: своя картинка (из галереи или из её альбома) с затемнением, либо тёмная рамка по умолчанию.
 */
class AlarmWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        render(ctx, mgr, ids)
        scheduleTick(ctx)
    }

    override fun onEnabled(ctx: Context) = scheduleTick(ctx)
    override fun onDisabled(ctx: Context) = cancelTick(ctx)

    companion object {
        private const val REQ_TICK = 7201
        private const val GLITCH_CHARS = "▓▒░#%&@$01"

        fun ids(ctx: Context): IntArray {
            val mgr = AppWidgetManager.getInstance(ctx) ?: return IntArray(0)
            return mgr.getAppWidgetIds(ComponentName(ctx, AlarmWidget::class.java))
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx) ?: return
            val ids = ids(ctx)
            if (ids.isNotEmpty()) {
                render(ctx, mgr, ids)
                scheduleTick(ctx)
            }
        }

        private fun bgFile(ctx: Context) = File(ctx.filesDir, "widget_bg.png")
        private fun srcFile(ctx: Context) = File(ctx.filesDir, "widget_bg_src.jpg")
        fun previewFile(ctx: Context): File? = bgFile(ctx).takeIf { it.exists() }

        fun hasBackground(ctx: Context) = bgFile(ctx).exists()

        /** Готовит фон: обрезка под виджет, затемнение, скруглённые углы. Исходник хранится, чтобы менять затемнение. */
        fun setBackground(ctx: Context, src: Bitmap, dimPercent: Int, keepSource: Boolean = true): Boolean {
            if (keepSource) {
                try {
                    val s = maxOf(src.width, src.height).let { if (it > 1400) 1400f / it else 1f }
                    val small = if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src
                    srcFile(ctx).outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                } catch (e: Exception) { }
            }
            val w = 800
            val h = 500
            val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
            val sw = (w / scale).toInt().coerceAtMost(src.width)
            val sh = (h / scale).toInt().coerceAtMost(src.height)
            val sx = (src.width - sw) / 2
            val sy = (src.height - sh) / 2
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val r = 46f
            c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            c.drawBitmap(src, Rect(sx, sy, sx + sw, sy + sh), Rect(0, 0, w, h), paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            paint.color = Color.argb((dimPercent.coerceIn(0, 85) * 255 / 100), 9, 6, 15)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            return try {
                bgFile(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                updateAll(ctx)
                true
            } catch (e: Exception) { false }
        }

        fun setBackgroundFromUri(ctx: Context, uri: Uri, dimPercent: Int): Boolean {
            val bmp = try {
                ctx.contentResolver.openInputStream(uri)?.use { s ->
                    BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = 2 })
                }
            } catch (e: Exception) { null } ?: return false
            return setBackground(ctx, bmp, dimPercent)
        }

        fun setBackgroundFromFile(ctx: Context, file: File, dimPercent: Int): Boolean {
            val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return false
            return setBackground(ctx, bmp, dimPercent)
        }

        fun reapplyDim(ctx: Context, dimPercent: Int): Boolean {
            val src = srcFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) } ?: return false
            return setBackground(ctx, src, dimPercent, keepSource = false)
        }

        fun clearBackground(ctx: Context) {
            bgFile(ctx).delete()
            srcFile(ctx).delete()
            updateAll(ctx)
        }

        private fun baseViews(ctx: Context): RemoteViews {
            val now = System.currentTimeMillis()
            val v = RemoteViews(ctx.packageName, R.layout.widget_alarm)
            val open = PendingIntent.getActivity(
                ctx, 7101,
                Intent(ctx, MainActivity::class.java).putExtra("open", "alarms").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.widget_root, open)
            val bg = bgFile(ctx)
            val bmp = if (bg.exists()) BitmapFactory.decodeFile(bg.absolutePath) else null
            if (bmp != null) {
                v.setImageViewBitmap(R.id.widget_bg_img, bmp)
                v.setViewVisibility(R.id.widget_bg_img, View.VISIBLE)
            } else {
                v.setViewVisibility(R.id.widget_bg_img, View.GONE)
            }
            v.setViewVisibility(R.id.widget_glitch, View.GONE)
            v.setTextViewText(R.id.widget_time, SimpleDateFormat("HH:mm", Locale.US).format(Date(now)))
            v.setTextColor(R.id.widget_time, Color.parseColor("#5EEAD4"))
            v.setViewPadding(R.id.widget_time, 0, 0, 0, 0)
            val next = nextAlarm(AlarmStore(ctx).list(), now)
            if (next == null) {
                v.setTextViewText(R.id.widget_alarm, "")
                v.setTextViewText(R.id.widget_sub, "будильников нет · нажми, чтобы поставить")
                v.setTextViewText(R.id.widget_by, "")
            } else {
                val (a, at) = next
                v.setTextViewText(R.id.widget_alarm, "будильник " + SimpleDateFormat("HH:mm", Locale.US).format(Date(at)) + " · " + dayWord(at, now))
                v.setTextViewText(R.id.widget_sub, alarmDaysText(a) + if (a.label.isNotBlank()) " · ${a.label}" else "")
                v.setTextViewText(R.id.widget_by, if (a.by == "aurora") "поставила Аврора" else "")
            }
            return v
        }

        private fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val v = baseViews(ctx)
            for (id in ids) mgr.updateAppWidget(id, v)
        }

        /** Полосы глитча: маленькая картинка, растягивается на весь виджет и выглядит рвано. */
        private fun glitchBars(rnd: Random): Bitmap {
            val b = Bitmap.createBitmap(120, 60, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            val p = Paint()
            repeat(7 + rnd.nextInt(6)) {
                val y = rnd.nextInt(60)
                val h = 1 + rnd.nextInt(4)
                val x = rnd.nextInt(40)
                p.color = if (rnd.nextBoolean()) Color.argb(150, 94, 234, 212) else Color.argb(150, 217, 70, 239)
                c.drawRect(x.toFloat(), y.toFloat(), (x + 30 + rnd.nextInt(90)).toFloat(), (y + h).toFloat(), p)
            }
            return b
        }

        private fun glitchText(text: String, rnd: Random): String =
            text.map { ch -> if (ch.isDigit() && rnd.nextInt(3) == 0) GLITCH_CHARS[rnd.nextInt(GLITCH_CHARS.length)] else ch }.joinToString("")

        /** Смена минуты: несколько кадров глитча, потом чистые цифры. */
        fun glitchTick(ctx: Context, done: () -> Unit) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = ids(ctx)
            if (mgr == null || ids.isEmpty()) { done(); return }
            if (!AppPrefs(ctx).widgetGlitch) { render(ctx, mgr, ids); done(); return }
            val now = SimpleDateFormat("HH:mm", Locale.US).format(Date())
            val rnd = Random(System.nanoTime())
            val handler = Handler(Looper.getMainLooper())
            val frames = 4
            for (k in 0 until frames) {
                handler.postDelayed({
                    val v = RemoteViews(ctx.packageName, R.layout.widget_alarm)
                    v.setTextViewText(R.id.widget_time, glitchText(now, rnd))
                    v.setTextColor(R.id.widget_time, if (k % 2 == 0) Color.parseColor("#D946EF") else Color.parseColor("#5EEAD4"))
                    val dx = rnd.nextInt(-10, 11)
                    v.setViewPadding(R.id.widget_time, maxOf(0, dx), 0, maxOf(0, -dx), 0)
                    v.setImageViewBitmap(R.id.widget_glitch, glitchBars(rnd))
                    v.setViewVisibility(R.id.widget_glitch, View.VISIBLE)
                    for (id in ids) mgr.partiallyUpdateAppWidget(id, v)
                }, k * 75L)
            }
            handler.postDelayed({
                render(ctx, mgr, ids)
                done()
            }, frames * 75L + 40L)
        }

        /** Будильник на начало следующей минуты. RTC без пробуждения: при выключенном экране телефон не будится. */
        fun scheduleTick(ctx: Context) {
            if (ids(ctx).isEmpty()) return
            val am = ctx.getSystemService(AlarmManager::class.java)
            val cal = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val pi = tickIntent(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExact(AlarmManager.RTC, cal.timeInMillis, pi)
                else am.set(AlarmManager.RTC, cal.timeInMillis, pi)
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC, cal.timeInMillis, pi)
            }
        }

        fun cancelTick(ctx: Context) {
            ctx.getSystemService(AlarmManager::class.java).cancel(tickIntent(ctx))
        }

        private fun tickIntent(ctx: Context) = PendingIntent.getBroadcast(
            ctx, REQ_TICK, Intent(ctx, WidgetTickReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        private fun dayWord(at: Long, now: Long): String {
            val a = Calendar.getInstance().apply { timeInMillis = at }
            val n = Calendar.getInstance().apply { timeInMillis = now }
            val diff = (a.get(Calendar.YEAR) * 400 + a.get(Calendar.DAY_OF_YEAR)) - (n.get(Calendar.YEAR) * 400 + n.get(Calendar.DAY_OF_YEAR))
            return when (diff) {
                0 -> "сегодня"
                1 -> "завтра"
                else -> SimpleDateFormat("EEE d MMM", Locale("ru")).format(Date(at))
            }
        }
    }
}

/** Каждая минута: глитч на цифрах и следующая минута в очередь. */
class WidgetTickReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        AlarmWidget.scheduleTick(ctx)
        AlarmWidget.glitchTick(ctx) { pending.finish() }
    }
}
