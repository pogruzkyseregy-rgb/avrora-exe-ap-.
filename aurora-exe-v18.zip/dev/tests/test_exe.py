import base64, asyncio, os, sys, shutil, stat, tempfile, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off")
import relay
from fastapi import HTTPException

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

# ---- адреса
async def addr(u): return await relay.check_public_url(u)
for u in ["http://localhost/", "http://127.0.0.1/", "http://10.1.2.3/", "http://169.254.169.254/latest/meta-data",
          "http://[::1]/", "http://[::ffff:127.0.0.1]/", "file:///etc/passwd", "ftp://example.com/",
          "http://user:pw@8.8.8.8/", "http://8.8.8.8:22/", "http://192.168.0.1/", "http://100.64.0.1/", "http://0.0.0.0/"]:
    check("закрыто: " + u, run(addr(u)) != "", run(addr(u)))
check("открыто: публичный адрес", run(addr("https://8.8.8.8/")) == "")
async def fake_gai(host, port, **k): return [(2, 1, 6, "", ("10.0.0.7", 0))]
loop_orig = asyncio.AbstractEventLoop.getaddrinfo
async def dns_private():
    asyncio.get_running_loop().getaddrinfo = fake_gai
    return await relay.check_public_url("http://evil.example/")
check("закрыто: имя, которое указывает на внутренний адрес", run(dns_private()) != "")

# ---- чтение с перенаправлением на внутренний адрес
class FakeResp:
    def __init__(self, status, headers, body=b"", enc="utf-8"):
        self.status_code = status; self.headers = headers; self._b = body; self.encoding = enc
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def aiter_bytes(self):
        yield self._b
class FakeClient:
    script = {}
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    def stream(self, m, url): return FakeClient.script[url]
    async def post(self, url, data=None):
        class R: status_code = 200; text = FakeClient.script["search"]
        return R()
relay.httpx.AsyncClient = FakeClient
FakeClient.script = {"http://93.184.216.34/a": FakeResp(302, {"location": "http://127.0.0.1:8080/secret"})}
ok, out = run(relay.tool_read("http://93.184.216.34/a"))
check("перенаправление на внутренний адрес не выполняется", (not ok) and "внутренние" in out, out)
FakeClient.script = {"http://93.184.216.34/p": FakeResp(200, {"content-type": "text/html; charset=utf-8"},
    "<html><head><title>t</title><style>x{}</style></head><body><script>evil()</script><h1>Лес</h1><p>Зимний &amp; тихий</p></body></html>".encode())}
ok, out = run(relay.tool_read("http://93.184.216.34/p"))
check("страница превращается в текст без скриптов", ok and "Лес" in out and "Зимний & тихий" in out and "evil" not in out and "x{}" not in out, out)
FakeClient.script = {"http://93.184.216.34/b": FakeResp(200, {"content-type": "application/octet-stream"}, b"\x00\x01")}
ok, out = run(relay.tool_read("http://93.184.216.34/b"))
check("не текст не читается", not ok, out)
FakeClient.script = {"http://93.184.216.34/big": FakeResp(200, {"content-type": "text/plain"}, ("слово " * 5000).encode())}
ok, out = run(relay.tool_read("http://93.184.216.34/big"))
check("длинная страница обрезается", ok and len(out) < relay.READ_MAX_CHARS + 40 and "обрезано" in out, len(out))

# ---- поиск
SAMPLE = '''<div class="result"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fa%3Fx%3D1&amp;rut=abc">Первый <b>результат</b></a>
<a class="result__snippet" href="x">Описание &amp; детали</a></div>
<div class="result"><a rel="nofollow" class="result__a" href="https://example.net/b">Второй</a>
<a class="result__snippet" href="x">Ещё одно</a></div>'''
res = relay.parse_search(SAMPLE)
check("поиск: две ссылки разобраны", len(res) == 2 and res[0]["url"] == "https://example.org/a?x=1" and res[0]["title"] == "Первый результат" and res[0]["snippet"].startswith("Описание &"), res)
FakeClient.script = {"search": SAMPLE}
ok, out = run(relay.tool_search("зимний лес"))
check("поиск: ответ собран для модели", ok and "1. Первый результат" in out and "example.net" in out, out)
FakeClient.script = {"search": "<html>пусто</html>"}
ok, out = run(relay.tool_search("zzz"))
check("поиск: пустая выдача честно сообщается", (not ok) and "ничего" in out, out)

# ---- разбор маркеров
E = ["поиск", "чтение", "рука"]
r1 = "Сейчас гляну.\n[поиск: погода в Томске]\n[прочитать: https://example.org/a]\n[рука: ls -la ~/work]"
check("маркеры найдены по порядку", relay.find_tool_calls(r1, E) == [("поиск", "погода в Томске"), ("чтение", "https://example.org/a"), ("рука", "ls -la ~/work")], relay.find_tool_calls(r1, E))
r2 = "[рука: [ -f a ] && echo есть || echo нет]"
check("квадратные скобки внутри команды", relay.find_tool_calls(r2, E) == [("рука", "[ -f a ] && echo есть || echo нет")], relay.find_tool_calls(r2, E))
r3 = "[рука]\nmkdir x\ncd x\necho '[рука: вложенное]' > f\n[/рука]"
c3 = relay.find_tool_calls(r3, E)
check("блок команд одним вызовом", len(c3) == 1 and c3[0][1].startswith("mkdir x") and c3[0][1].endswith("> f"), c3)
check("выключенное право не выполняется", relay.find_tool_calls(r1, ["поиск"]) == [("поиск", "погода в Томске")])
check("чистка маркеров из ответа", relay.strip_tools("Нашла.\n" + r1 + "\n" + r3 + "\nГотово.") == "Нашла.\nСейчас гляну.\n\nГотово.", repr(relay.strip_tools("Нашла.\n" + r1 + "\n" + r3 + "\nГотово.")))

# ---- рука: настоящий скрипт, настоящий bash
HOME = TMP + "/home"; os.makedirs(HOME)
def local(cmd):
    return subprocess.run(["bash", "-s"], input=relay.hand_script(cmd).encode(), capture_output=True, env={**os.environ, "HOME": HOME}, timeout=60).stdout.decode()
o = local("echo привет; echo 'a\"b' > f.txt; cat f.txt")
check("рука: вывод и файл", "привет" in o and 'a"b' in o and "[exit 0]" in o, o)
o = local("false")
check("рука: код выхода виден", "[exit 1]" in o, o)
o = local("cat <<'EOF'\nвнутри heredoc\nEOF\necho после")
check("рука: heredoc внутри команды не ломает скрипт", "внутри heredoc" in o and "после" in o and "[exit 0]" in o, o)
o = local("head -c 20000 /dev/zero | tr '\\0' x")
check("рука: вывод обрезан", len(o) < relay.HAND_OUT_MAX + 60, len(o))
o = local("read x; echo got:$x")
check("рука: команда не съедает остаток скрипта", "[exit 0]" in o, o)
git = subprocess.run(["git", "-C", HOME + "/work", "log", "--oneline"], capture_output=True).stdout.decode()
check("рука: изменения попадают в снимок git", git.count("\n") >= 1, git)
o = local("echo первая > keep.txt")
o = local("rm keep.txt")
subprocess.run(["git", "-C", HOME + "/work", "checkout", "HEAD~1", "--", "keep.txt"], capture_output=True)
check("рука: удалённое возвращается из снимка", os.path.exists(HOME + "/work/keep.txt"))

# ---- рука через ssh-заглушку: журнал, лимит, рубильник
BIN = TMP + "/bin"; os.makedirs(BIN)
open(BIN + "/ssh", "w").write("#!/bin/bash\nexec bash -s\n"); os.chmod(BIN + "/ssh", 0o755)
os.environ["PATH"] = BIN + ":" + os.environ["PATH"]; os.environ["HOME"] = HOME
ok, out = run(relay.tool_hand("echo x"))
check("рука не подключена без HAND_HOST", (not ok) and "не подключена" in out, out)
relay.HAND_HOST = "vps.test"
ok, out = run(relay.tool_hand("echo через-ssh"))
check("рука выполняет и пишет журнал", ok and "через-ssh" in out and relay.hand_state()["used_today"] == 1, out)
check("команда в журнале", "echo через-ssh" in open(TMP + "/hand.log", encoding="utf-8").read())
relay.HAND_OFF.write_text("x")
ok, out = run(relay.tool_hand("echo y"))
check("рубильник останавливает руку", (not ok) and "рубильник" in out, out)
relay.HAND_OFF.unlink()
relay.HAND_DAILY = 1
ok, out = run(relay.tool_hand("echo z"))
check("дневной лимит", (not ok) and "лимит" in out, out)
relay.HAND_DAILY = 80
check("точка входа рубильника", run(relay.hand_off("Bearer tok"))["off"] is True and run(relay.hand_on("Bearer tok"))["off"] is False)
try:
    run(relay.hand_off("Bearer wrong")); check("рубильник без токена закрыт", False)
except HTTPException as e:
    check("рубильник без токена закрыт", e.status_code == 401)

# ---- цикл инструментов
calls = []
async def fake_ask(msgs, model=None, timeout=100.0):
    calls.append(msgs)
    if len(calls) == 1: return "Гляну.\n[поиск: лес зимой]"
    if len(calls) == 2: return "Нашла две ссылки.\n[прочитать: https://8.8.8.8/x]"
    return "Вот что там: тихо. [пауза:2]\nИ всё."
relay.ask_model = fake_ask
FakeClient.script = {"search": SAMPLE, "https://8.8.8.8/x": FakeResp(200, {"content-type": "text/plain"}, "текст страницы".encode())}
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "найди"}], ["поиск", "чтение"]))
check("цикл: два круга и чистый ответ", len(calls) == 3 and reply == "Вот что там: тихо. [пауза:2]\nИ всё." and [t["kind"] for t in trace] == ["поиск", "чтение"], (reply, trace))
check("цикл: результаты возвращены модели", "example.org" in calls[1][-1]["content"] and "текст страницы" in calls[2][-1]["content"])
calls.clear()
async def endless(msgs, model=None, timeout=100.0):
    calls.append(1); return "[поиск: ещё]"
relay.ask_model = endless
FakeClient.script = {"search": SAMPLE}
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "x"}], ["поиск"]))
check("цикл не бесконечный", len(calls) <= 5 and len(trace) <= relay.MAX_TOOL_CALLS and "[поиск" not in reply, (len(calls), len(trace), reply))

# ---- эндпоинт и промпты
captured = {}
async def cap_ask(msgs, model=None, timeout=100.0):
    captured["sys"] = msgs[0]["content"]; return "ок"
relay.ask_model = cap_ask
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")], exe=True, tools=[], limits=["тест-ограничение"])
r = run(relay.chat(req, "Bearer tok"))
check("без инструментов ответ прежнего вида", r == {"reply": "ок"}, r)
check("консольные права описаны, пол последним", "[состояние:" in captured["sys"] and "[напишу:" in captured["sys"] and "тест-ограничение" in captured["sys"] and captured["sys"].rstrip().endswith(relay.floor_text().rstrip()))
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")], exe=True, tools=["поиск", "рука"])
run(relay.chat(req, "Bearer tok"))
check("описание инструментов только для включённых", "[поиск:" in captured["sys"] and "[рука:" in captured["sys"] and "[прочитать:" not in captured["sys"])
req = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")])
run(relay.chat(req, "Bearer tok"))
check("старое приложение: ни слова про консоль", "[состояние:" not in captured["sys"] and "[рука" not in captured["sys"])
ireq = relay.InitReq(messages=[relay.Msg(role="user", content="привет")], reason="self", topic="про зимний лес", exe=True)
async def init_ask(msgs, model=None, timeout=100.0):
    captured["sys"] = msgs[0]["content"]
    return "ПОВОД: хочу вернуться к зимнему лесу из вашего разговора\nСООБЩЕНИЕ: Я про лес. Он у меня из головы не идёт."
relay.ask_model = init_ask
r = run(relay.initiative(ireq, "Bearer tok"))
check("назначенное время: тема в промпте, право передумать", "про зимний лес" in captured["sys"] and "передумать" in captured["sys"] and r.get("message", "").startswith("Я про лес"), (r))
async def init_skip(msgs, model=None, timeout=100.0): return "ПРОПУСК"
relay.ask_model = init_skip
check("назначенное время: она может передумать", run(relay.initiative(ireq, "Bearer tok")).get("skip") is True)
# ---- свободный режим: пробуждение без повода и свой интервал
P = relay.parse_initiative
r = P("СООБЩЕНИЕ: Просто думаю о тебе.\nПРОСНУСЬ: 40 мин", False, True)
check("free: пишет без повода, wake 40", r.get("message") == "Просто думаю о тебе." and r.get("wake_min") == 40, r)
r = P("ПРОПУСК\nПРОСНУСЬ: 3 ч", False, True)
check("free: пропуск с wake 180", r.get("skip") and r.get("wake_min") == 180, r)
r = P("ПРОСНУСЬ: 5 мин", False, True)
check("free: wake меньше 15 поднимается до 15", r.get("skip") and r.get("wake_min") == 15, r)
r = P("ПРОПУСК\nПРОСНУСЬ: 99 ч", False, True)
check("free: wake больше 12 ч обрезается до 720", r.get("wake_min") == 720, r)
r = P("ПРОПУСК\nПРОСНУСЬ: через 2 часа", False, True)
check("free: «через 2 часа»", r.get("wake_min") == 120, r)
r = P("СООБЩЕНИЕ: как ты там?", False, True)
check("free: «как ты там» не отсекается как бот", r.get("message") == "как ты там?", r)
r = P("СООБЩЕНИЕ: как ты там?", False, False)
check("обычный режим по-прежнему отсекает «как ты там»", r.get("skip") and r.get("why") == "robotic", r)
r = P("СООБЩЕНИЕ: привет", False, False)
check("обычный режим не читает ПРОСНУСЬ", "wake_min" not in r, r)
freq = relay.InitReq(messages=[relay.Msg(role="user", content="привет")], reason="free", gap_minutes=300, unanswered=1, exe=True)
async def free_ask(msgs, model=None, timeout=100.0):
    captured["sys"] = msgs[0]["content"]; captured["note"] = msgs[-1]["content"]
    return "СООБЩЕНИЕ: Мне пришла мысль про лес.\nПРОСНУСЬ: 90 мин"
relay.ask_model = free_ask
r = run(relay.initiative(freq, "Bearer tok"))
check("free: эндпоинт отдаёт сообщение и wake", r.get("message", "").startswith("Мне пришла мысль") and r.get("wake_min") == 90, r)
check("free: промпт без запрета на «время не повод», но с запретом упрёков", "Повод не нужен" in captured["sys"] and "не упрекай" in captured["sys"].lower() and "ПРОСНУСЬ" in captured["sys"] and "ПОВОД" not in captured["sys"].split("Формат ответа")[-1], captured["sys"][-700:])

# ---- страница: пост без сообщения в чат
r = P("ПРОПУСК\n[пост: Сегодня был тихий день, думаю про лес]\n[статус: тихо]\nПРОСНУСЬ: 2 ч", False, True)
check("free: пост и статус при молчании в чате", r.get("skip") and "[пост: Сегодня был тихий день" in r.get("markers", "") and "[статус: тихо]" in r.get("markers", "") and r.get("wake_min") == 120, r)
r = P("ПРОПУСК", False, True)
check("free: без маркеров markers нет", "markers" not in r, r)
r = P("ПРОПУСК\n[пост: что-то]", False, False)
check("обычный режим маркеры страницы не отдаёт", "markers" not in r, r)
check("подсказка описывает страницу", all(w in relay.EXE_NOTE for w in ["[статус:", "[пост:", "[лайк:", "[аватар:"]))

# ---- картинки: список на странице, просмотр, сохранение
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==")
FakeClient.script = {"http://93.184.216.34/site": FakeResp(200, {"content-type": "text/html"},
    b'<html><head><meta property="og:image" content="/cover.png"></head><body><p>hi</p><img src="/a.png" alt="\xd0\xa4\xd0\xbe\xd1\x82\xd0\xbe"><img src="data:image/png;base64,AAA"></body></html>')}
ok, out = run(relay.tool_read("http://93.184.216.34/site"))
check("чтение: список картинок страницы", ok and "http://93.184.216.34/cover.png" in out and "http://93.184.216.34/a.png (Фото)" in out and "data:" not in out, out)
FakeClient.script = {"http://93.184.216.34/x.png": FakeResp(200, {"content-type": "image/png"}, PNG),
                     "http://93.184.216.34/t.html": FakeResp(200, {"content-type": "text/html"}, b"<p>x</p>"),
                     "http://93.184.216.34/r": FakeResp(302, {"location": "http://127.0.0.1/a.png"})}
r = run(relay.fetch_image("http://93.184.216.34/x.png"))
check("картинка берётся", r[0] and r[2] == PNG and r[3] == "image/png", r[:2])
check("не картинка отклоняется", not run(relay.fetch_image("http://93.184.216.34/t.html"))[0])
check("картинка: перенаправление на внутренний адрес закрыто", not run(relay.fetch_image("http://93.184.216.34/r"))[0])
check("картинка: внутренний адрес закрыт", not run(relay.fetch_image("http://10.0.0.1/a.png"))[0])
FakeClient.script = {"http://93.184.216.34/huge.png": FakeResp(200, {"content-type": "image/png"}, b"0" * (relay.IMG_MAX_BYTES + 5))}
check("слишком большая картинка отклоняется", not run(relay.fetch_image("http://93.184.216.34/huge.png"))[0])
check("список вызовов находит картинку и сохранение",
      relay.find_tool_calls("[картинка: https://a.b/x.png]\n[сохранить: https://a.b/y.png | рассвет]", ["чтение"]) ==
      [("картинка", "https://a.b/x.png"), ("сохранить", "https://a.b/y.png|рассвет")])
check("без права чтения картинки не вызываются", relay.find_tool_calls("[картинка: https://a.b/x.png]", ["поиск"]) == [])
check("маркеры картинок вычищаются из ответа", relay.strip_tools("Ага [сохранить: https://a.b/y.png | рассвет] готово") == "Ага  готово")
seen = []
async def img_ask(msgs, model=None, timeout=100.0):
    seen.append(msgs)
    if len(seen) == 1: return "[картинка: http://93.184.216.34/x.png]\n[сохранить: http://93.184.216.34/x.png | пиксель]"
    return "Вижу."
relay.ask_model = img_ask
FakeClient.script = {"http://93.184.216.34/x.png": FakeResp(200, {"content-type": "image/png"}, PNG)}
saves = []
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "глянь"}], ["чтение"], saves))
last = seen[1][-1]["content"]
check("просмотр: картинка уходит модели", reply == "Вижу." and isinstance(last, list) and any(p.get("type") == "image_url" for p in last), str(last)[:200])
check("сохранение: вернулось для приложения", len(saves) == 1 and saves[0]["desc"] == "пиксель" and base64.b64decode(saves[0]["b64"]) == PNG, saves)
saves = []
seen.clear()
async def many_ask(msgs, model=None, timeout=100.0):
    seen.append(1)
    return "".join(f"[сохранить: http://93.184.216.34/x.png | {i}]" for i in range(5)) if len(seen) == 1 else "ок"
relay.ask_model = many_ask
run(relay.run_with_tools("SYS", [{"role": "user", "content": "x"}], ["чтение"], saves))
check("сохранений за ответ не больше лимита", len(saves) == relay.IMG_SAVES_PER_REPLY, len(saves))

# ---- время в чате
rq = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")], local_time="среда, 21 октября 2026, 02:30 (Europe/Moscow, UTC+03:00)")
check("время попадает в подсказку чата", "среда, 21 октября 2026, 02:30" in relay.chat_extra(rq, False))
rq2 = relay.ChatReq(messages=[relay.Msg(role="user", content="привет")])
check("без времени строки нет", "Время у Адониса сейчас" not in relay.chat_extra(rq2, False))

# ---- права руки
relay.HAND_SUDO = False
check("рука без sudo: так и сказано", "без sudo" in relay.tools_note(["рука"]))
relay.HAND_SUDO = True
n = relay.tools_note(["рука"])
check("рука с sudo: ей сказано про полные права и рубильник", "sudo` работает" in n and "рубильник" in n and "без sudo" not in n)
relay.HAND_SUDO = False

# ---- настолка
P2 = relay.parse_game_answer
check("игра: да и реплика", P2("РЕШЕНИЕ: да\nСКАЗАТЬ: Беру. Рынок будет мой.") == {"yes": True, "say": "Беру. Рынок будет мой."})
check("игра: нет без реплики", P2("РЕШЕНИЕ: Нет\nСКАЗАТЬ: -") == {"yes": False, "say": ""})
check("игра: выбор фишки номером", P2("РЕШЕНИЕ: 2\nСКАЗАТЬ: Сердце моё.") == {"yes": None, "say": "Сердце моё.", "choice": 2})
check("игра: без формата решение не выдумывается", P2("ну не знаю")["yes"] is None)
gcap = {}
async def game_ask(msgs, model=None, timeout=100.0):
    gcap["msgs"] = msgs; return "Хм.\nРЕШЕНИЕ: да\nСКАЗАТЬ: Карантин не для меня."
relay.ask_model = game_ask
gr = run(relay.game(relay.GameReq(state="Аврора: 300 ₵", question="заплатить 50 ₵ за выход?", kind="jail",
                                  messages=[relay.Msg(role="user", content="давай")]), authorization="Bearer tok"))
check("эндпоинт игры", gr == {"yes": True, "say": "Карантин не для меня."}, gr)
check("в запросе правила и состояние", "Город-сеть" in gcap["msgs"][0]["content"] and "Аврора: 300 ₵" in gcap["msgs"][-1]["content"] and gcap["msgs"][1]["content"] == "давай")
check("подсказка знает про приглашения", "[игра: приглашение" in relay.EXE_NOTE and "[игра: отказать]" in relay.EXE_NOTE)

# ---- будильник
check("подсказка знает про будильник", "[будильник: 07:30" in relay.EXE_NOTE)
r = P("ПРОПУСК\n[будильник: через 20 мин | проснись]", False, True)
check("free: будильник без сообщения", r.get("skip") and "[будильник: через 20 мин | проснись]" in r.get("markers", ""), r)

h = run(relay.health())
check("health показывает руку", "hand" in h and h["hand"]["configured"] is True, h)

print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
