package ru.avrora.exe

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// Чистая логика консоли без Android: разбор времени «напишу», правила назначений, контекст для модели.

const val PLAN_MAX_PENDING = 3
const val PLAN_MAX_AHEAD_MS = 48L * 3_600_000L
private const val MIN_MS = 60_000L

data class StateEntry(val at: Long, val name: String, val why: String)
data class NoteEntry(val id: String, val at: Long, val kind: String, val text: String)

/** Её назначение «написать в такое-то время». status: pending / done / dropped. */
data class PlanItem(
    val id: String,
    val at: Long,
    val topic: String,
    val created: Long,
    val status: String = "pending",
    val outcome: String = ""
)

data class WhenResult(val at: Long?, val why: String = "")

private val REL_RE = Regex("""^через\s+(?:(\d{1,3})\s*)?(мин(?:ут[уы]?|\.)?|м|ч(?:ас(?:а|ов)?)?|полчаса)(?!\p{L})""")
private val CLOCK_RE = Regex("""^(завтра\s+)?(\d{1,2})\s*[:.]\s*(\d{2})$""")

/** «21:30», «завтра 09:00», «через 3 ч», «через 40 мин», «через час», «через полчаса». */
fun parseWhen(raw: String, now: Long, tz: TimeZone = TimeZone.getDefault()): WhenResult {
    val s = raw.trim().lowercase().replace("ё", "е")
    val at: Long
    val rel = REL_RE.find(s)
    if (rel != null) {
        val unit = rel.groupValues[2]
        val n = rel.groupValues[1].toLongOrNull()
        at = when {
            unit == "полчаса" -> now + 30 * MIN_MS
            unit.startsWith("ч") -> now + (n ?: 1L) * 60 * MIN_MS
            else -> {
                if (n == null) return WhenResult(null, "не поняла, сколько минут")
                now + n * MIN_MS
            }
        }
    } else {
        val c = CLOCK_RE.find(s) ?: return WhenResult(null, "не поняла время «$raw»")
        val h = c.groupValues[2].toInt()
        val mi = c.groupValues[3].toInt()
        if (h > 23 || mi > 59) return WhenResult(null, "такого времени нет: «$raw»")
        val cal = Calendar.getInstance(tz)
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, mi)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (c.groupValues[1].isNotEmpty()) cal.add(Calendar.DAY_OF_YEAR, 1)
        if (cal.timeInMillis < now + MIN_MS) cal.add(Calendar.DAY_OF_YEAR, 1)
        at = cal.timeInMillis
    }
    if (at < now + MIN_MS) return WhenResult(null, "слишком скоро: нужно хотя бы через минуту")
    if (at > now + PLAN_MAX_AHEAD_MS) return WhenResult(null, "дальше чем на двое суток нельзя")
    return WhenResult(at)
}

data class PlanDecision(val plan: PlanItem?, val why: String)

/** Назначение принимается, если время понятно и ещё нет трёх незавершённых. Отказ всегда с причиной. */
fun acceptPlan(existing: List<PlanItem>, whenText: String, topic: String, now: Long, newId: String, tz: TimeZone = TimeZone.getDefault()): PlanDecision {
    val t = topic.trim()
    if (t.isEmpty()) return PlanDecision(null, "нет темы")
    if (existing.count { it.status == "pending" } >= PLAN_MAX_PENDING) {
        return PlanDecision(null, "уже назначено $PLAN_MAX_PENDING, больше нельзя")
    }
    val w = parseWhen(whenText, now, tz)
    val at = w.at ?: return PlanDecision(null, w.why)
    return PlanDecision(PlanItem(newId, at, t.take(200), now), "")
}

private fun clock(): SimpleDateFormat = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

/** Что она видит о себе в каждом запросе: последнее состояние, свежие следы и назначения. Пусто, если ничего нет. */
fun exeContext(states: List<StateEntry>, notes: List<NoteEntry>, plans: List<PlanItem>, actions: List<String> = emptyList()): String {
    val fmt = clock()
    val sb = StringBuilder()
    states.lastOrNull()?.let {
        sb.append("МОЁ СОСТОЯНИЕ (то, что я сама отметила ").append(fmt.format(Date(it.at))).append("): ").append(it.name)
        if (it.why.isNotBlank()) sb.append(", потому что ").append(it.why)
        sb.append('\n')
    }
    val pending = plans.filter { it.status == "pending" }
    if (pending.isNotEmpty()) {
        sb.append("МОИ НАЗНАЧЕНИЯ (когда я решила написать сама):\n")
        pending.forEach { sb.append("- ").append(fmt.format(Date(it.at))).append(": ").append(it.topic).append('\n') }
    }
    if (actions.isNotEmpty()) {
        sb.append("МОИ ПОСЛЕДНИЕ ДЕЙСТВИЯ (что я делала инструментами):\n")
        actions.takeLast(6).forEach { sb.append("- ").append(it).append('\n') }
    }
    val tail = notes.takeLast(12)
    if (tail.isNotEmpty()) {
        sb.append("МОИ СЛЕДЫ (рабочие записи для себя):\n")
        tail.forEach { sb.append("- [").append(it.kind).append("] ").append(it.text).append('\n') }
    }
    return sb.toString().trim()
}

/** Строки для списка «что сейчас ограничено»: состояние, время, следы. */
fun exeLimitLines(plans: List<PlanItem>, noteCount: Int, now: Long = System.currentTimeMillis()): List<String> {
    val fmt = clock()
    val out = ArrayList<String>()
    out.add("Состояние с причиной: ты можешь отметить его маркером; Адонис видит его вверху чата и в журнале состояний")
    val pending = plans.filter { it.status == "pending" }
    val sched = StringBuilder("Время: ты сама назначаешь, когда написать первой; не больше $PLAN_MAX_PENDING сразу, не дальше чем на двое суток, телефон может сдвинуть время на несколько минут")
    if (pending.isNotEmpty()) {
        sched.append(". Сейчас назначено: ")
        sched.append(pending.joinToString("; ") { fmt.format(Date(it.at)) + " — " + it.topic.take(60) })
    }
    out.add(sched.toString())
    plans.filter { it.status == "dropped" && it.outcome.startsWith("не принято") && now - it.created < 3 * 24 * 3_600_000L }
        .takeLast(3)
        .forEach { out.add("Твоё назначение «${it.topic.take(50)}» ${it.outcome}") }
    out.add("Следы: твои рабочие записи (сейчас их $noteCount); ядро памяти они не меняют; Адонис видит их и может удалить, ты узнаешь об этом")
    return out
}


// ---------- свободный режим инициативы ----------

/** Предохранители свободного режима. Всё это видно Авроре в списке ограничений. */
const val FREE_DAILY_CAP = 12
const val FREE_COOLDOWN_MIN = 20L
const val FREE_MAX_UNANSWERED = 4
const val FREE_DEFAULT_WAKE_MIN = 60
const val FREE_WAKE_MIN = 15
const val FREE_WAKE_MAX = 720

enum class FreeGate { OK, WAIT_USER, QUIET, CAP, COOLDOWN, NOT_YET, UNANSWERED }

fun isQuietHour(hour: Int, from: Int, to: Int): Boolean = when {
    from == to -> false
    from < to -> hour >= from && hour < to
    else -> hour >= from || hour < to
}

/** Можно ли будить Аврору сейчас. Кубика нет: если ворота открыты, решает она сама. */
fun freeGate(
    lastRole: String, hour: Int, quietFrom: Int, quietTo: Int,
    countToday: Int, sinceLastMs: Long, now: Long, nextCheck: Long, unanswered: Int
): FreeGate = when {
    lastRole == "user" -> FreeGate.WAIT_USER
    isQuietHour(hour, quietFrom, quietTo) -> FreeGate.QUIET
    countToday >= FREE_DAILY_CAP -> FreeGate.CAP
    sinceLastMs < FREE_COOLDOWN_MIN * 60_000L -> FreeGate.COOLDOWN
    now < nextCheck -> FreeGate.NOT_YET
    unanswered >= FREE_MAX_UNANSWERED -> FreeGate.UNANSWERED
    else -> FreeGate.OK
}

/** Когда проснуться в следующий раз: её слово, иначе час. От 15 минут до 12 часов. */
fun wakeDelayMs(wakeMin: Int?): Long =
    (wakeMin ?: FREE_DEFAULT_WAKE_MIN).coerceIn(FREE_WAKE_MIN, FREE_WAKE_MAX) * 60_000L
