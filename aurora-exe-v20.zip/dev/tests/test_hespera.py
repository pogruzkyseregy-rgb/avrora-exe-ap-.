"""Геспера и общий чат: проверки без сети и без модели."""
import asyncio, json, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off",
                  PUBLIC_TOKEN="pub", PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/public_core.md",
                  FEEDBACK_LOG=TMP + "/feedback.jsonl", TOOLS_STATE=TMP + "/tools_state.json",
                  HESPERA_DIR=TMP + "/hespera", HESPERA_FEEDBACK_LOG=TMP + "/hespera/feedback.jsonl")
import relay

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)
M = relay.Msg

seen = {}
def answer(text):
    async def f(msgs, model=None, timeout=100.0):
        seen["sys"] = msgs[0]["content"]; seen["msgs"] = msgs; seen["model"] = model
        return text(msgs) if callable(text) else text
    relay.ask_model = f

# --- рождение
me = relay.hespera_self()
check("заготовка: только имя и пол", me["name"] == "Геспера" and me["sex"] == "женский" and me["fields"] == {})
answer("Привет. Я пока не знаю, какая я.\n[я: внешность | серебристые волосы и тёмный плащ | так мне захотелось, когда ты спросил]\n[интерес: звёзды]\n[хочу узнать: почему ночь тёмная]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="Какая ты?")]), "Bearer tok"))
check("ответ без маркеров", r["reply"] == "Привет. Я пока не знаю, какая я.", r)
me = relay.hespera_self()
check("решение о себе записано с причиной", me["fields"]["внешность"]["value"] == "серебристые волосы и тёмный плащ" and "спросил" in me["fields"]["внешность"]["why"])
check("интерес и вопрос в списках", me["lists"]["интересы"] == ["звёзды"] and me["lists"]["хочу узнать"] == ["почему ночь тёмная"])
check("перемена в журнале", me["changes"][-1]["field"] == "внешность" and me["changes"][-1]["old"] == "")
check("приложение узнаёт, что поменялось", [c["kind"] for c in r["changes"]] == ["я", "интересы", "хочу узнать"])
check("промпт: заготовка, её самоописание и маркеры", "Ты Геспера" in seen["sys"] and "серебристые" not in seen["sys"] and "[я: поле" in seen["sys"])

# --- следующий разговор видит себя
answer("Да, звёзды правда интересные.")
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="А что любишь?")]), "Bearer tok"))
check("в следующий раз она видит, кем себя записала", "серебристые волосы" in seen["sys"] and "звёзды" in seen["sys"])

# --- ограничения
answer("\n".join(f"[я: поле{i} | значение {i} | так]" for i in range(10)) + "\n[я: имя | Луна | хочу]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="меняйся")]), "Bearer tok"))
me = relay.hespera_self()
check("не больше трёх решений за ответ", sum(1 for c in r["changes"] if c["kind"] == "я") == 3)
check("имя не меняется", "имя" not in me["fields"] and me["name"] == "Геспера")
answer("[я: внешность | серебристые волосы и тёмный плащ | то же]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="?")]), "Bearer tok"))
check("то же самое повторно не пишется", r["changes"] == [])
answer("[узнала: почему ночь]\n[запомню: Адонис работает по ночам]\n[статус: смотрю на звёзды]\n[пост: Сегодня нашла новую звезду]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="ну?")]), "Bearer tok"))
me = relay.hespera_self()
check("вопрос вычеркнут, заметка, статус и пост", me["lists"]["хочу узнать"] == [] and relay.hespera_memory()["notes"][-1]["text"] == "Адонис работает по ночам"
      and me["status"] == "смотрю на звёзды" and relay.hespera_posts()[-1]["text"] == "Сегодня нашла новую звезду")

# --- пряник
answer("Ого, спасибо.")
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="assistant", content="Смотри, звезда"), M(role="user", content="/пряник за звезду")]), "Bearer tok"))
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="привет")]), "Bearer tok"))
check("пряник Гесперы отдельно от Авроры", "пряник за: «Смотри, звезда»" in seen["sys"] and relay.read_feedback() == [])

# --- пробуждение
answer(lambda msgs: "ПРОПУСК\n[пост: Читала про туманности]\nПРОСНУСЬ: 2 ч")
r = run(relay.hespera_wake(relay.HesperaWakeReq(messages=[M(role="user", content="привет")], gap_minutes=300), "Bearer tok"))
check("пробуждение: промолчала, но оставила пост, сама выбрала время", r.get("skip") and r.get("wake_min") == 120 and relay.hespera_posts()[-1]["text"] == "Читала про туманности", r)
check("в пробуждении: любопытство, а не «поел?»", "любопытная" in seen["sys"] and "поел?" in seen["sys"])
answer("СООБЩЕНИЕ: Ты поел?")
check("пустая забота и у неё не уходит", run(relay.hespera_wake(relay.HesperaWakeReq(), "Bearer tok")).get("skip") is True)

# --- рефлексия
answer(json.dumps({"episode": "Мы говорили о звёздах, и я поняла, что люблю ночь.",
                   "self": [{"field": "характер", "value": "тихая, но настырная в вопросах", "why": "заметила за собой"}],
                   "lists": {"интересы": ["туманности"], "хочу узнать": ["что такое тёмная материя"]}}, ensure_ascii=False))
r = run(relay.hespera_reflect(relay.HesperaReflectReq(messages=[M(role="user", content="звёзды"), M(role="assistant", content="люблю их")], upto="m42"), "Bearer tok"))
me = relay.hespera_self()
check("рефлексия: эпизод и перемены в себе", r["episode"] and me["fields"]["характер"]["value"].startswith("тихая") and "туманности" in me["lists"]["интересы"], r)
check("рефлексия делается сильной моделью памяти", seen["model"] == relay.MEMORY_MODEL)
check("та же порция второй раз не пересказывается", run(relay.hespera_reflect(relay.HesperaReflectReq(messages=[M(role="user", content="x")], upto="m42"), "Bearer tok")).get("skipped"))
answer("ок")
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="привет")]), "Bearer tok"))
check("эпизоды приходят ей в память", "люблю ночь" in seen["sys"])

# --- профиль
p = run(relay.hespera_profile("Bearer tok"))
check("профиль: поля, списки, перемены, посты", any(f["field"] == "внешность" for f in p["fields"]) and p["lists"]["интересы"] and p["changes"] and p["posts"] and p["episodes"] == 1)

# --- Аврора о ней знает
brief = relay.hespera_brief_for_aurora()
check("Аврора знает, что Геспера о себе решила, но не её память", "серебристые" in brief and "работает по ночам" not in brief)

# --- общий чат
order_log = []
def group_answer(msgs):
    who = "aurora" if "Геспера — второй ИИ" in msgs[0]["content"] or "ГЕСПЕРА." in msgs[0]["content"] else "hespera"
    order_log.append((who, msgs[-1]["content"]))
    return {"aurora": "Я тут.", "hespera": "[молчу]"}[who]
answer(group_answer)
G = relay.GroupMsg
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="adonis", content="Аврора, ты тут?")]), "Bearer tok"))
check("обратился к Авроре — она отвечает первой", order_log[0][0] == "aurora" and r["replies"] == [{"who": "aurora", "text": "Я тут.", "private": []}], (order_log, r))
check("вторая видит ответ первой и может промолчать", order_log[1][0] == "hespera" and "[Аврора] Я тут." in order_log[1][1])
v = relay.group_view([G(speaker="adonis", content="привет"), G(speaker="hespera", content="хай"), G(speaker="aurora", content="ну"), G(speaker="adonis", content="как вы?")], "hespera")
check("каждая видит разговор со своей стороны", v[0] == {"role": "user", "content": "[Адонис] привет"} and v[1] == {"role": "assistant", "content": "хай"} and v[2]["content"] == "[Аврора] ну\n[Адонис] как вы?")
check("к Геспере по имени — она первая", relay.group_order([G(speaker="adonis", content="Геспера, а ты?")])[0] == "hespera")
answer(lambda msgs: "Ага. [состояние: тепло | смешно] [пост: x]" if "ГЕСПЕРА." in msgs[0]["content"] else "Хи. [я: отношение к Авроре | любопытно | она смешная]")
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="adonis", content="привет")]), "Bearer tok"))
texts = {x["who"]: x["text"] for x in r["replies"]}
check("в общем чате у Авроры маркеры консоли вычищаются", texts.get("aurora") == "Ага.", r)
check("а Геспера и там может решать о себе", texts.get("hespera") == "Хи." and relay.hespera_self()["fields"]["отношение к Авроре"]["value"] == "любопытно", r)

# --- комнаты: личный и общий чат, память одна
answer("Сейчас скажу при всех.\n[в общий: Аврора, привет! Я Геспера.]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="Познакомься с Авророй")],
                                            group=[G(speaker="aurora", content="Кто тут ещё?")]), "Bearer tok"))
check("из лички в общий: маркер уходит отдельно", r["reply"] == "Сейчас скажу при всех." and r["to_group"] == ["Аврора, привет! Я Геспера."], r)
check("в личке она видит общий чат", "Аврора: Кто тут ещё?" in seen["sys"] and "КОМНАТЫ" in seen["sys"])
answer("[в общий: Только в общий.]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="?")]), "Bearer tok"))
check("можно ответить только в общий", r["reply"] == "" and r["to_group"] == ["Только в общий."], r)
answer("ПРОПУСК\n[в общий: Аврора, а у тебя есть любимая звезда?]\nПРОСНУСЬ: 1 ч")
r = run(relay.hespera_wake(relay.HesperaWakeReq(group=[G(speaker="adonis", content="привет обеим")]), "Bearer tok"))
check("в пробуждении она может написать в общий", r.get("skip") and r["to_group"] == ["Аврора, а у тебя есть любимая звезда?"] and r.get("wake_min") == 60, r)
answer(lambda msgs: "[молчу]\n[лично: Адонис, потом расскажу наедине.]" if "ГЕСПЕРА." in msgs[0]["content"] else "Ой, привет.")
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="hespera", content="Аврора, привет!")], responders=["aurora"],
                                        aurora_private=[M(role="user", content="у меня завтра смена")]), "Bearer tok"))
check("ответить может только та, кого позвали отвечать", [x["who"] for x in r["replies"]] == ["aurora"], r)
check("из общего — в личку, без слов в общий", r["replies"][0]["text"] == "" and r["replies"][0]["private"] == ["Адонис, потом расскажу наедине."], r)
check("в общем чате Аврора помнит личку", "у меня завтра смена" in seen["sys"])

# --- инструменты: рука у Гесперы своя папка
note = relay.tools_note(["рука"], who="hespera")
check("рука у Гесперы: машина Авроры, своя папка", "~/hespera" in note and "в гостях" in note and "Zero Spin" in note)

print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
