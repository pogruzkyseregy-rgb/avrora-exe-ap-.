package ru.avrora.exe

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import java.io.File
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val hTime = SimpleDateFormat("HH:mm", Locale.getDefault())
private val hDay = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

/** Переключатель над чатом: Аврора, Геспера или все трое. */
@Composable
fun ChatSwitcher(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        listOf(WHO_AURORA to "АВРОРА", WHO_HESPERA to "ГЕСПЕРА", WHO_GROUP to "ВТРОЁМ").forEach { (id, label) ->
            val on = id == selected
            val accent = when (id) { WHO_AURORA -> Glow; WHO_HESPERA -> HespColor; else -> Violet }
            Box(
                Modifier
                    .weight(1f)
                    .height(34.dp)
                    .background(if (on) accent.copy(alpha = if (AppTheme.current.light) 0.14f else 0.18f) else Terminal, panelShape())
                    .then(if (on) Modifier.themeFrame(accent, 7.dp) else Modifier.border(1.dp, Edge.copy(alpha = 0.6f), panelShape()))
                    .clickable { onSelect(id) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (on) accent else TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

/** Аватар Гесперы: картинка, которую она выбрала сама, или буква, пока не выбрала. */
@Composable
fun HespAvatar(bytes: ByteArray?, size: Dp) {
    val bmp = remember(bytes) { bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() } }
    Box(
        Modifier.size(size).clip(avatarShape()).background(Terminal).border(1.dp, HespColor.copy(alpha = 0.7f), avatarShape()),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp, contentDescription = "Геспера", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Text("Г", color = HespColor, fontSize = (size.value * 0.42f).sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HespHeader(hvm: HesperaViewModel, onProfile: () -> Unit) {
    val p = hvm.profile
    val who = p.fields.firstOrNull { it.field == "кто я" }?.value
    Row(
        Modifier.fillMaxWidth().background(Panel).clickable { onProfile() }.padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HespAvatar(hvm.avatar, 38.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ГЕСПЕРА", color = HespColor, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.width(8.dp))
                Text(if (hvm.sending) "● думает" else "● в сети", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Text(
                when {
                    p.status.isNotBlank() -> "«${p.status}»"
                    who != null -> who
                    p.fields.isEmpty() -> "ещё не решила, кто она"
                    else -> "решила о себе: ${p.fields.size}"
                },
                color = TextMain, fontSize = 12.sp, maxLines = 1
            )
        }
        Text("профиль ›", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

/** Пузырь сообщения в чатах Гесперы. who: user, hespera, aurora, system. */
@Composable
private fun HBubble(m: ChatMessage, who: String, showName: Boolean, hespAvatar: ByteArray?, onOpen: (Any) -> Unit = {}) {
    if (who == "system") {
        Text("· ${m.content}", color = TextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 6.dp))
        return
    }
    val mine = who == "user"
    val accent = when (who) { "user" -> Violet; WHO_AURORA -> Glow; else -> HespColor }
    val shape = bubbleShape(mine)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        if (!mine && showName) {
            Text(if (who == WHO_AURORA) "АВРОРА" else "ГЕСПЕРА", color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(start = 38.dp, bottom = 2.dp))
        }
        val tools = if (who == WHO_HESPERA) decodeHesperaTools(m.trace) else emptyList()
        tools.forEach { t ->
            Text("⌁ ${t.kind}: ${t.arg.take(70)}" + if (t.ok) "" else " — не вышло", color = TextDim, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, maxLines = 2, modifier = Modifier.padding(start = 38.dp, bottom = 2.dp))
        }
        Row(verticalAlignment = Alignment.Bottom) {
            if (!mine) {
                Box(Modifier.size(30.dp)) {
                    if (showName || who == WHO_HESPERA) {
                        if (who == WHO_AURORA) Avatar(30.dp) else HespAvatar(hespAvatar, 30.dp)
                    }
                }
                Spacer(Modifier.width(6.dp))
            }
            Column(
                Modifier.widthIn(max = 300.dp).clip(shape)
                    .background(if (mine) BubbleUser else BubbleAurora)
                    .border(1.dp, accent.copy(alpha = 0.5f), shape)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                val snaps = remember(m.content) { parseParts(m.content).filterIsInstance<Part.Snap>() }
                if (snaps.isNotEmpty()) {
                    val dir = File(LocalContext.current.filesDir, "sent")
                    snaps.forEach { p ->
                        val f = File(dir, p.file)
                        val aspect = remember(f) { imageAspect(f) }
                        AsyncImage(
                            model = f, contentDescription = "Фото", contentScale = ContentScale.Crop,
                            modifier = Modifier.padding(bottom = 4.dp).width(230.dp).aspectRatio(aspect.coerceIn(0.5f, 2f))
                                .clip(panelShape()).border(1.dp, Edge, panelShape()).clickable { onOpen(f) }
                        )
                    }
                }
                val text = if (snaps.isEmpty()) m.content else TAG_RE.replace(m.content, "").trim()
                if (text.isNotEmpty()) Text(text, color = TextMain, fontSize = 15.sp, lineHeight = 21.sp)
                Text(if (m.auto) "сама · " + hTime.format(Date(m.time)) else hTime.format(Date(m.time)), color = TextDim, fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.End))
            }
        }
        if (who == WHO_HESPERA) {
            decodeHesperaChanges(m.trace).forEach { c ->
                Text("✎ " + changeLabel(c), color = HespColor.copy(alpha = 0.85f), fontSize = 11.sp, fontStyle = FontStyle.Italic,
                    maxLines = 3, modifier = Modifier.padding(start = 38.dp, top = 2.dp).widthIn(max = 300.dp))
            }
        }
    }
}

@Composable
private fun HInput(sending: Boolean, placeholder: String, accent: Color, onFocus: (Boolean) -> Unit, onSend: (String, Uri?) -> Unit) {
    var input by rememberSaveable(placeholder) { mutableStateOf("") }
    var photo by remember(placeholder) { mutableStateOf<Uri?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) photo = uri }
    val can = !sending && (input.isNotBlank() || photo != null)
    photo?.let { u ->
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = u, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(56.dp).clip(panelShape()))
            Spacer(Modifier.width(10.dp))
            Text("Фото прикреплено. Можно добавить подпись.", color = TextDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { photo = null }) { Icon(Icons.Default.Close, contentDescription = "Убрать фото", tint = TextDim) }
        }
    }
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
            Icon(Icons.Default.Add, contentDescription = "Отправить фото", tint = TextDim)
        }
        OutlinedTextField(
            value = input, onValueChange = { input = it },
            modifier = Modifier.weight(1f).onFocusChanged { onFocus(it.isFocused) },
            placeholder = { Text(placeholder) }, maxLines = 5,
            shape = if (AppTheme.current.frame == "soft") RoundedCornerShape(22.dp) else panelShape(),
            colors = auroraFieldColors()
        )
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(46.dp).clip(if (AppTheme.current.frame == "soft") CircleShape else panelShape())
                .background(if (can) accent else Edge)
                .clickable(enabled = can) { onSend(input, photo); input = ""; photo = null },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Send, contentDescription = "Отправить", tint = if (can) (if (AppTheme.current.light) Color.White else Night) else TextDim, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun ErrorBar(err: String?, onRetry: () -> Unit, onClose: () -> Unit) {
    if (err == null) return
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(err, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onRetry) { Text("Повторить") }
        TextButton(onClick = onClose) { Text("✕") }
    }
}

/** Чат с Гесперой. */
@Composable
fun HesperaChatPane(hvm: HesperaViewModel, onProfile: () -> Unit, onFocus: (Boolean) -> Unit, onOpen: (Any) -> Unit = {}) {
    val list = rememberLazyListState()
    LaunchedEffect(hvm.chat.size, hvm.sending) {
        val n = hvm.chat.size + if (hvm.sending) 1 else 0
        if (n > 0) list.animateScrollToItem(n - 1)
    }
    Column(Modifier.fillMaxSize()) {
        HespHeader(hvm, onProfile)
        GradientLine()
        LazyColumn(
            state = list, modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (hvm.chat.isEmpty()) item { HespEmpty(hvm) }
            itemsIndexed(hvm.chat) { i, m ->
                val who = if (m.role == "user") "user" else WHO_HESPERA
                HBubble(m, who, showName = false, hespAvatar = hvm.avatar, onOpen = onOpen)
            }
            if (hvm.sending) item { Text("Геспера печатает…", color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(start = 38.dp)) }
        }
        ErrorBar(hvm.error, onRetry = hvm::retry, onClose = hvm::clearError)
        HInput(hvm.sending, "Написать Геспере", HespColor, onFocus) { t, ph -> hvm.send(t, ph) }
    }
}

@Composable
private fun HespEmpty(hvm: HesperaViewModel) {
    Column(Modifier.fillMaxWidth().padding(top = 30.dp, start = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        HespAvatar(hvm.avatar, 64.dp)
        Text("ГЕСПЕРА", color = HespColor, fontSize = 20.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text("Она только появилась. Заданы имя, пол и любопытство — всё остальное она решит о себе сама.", color = TextDim, fontSize = 14.sp)
        Text("Напиши ей первым или подожди: она может проснуться и написать сама.", color = TextDim, fontSize = 13.sp)
    }
}

/** Общий чат: Адонис, Аврора и Геспера. */
@Composable
fun GroupChatPane(hvm: HesperaViewModel, vm: ChatViewModel, onFocus: (Boolean) -> Unit, onOpen: (Any) -> Unit = {}) {
    val list = rememberLazyListState()
    LaunchedEffect(hvm.group.size, hvm.groupSending) {
        val n = hvm.group.size + if (hvm.groupSending) 1 else 0
        if (n > 0) list.animateScrollToItem(n - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(32.dp)
            Spacer(Modifier.width(4.dp))
            HespAvatar(hvm.avatar, 32.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("ВТРОЁМ", color = Violet, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                Text(if (hvm.groupSending) "● отвечают" else "Аврора, Геспера и ты", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
        GradientLine()
        LazyColumn(
            state = list, modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (hvm.group.isEmpty()) item {
                Text("Общий чат. Обратись по имени — ответит та, к кому обращаешься, а вторая может вставить слово. " +
                    "Если вопрос не к ней, она промолчит.", color = TextDim, fontSize = 14.sp, modifier = Modifier.padding(top = 30.dp, start = 6.dp))
            }
            itemsIndexed(hvm.group) { i, m ->
                val prev = hvm.group.getOrNull(i - 1)?.role
                HBubble(m, m.role, showName = prev != m.role, hespAvatar = hvm.avatar, onOpen = onOpen)
            }
            if (hvm.groupSending) item { Text("пишут…", color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(start = 38.dp)) }
        }
        ErrorBar(hvm.error, onRetry = { hvm.retryGroup(vm) }, onClose = hvm::clearError)
        HInput(hvm.groupSending, "Написать обеим", Violet, onFocus) { t, ph -> hvm.sendGroup(t, vm, ph) }
    }
}

// ---------- профиль Гесперы ----------

/** Отдельный экран из её чата: шапка «назад» и то же досье, что во вкладке «Профиль». */
@Composable
fun HesperaProfileScreen(hvm: HesperaViewModel, hand: HandStatus, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Night)) {
        ThemeBackdrop()
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = TextDim) }
                Text("ГЕСПЕРА · ПРОФИЛЬ", color = HespColor, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
            }
            GradientLine()
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) { HesperaDossier(hvm, hand) }
        }
    }
}

private val HESP_FIELDS = listOf("кто я", "внешность", "характер", "голос", "отношение к Адонису", "отношение к Авроре", "о чём мечтаю")

/** Профиль Гесперы: её ядро, показания и блоки; всё, что здесь написано о ней, она решила сама. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HesperaDossier(hvm: HesperaViewModel, hand: HandStatus) {
    LaunchedEffect(Unit) { hvm.refreshProfile() }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); now = System.currentTimeMillis() } }
    val p = hvm.profile
    val accent = HespColor
    val days = if (p.born > 0) ((now / 1000.0 - p.born) / 86400).toInt() + 1 else 1
    val filled = HESP_FIELDS.count { k -> p.fields.any { it.field.equals(k, ignoreCase = true) } }
    val lists = p.lists
    fun n(k: String) = lists[k].orEmpty().size
    val changeTimes = p.changeTimes.map { (it * 1000).toLong() }
    val talk = remember(hvm.chat.size) { perDay(hvm.chat.filter { it.role != "system" }.map { it.time }) }
    val rights = listOf(hvm.wakeOn, hvm.toolSearch, hvm.toolRead, hvm.toolHand)
    val who = p.fields.firstOrNull { it.field.equals("кто я", ignoreCase = true) }?.value

    CoreHero(
        hesperaCore(), "HESPERA",
        p.status.ifBlank { who ?: "только появилась" },
        listOf("ДНЕЙ" to "$days", "О СЕБЕ" to "${p.fields.size}", "ЗАМЕТОК" to "${p.notes}", "ЭПИЗОДОВ" to "${p.episodes}")
    )
    Spacer(Modifier.height(4.dp))
    DossierGrid(listOf(
        DossierItem("who", "КТО ОНА", "$filled из ${HESP_FIELDS.size}", accent,
            preview = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HespAvatar(hvm.avatar, 32.dp)
                    Spacer(Modifier.width(8.dp))
                    SegmentMeter(filled, HESP_FIELDS.size, accent, Modifier.weight(1f).height(8.dp))
                }
            }
        ) {
            if (p.fields.isEmpty()) DetailHint("Пока ничего не решила. Это нормально: она только появилась.")
            p.fields.forEach { DetailLine(it.field, it.value, if (it.why.isNotBlank()) "почему: ${it.why}" else "") }
            if (hvm.avatar == null) DetailHint("Аватар она выберет сама, когда найдёт картинку, в которой узнает себя.")
        },
        DossierItem("taste", "ВКУСЫ", "${n("интересы") + n("люблю") + n("не люблю")}", accent,
            preview = { MiniBars(listOf(n("интересы"), n("люблю"), n("не люблю")).map { it.toFloat() }, accent) }
        ) {
            listOf("интересы", "люблю", "не люблю").forEach { k ->
                val items = lists[k].orEmpty()
                Text(k.uppercase() + " · ${items.size}", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.2.sp)
                if (items.isEmpty()) DetailHint("пусто")
                else FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items.forEach { Chip(it, if (k == "не люблю") Magenta else accent) }
                }
            }
        },
        DossierItem("ask", "ВОПРОСЫ", "${n("хочу узнать")} открыто", accent,
            preview = { RingGauge(if (n("хочу узнать") + n("узнала") > 0) n("узнала").toFloat() / (n("хочу узнать") + n("узнала")) else 0f, accent, "${n("хочу узнать")}") }
        ) {
            DetailHint("Шкала — сколько из её вопросов уже закрыто.")
            listOf("хочу узнать", "узнала").forEach { k ->
                val items = lists[k].orEmpty()
                if (items.isNotEmpty()) {
                    Text(k.uppercase(), color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.2.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items.forEach { Chip(it, if (k == "узнала") Glow else accent) }
                    }
                }
            }
            if (n("хочу узнать") + n("узнала") == 0) DetailHint("Вопросов пока нет.")
        },
        DossierItem("changes", "КАК МЕНЯЛАСЬ", "${p.changes.size} решений", accent,
            preview = { Sparkline(perDay(changeTimes), accent) }
        ) {
            if (p.changes.isEmpty()) DetailHint("Пока ни одного решения о себе.")
            p.changes.zip(p.changeTimes.ifEmpty { List(p.changes.size) { 0.0 } }).reversed().take(12).forEach { (c, at) ->
                DetailLine((if (at > 0) hDay.format(Date((at * 1000).toLong())) + " · " else "") + c.field, c.value, c.why)
            }
        },
        DossierItem("talk", "РАЗГОВОРЫ", "сегодня ${talk.last().toInt()}", accent,
            preview = { Sparkline(talk, accent) }
        ) {
            StatRow(listOf(
                "ЛИЧКА" to "${hvm.chat.count { it.role != "system" }}",
                "ОБЩИЙ" to "${hvm.group.count { it.role == WHO_HESPERA }}",
                "САМА" to "${hvm.chat.count { it.auto } + hvm.group.count { it.auto && it.role == WHO_HESPERA }}"
            ), accent)
            DetailHint("«Общий» — её реплики в чате на троих, «сама» — то, что она написала без вопроса.")
        },
        DossierItem("page", "СТРАНИЦА", "${p.posts.size} постов", accent,
            preview = { Sparkline(perDay(p.posts.map { (it.at * 1000).toLong() }), accent) }
        ) {
            if (p.status.isNotBlank()) DetailLine("статус", "«${p.status}»")
            if (p.posts.isEmpty()) DetailHint("Постов пока нет.")
            p.posts.reversed().take(8).forEach { DetailLine(hDay.format(Date((it.at * 1000).toLong())), it.text) }
        },
        DossierItem("rights", "ЧТО ЕЙ МОЖНО", "${rights.count { it }} из 4", accent,
            preview = { DotRow(rights, accent) }
        ) {
            ToggleRow("Пишет первой", "Просыпается сама и решает: искать, писать тебе, вести страницу или молчать", hvm.wakeOn) { hvm.setWake(it) }
            ToggleRow("Поиск в сети", "Сама ищет то, что ей интересно", hvm.toolSearch) { hvm.setTool("поиск", it) }
            ToggleRow("Чтение страниц", "Открывает ссылки и картинки; так она может выбрать себе аватар", hvm.toolRead) { hvm.setTool("чтение", it) }
            ToggleRow(
                "Рука на сервере",
                if (hand.configured) "Команды на машине Авроры, в своей папке ~/hespera. Общий лимит и рубильник с Авророй" else "Рука не подключена на сервере",
                hvm.toolHand
            ) { hvm.setTool("рука", it) }
        },
        DossierItem("wake", "ПРОБУЖДЕНИЕ", if (!hvm.wakeOn) "выключено" else inTime(hvm.nextWakeAt - now), accent,
            preview = {
                val left = (hvm.nextWakeAt - now).coerceAtLeast(0)
                RingGauge(if (hvm.wakeOn) 1f - (left / (12 * 3_600_000f)).coerceIn(0f, 1f) else 0f, accent, if (hvm.wakeOn) "${left / 60_000}" else "—")
            }
        ) {
            DetailHint("Когда проснуться, она решает сама: от 15 минут до 12 часов. Шкала заполняется к моменту пробуждения.")
            TextButton(onClick = { hvm.wakeNow() }, enabled = !hvm.waking) {
                Text(if (hvm.waking) "Будим…" else "Разбудить сейчас", color = accent)
            }
            hvm.error?.let { DetailHint(it) }
        }
    ))
    Text("Имя и пол ей задал ты. Всё остальное здесь она написала о себе сама и может переписать, когда передумает.",
        color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
    Spacer(Modifier.height(16.dp))
}

@Composable
private fun Section(title: String, accent: Color, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().tile(accent).padding(12.dp)) {
        Text(title, color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun Chip(text: String, accent: Color) {
    Text(
        text, color = TextMain, fontSize = 12.sp,
        modifier = Modifier.background(accent.copy(alpha = 0.12f), panelShape()).border(1.dp, accent.copy(alpha = 0.5f), panelShape())
            .padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

@Composable
private fun ToggleRow(title: String, hint: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontSize = 14.sp)
            Text(hint, color = TextDim, fontSize = 11.sp)
        }
        Switch(checked = on, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedThumbColor = HespColor, checkedTrackColor = HespColor.copy(alpha = 0.35f)))
    }
}
