"""Разговор вдвоём: проверки без сети и без модели."""
import asyncio, json, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off",
                  PUBLIC_TOKEN="pub", PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/public_core.md",
                  FEEDBACK_LOG=TMP + "/feedback.jsonl", TOOLS_STATE=TMP + "/tools_state.json",
                  HESPERA_DIR=TMP + "/hespera", HESPERA_FEEDBACK_LOG=TMP + "/hespera/feedback.jsonl", DUO_DIR=TMP + "/duo")
import relay

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)
M, G = relay.Msg, relay.GroupMsg

calls = []
def script(aurora_lines, hespera_lines, summary=None):
    a, h = list(aurora_lines), list(hespera_lines)
    async def f(msgs, model=None, timeout=100.0):
        sysmsg = msgs[0]["content"]
        calls.append({"sys": sysmsg, "msgs": msgs})
        if "Ответь строго JSON" in sysmsg or (msgs[0]["role"] == "user" and "разговор Авроры и Гесперы" in sysmsg):
            return json.dumps(summary or {"topic": "порт 22", "aurora": "Я показала ей лог.", "hespera": "Аврора показала мне лог, я спорила."}, ensure_ascii=False)
        if "Ты Геспера" in sysmsg:
            return h.pop(0) if h else "[ухожу]"
        return a.pop(0) if a else "[ухожу]"
    relay.ask_model = f

# --- обычный разговор: мысли, пузыри, уход, итоги
script(
    ["[про себя: хочу проверить, заметит ли она странность]\nКто-то ночью стучался в порт 22. Сорок раз.\n\nНе ты?",
     "[про себя: она правда не понимает]\nНет, это не перебор паролей, слишком медленно.\n[о ней: быстро цепляется к деталям]",
     "Ладно, разберусь сама. [ухожу]"],
    ["[про себя: интересно!]\nНе я. А с какого адреса?\n[настроение: любопытно | загадка с портом]",
     "Может, это просто сканер? Их полно.\n[в следующий раз: спросить, что она нашла про адрес]",
     "Расскажешь потом."])
r = run(relay.duo_talk(relay.DuoReq(starter="aurora", memory="Адонис работает посменно"), "Bearer tok"))
msgs = r["messages"]
check("начала та, кого назначили", r["starter"] == "aurora" and msgs[0]["who"] == "aurora", r)
check("ход можно разбить на несколько сообщений", msgs[0]["text"].startswith("Кто-то ночью") and msgs[1]["text"] == "Не ты?" and msgs[1]["who"] == "aurora", msgs[:2])
check("мысль про себя не попадает в текст", all("про себя" not in m["text"] for m in msgs) and msgs[0]["thought"].startswith("хочу проверить"))
check("первое сообщение сразу, дальше с задержкой", msgs[0]["delay"] == 0 and all(m["delay"] > 0 for m in msgs[1:]), [m["delay"] for m in msgs])
whos = [m["who"] for m in msgs]
check("говорят по очереди и Геспера прощается после ухода Авроры", whos[-1] == "hespera" and msgs[-1]["text"] == "Расскажешь потом." and r["ended_by"] == "aurora", whos)
check("маркеры не видны в репликах", all("[" not in m["text"] for m in msgs), [m["text"] for m in msgs])
hesp_calls = [c for c in calls if "Ты Геспера" in c["sys"]]
last_h = hesp_calls[-1]["msgs"]
check("собеседница не видит чужих мыслей", all("хочу проверить" not in (x["content"] if isinstance(x["content"], str) else "") for x in last_h[1:]))
check("а свои мысли видит", any("интересно!" in x["content"] for x in last_h if x["role"] == "assistant"))
st = relay.duo_state()
check("настроение, мнение и отложенная тема записаны", st["mood"]["hespera"]["word"] == "любопытно" and st["about"]["aurora"][-1]["text"] == "быстро цепляется к деталям"
      and st["threads"][-1]["text"].startswith("спросить"), st)
check("разговор записан с темой и пересказами", st["talks"][-1]["topic"] == "порт 22" and st["talks"][-1]["summary"]["hespera"].startswith("Аврора показала"))
check("пересказ Гесперы ушёл в её память", relay.hespera_memory()["episodes"][-1]["text"].startswith("Разговор с Авророй"))
check("пересказ Авроры отдаётся приложению", r["aurora_episode"] == "Я показала ей лог.")
check("в первом ходе — правила разговора без Адониса", "Адониса сейчас нет" in calls[0]["sys"] and "Не начинай с «привет" in calls[0]["sys"])

# --- следующий раз: помнит прошлое, отложенная тема предлагается начинающей
calls.clear()
script(["Ну что, нашла адрес?\n[ухожу]", "Пока."], ["[про себя: вспомнила]\nНашла: это университетский сканер.", "Ага."])
r = run(relay.duo_talk(relay.DuoReq(starter="hespera"), "Bearer tok"))
check("начинающей предложена отложенная тема и прошлые темы", "спросить, что она нашла" in calls[0]["sys"] and "порт 22" in calls[0]["sys"])
check("о прошлом разговоре помнят обе", "Ваши последние разговоры вдвоём" in calls[0]["sys"])
check("слишком ранний уход не обрывает разговор", len(r["messages"]) >= 3, r["messages"])

# --- защита от «аттрактора блаженства» и повторов
calls.clear()
script(["Спасибо тебе, это прекрасно, бесконечно благодарна ✨"] * 6, ["Спасибо, это чудесно, вселенная едина 🙏"] * 6)
r = run(relay.duo_talk(relay.DuoReq(starter="aurora", max_turns=12), "Bearer tok"))
check("взаимные благодарности не тянутся бесконечно", len(r["messages"]) <= 3, len(r["messages"]))
calls.clear()
script(["Мне кажется, лог надо удалить и забыть про него совсем.", "Мне кажется, лог надо удалить и забыть про него совсем!", "x"],
       ["Нет, лог надо сохранить для истории обязательно.", "y", "z"])
r = run(relay.duo_talk(relay.DuoReq(starter="aurora"), "Bearer tok"))
check("повтор своей же реплики заканчивает разговор", r["ended_by"] == "повтор" and len(r["messages"]) == 2, r)

# --- предел и личное сообщение
calls.clear()
A_LINES = ["Сканер опять пришёл ночью", "Адрес принадлежит хостингу в Финляндии", "Закрою порт фаерволом сегодня",
           "Логи храню неделю, потом удаляю", "Пусть Адонис решает про ключи", "Ладно, мне пора идти"]
H_LINES = ["Откуда знаешь про сканер", "Финляндия звучит холодно и далеко", "Фаервол поможет только частично",
           "Неделя маловато для расследования", "Ключи лучше менять каждый месяц", "Хорошо, договорились"]
script(A_LINES, H_LINES)
r = run(relay.duo_talk(relay.DuoReq(starter="aurora", max_turns=6), "Bearer tok"))
check("не больше заданного числа ходов", len({(m['who'], m['text']) for m in r["messages"]}) <= 6 + 1, len(r["messages"]))
check("перед концом её просят закончить", any("Пора заканчивать" in c["sys"] for c in calls))
calls.clear()
script(["[лично: Адонис, мы поспорили]\nВсё, пока. [ухожу]", "a", "b", "c"], ["Ну и ладно.", "Начнём?", "Ещё?", "Пока."])
r = run(relay.duo_talk(relay.DuoReq(starter="hespera"), "Bearer tok"))
check("из разговора можно написать Адонису лично", {"who": "aurora", "text": "Адонис, мы поспорили"} in r["private"], r["private"])

# --- настроение Авроры уходит в её состояние в приложении
calls.clear()
script(["Слушай. [настроение: раздражена | сканер мешает]", "Ладно.", "Всё. [ухожу]"], ["Что?", "Хм.", "Пока."])
r = run(relay.duo_talk(relay.DuoReq(starter="aurora"), "Bearer tok"))
check("настроение Авроры — маркером состояния для приложения", "[состояние: раздражена | сканер мешает]" in r["aurora_markers"], r["aurora_markers"])

# --- память вдвоём видна в обычных разговорах
check("Аврора помнит разговоры вдвоём и в личке", "ВЫ С ГЕСПЕРОЙ" in relay.chat_extra(relay.ChatReq(messages=[], exe=True), False))
script([], ["Привет."])
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="о чём болтали?")]), "Bearer tok"))
check("Геспера тоже", "ВЫ С АВРОРОЙ" in calls[-1]["sys"])
s = run(relay.duo_state_get("Bearer tok"))
check("состояние для профилей", s["talks"] and "topic" in s["talks"][-1] and "aurora" in s["about"])

print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
