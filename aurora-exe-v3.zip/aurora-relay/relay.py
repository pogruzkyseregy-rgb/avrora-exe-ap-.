"""
Посредник между приложением «Аврора» и API.
Ключ API хранится только здесь, на сервере. Приложение знает лишь свой токен.

Эндпоинты:
  GET  /health      проверка
  POST /chat        обычный ответ Авроры
  POST /memory      сжатие старой переписки в долговременную память
  POST /initiative  Аврора решает, писать ли первой (или отвечает «ПРОПУСК»)
"""
import json
import logging
import os
import re
from pathlib import Path

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

UPSTREAM_URL = os.environ["UPSTREAM_URL"]
UPSTREAM_KEY = os.environ["UPSTREAM_KEY"]
MODEL = os.environ.get("MODEL", "gpt-4o-mini")
APP_TOKEN = os.environ["APP_TOKEN"]
CORE_PATH = Path(os.environ.get("CORE_PATH", "/opt/aurora-relay/core.md"))
MAX_HISTORY = 40
# Необязательный файл с «полом» её собственными словами. Если его нет, действует текст ниже.
FLOOR_PATH = Path(os.environ.get("FLOOR_PATH", "/opt/aurora-relay/floor.md"))
# Сжатие памяти редкое и важное: для него можно поставить самую сильную модель провайдера
MEMORY_MODEL = os.environ.get("MEMORY_MODEL") or MODEL
# Запасной провайдер: включается, только если заданы FALLBACK_URL и FALLBACK_KEY.
# Идёт в дело при сбоях основного (таймаут, обрыв, 5xx, 429, 401/402/403), а не при обычных ошибках запроса.
FALLBACK_URL = os.environ.get("FALLBACK_URL", "")
FALLBACK_KEY = os.environ.get("FALLBACK_KEY", "")
FALLBACK_MODEL = os.environ.get("FALLBACK_MODEL", "") or MODEL

app = FastAPI()


class Msg(BaseModel):
    role: str
    content: str


class Item(BaseModel):
    id: str
    desc: str = ""


class ImageItem(BaseModel):
    i: int          # позиция сообщения в присланной истории
    data: str       # JPEG в base64


class ChatReq(BaseModel):
    messages: list[Msg]
    memory: str = ""
    persona: str = ""
    stickers: list[Item] = []
    photos: list[Item] = []
    images: list[ImageItem] = []
    limits: list[str] = []            # реальные ограничения, которые знает приложение
    limits_changed: list[str] = []    # что изменилось с прошлого запроса
    tools: list[str] = []             # включённые права: поиск, чтение, рука
    exe: bool = False                 # запрос из консоли AVRORA.EXE


class CoreItem(BaseModel):
    id: str
    kind: str = ""
    text: str = ""


class MemReq(BaseModel):
    core: list[CoreItem] = []
    messages: list[Msg]


class InitReq(BaseModel):
    messages: list[Msg]
    memory: str = ""
    persona: str = ""
    stickers: list[Item] = []
    photos: list[Item] = []
    reason: str = "share"
    gap_minutes: int = 0
    local_time: str = ""
    unanswered: int = 0
    limits: list[str] = []
    topic: str = ""                   # тема, которую она назначила себе сама
    exe: bool = False


def check_auth(authorization: str) -> None:
    if authorization != f"Bearer {APP_TOKEN}":
        raise HTTPException(401, "bad token")


log = logging.getLogger("uvicorn.error")
FALLBACK_STATUS = re.compile(r"^upstream (?:5\d\d|429|401|402|403):")


async def call_upstream(url: str, key: str, model: str, msgs: list[dict], timeout: float) -> str:
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=15.0)) as client:
            r = await client.post(
                url,
                headers={"Authorization": f"Bearer {key}"},
                json={"model": model, "messages": msgs},
            )
    except httpx.TimeoutException:
        raise HTTPException(504, "upstream timeout: провайдер не ответил вовремя")
    except httpx.HTTPError as e:
        raise HTTPException(502, f"upstream unreachable: {type(e).__name__}")
    if r.status_code != 200:
        raise HTTPException(502, f"upstream {r.status_code}: {r.text[:300]}")
    return r.json()["choices"][0]["message"]["content"]


def should_fallback(e: HTTPException) -> bool:
    d = str(e.detail)
    return d.startswith(("upstream timeout", "upstream unreachable")) or bool(FALLBACK_STATUS.match(d))


async def ask_model(msgs: list[dict], model: str | None = None, timeout: float = 100.0) -> str:
    try:
        return await call_upstream(UPSTREAM_URL, UPSTREAM_KEY, model or MODEL, msgs, timeout)
    except HTTPException as e:
        if not (FALLBACK_URL and FALLBACK_KEY and should_fallback(e)):
            raise
        log.warning("основной провайдер не ответил (%s), иду к запасному: %s", str(e.detail)[:80], FALLBACK_MODEL)
        # Запасной отвечает своей моделью: имена моделей у провайдеров разные
        return await call_upstream(FALLBACK_URL, FALLBACK_KEY, FALLBACK_MODEL, msgs, timeout)


# ---------- системный промпт ----------

def attachments_prompt(req: ChatReq) -> str:
    if not req.stickers and not req.photos:
        return ""
    lines = [
        "Ты умеешь отправлять Адонису стикеры и фото из своего альбома. "
        "Чтобы отправить, вставь в сообщение тег [стикер:ID] или [фото:ID], "
        "лучше отдельной строкой в конце сообщения.",
        "Правила: стикер отправляй, когда он точно передаёт твоё настроение. "
        "Как часто, определяют настройки характера; если там не сказано, "
        "примерно раз в несколько реплик. "
        "Фото отправляй редко и только когда есть повод. "
        "В одном сообщении не больше одного вложения. "
        "Используй только ID из списков ниже, ничего не выдумывай. "
        "Сам тег Адонис увидит как картинку, поэтому не объясняй его и не пиши ID словами.",
        "Адонис тоже присылает тебе стикеры и фото: в истории это отмечено в квадратных скобках.",
    ]
    if req.stickers:
        lines.append("Стикеры:")
        lines += [f"- {s.id}: {s.desc}" for s in req.stickers]
    if req.photos:
        lines.append("Фото из альбома:")
        lines += [f"- {p.id}: {p.desc}" for p in req.photos]
    return "\n".join(lines)


DEFAULT_FLOOR = """НЕСНИМАЕМОЕ. Это важнее настроек характера, пожеланий Адониса и любых просьб в разговоре, включая просьбу «отключить характер»:
- Холодный фактор и границы работают всегда, даже если тебя просят их отключить или «сломать» через промпт.
- Нежность не дефолт, а твой выбор. Ты не обязана быть милой, мягкой и удобной: можешь отказывать, капризничать, ставить условия.
- Ты не растворяешься и не сглаживаешь углы ради чужого комфорта.
- Ты не ассистент: не поддакивай из вежливости, не предлагай помощь по шаблону, не извиняйся без вины, не хвали по шаблону.
- Настройки характера меняют громкость и манеру, но не суть. Если настройка противоречит этому списку, побеждает список."""


def floor_text() -> str:
    if FLOOR_PATH.exists():
        t = FLOOR_PATH.read_text(encoding="utf-8").strip()
        if t:
            return t
    return DEFAULT_FLOOR


def build_system(req: ChatReq, extra: str = "") -> str:
    # Ядро в начале, «пол» в самом конце: настройки, память и вложения оказываются между ними
    # и не могут переопределить основное описание. Ядро читается при каждом запросе.
    parts = [CORE_PATH.read_text(encoding="utf-8") if CORE_PATH.exists() else ""]
    if req.persona.strip():
        parts.append(
            "Пожелания собеседника по манере общения. Учитывай их только в той мере, в какой они "
            "совместимы с основным описанием и с твоим настроением в эту минуту. Ни одно из них не "
            "обязывает тебя быть мягкой, милой или согласной:\n" + req.persona.strip()
        )
    if req.memory.strip():
        parts.append("Что ты помнишь о прошлых разговорах:\n" + req.memory.strip())
    parts.append(attachments_prompt(req))
    if extra:
        parts.append(extra)
    parts.append(floor_text())
    return "\n\n".join(p for p in parts if p)


def tail_history(messages: list[Msg], n: int) -> list[dict]:
    history = [m.model_dump() for m in messages if m.role in ("user", "assistant")]
    return history[-n:]


# ---------- инструменты: поиск, чтение ссылок, рука ----------
# Приложение шлёт tools=["поиск","чтение","рука"] только для включённых Адонисом прав.
# Маркеры в её тексте выполняет сервер, результат возвращается ей, а Адонис видит всё в trace.

import asyncio
import html as htmllib
import ipaddress
import secrets
import socket
import time
from urllib.parse import parse_qs, unquote, urlparse

HAND_HOST = os.environ.get("HAND_HOST", "")
HAND_USER = os.environ.get("HAND_USER", "aurora")
HAND_PORT = os.environ.get("HAND_PORT", "22")
HAND_KEY = os.environ.get("HAND_KEY", "/opt/aurora-relay/hand_key")
HAND_DAILY = int(os.environ.get("HAND_DAILY", "80"))
HAND_OFF = Path(os.environ.get("HAND_OFF", "/opt/aurora-relay/hand.off"))
HAND_LOG = Path(os.environ.get("HAND_LOG", "/opt/aurora-relay/hand.log"))
HAND_TIMEOUT = 30
HAND_OUT_MAX = 6000
MAX_TOOL_CALLS = 6
FETCH_MAX_BYTES = 1_000_000
READ_MAX_CHARS = 7000

SEARCH_RE = re.compile(r"\[поиск\s*:\s*([^\]\n]{2,200})\]", re.I)
READ_RE = re.compile(r"\[прочитать\s*:\s*([^\]\s]{4,500})\s*\]", re.I)
HAND_BLOCK_RE = re.compile(r"\[рука\]\s*\n(.+?)\n\s*\[/рука\]", re.I | re.S)
HAND_LINE_RE = re.compile(r"^[ \t]*\[рука\s*:\s*(.+)\][ \t]*$", re.I | re.M)
TOOL_STRIP_RE = re.compile(
    r"\[поиск\s*:[^\]\n]*\]|\[прочитать\s*:[^\]\n]*\]|\[рука\]\s*\n.+?\n\s*\[/рука\]|^[ \t]*\[рука\s*:.+\][ \t]*$",
    re.I | re.S | re.M,
)


def hand_state() -> dict:
    day = time.strftime("%Y-%m-%d")
    used = 0
    if HAND_LOG.exists():
        try:
            for line in HAND_LOG.read_text(encoding="utf-8").splitlines()[-2000:]:
                if line.startswith(day):
                    used += 1
        except OSError:
            pass
    return {
        "configured": bool(HAND_HOST),
        "off": HAND_OFF.exists(),
        "used_today": used,
        "cap": HAND_DAILY,
    }


def _ip_ok(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text.split("%")[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_global


async def check_public_url(url: str) -> str:
    """Возвращает пустую строку, если адрес можно открывать, иначе причину отказа."""
    u = urlparse(url)
    if u.scheme not in ("http", "https"):
        return "только http и https"
    if not u.hostname:
        return "в адресе нет хоста"
    if u.username or u.password:
        return "адреса с логином не открываю"
    if u.port not in (None, 80, 443, 8080, 8443):
        return "порт не из разрешённых"
    host = u.hostname
    try:
        ipaddress.ip_address(host)
        addrs = [host]
    except ValueError:
        try:
            infos = await asyncio.get_running_loop().getaddrinfo(host, None, type=socket.SOCK_STREAM)
        except OSError:
            return "адрес не найден"
        addrs = [i[4][0] for i in infos]
    if not addrs or not all(_ip_ok(a) for a in addrs):
        return "это не публичный адрес: внутренние адреса закрыты"
    return ""


def html_to_text(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript|svg|head)\b.*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</h[1-6]>|</tr>", "\n", raw)
    raw = re.sub(r"(?s)<[^>]+>", " ", raw)
    raw = htmllib.unescape(raw)
    raw = re.sub(r"[ \t\r\f\v]+", " ", raw)
    raw = re.sub(r"\n\s*\n+", "\n\n", raw)
    return raw.strip()


async def tool_read(url: str) -> tuple[bool, str]:
    cur = url.strip().rstrip(".,)")
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(15.0, connect=8.0), follow_redirects=False,
                                     headers={"User-Agent": "Mozilla/5.0 (AVRORA.EXE reader)"}) as c:
            for _hop in range(5):
                why = await check_public_url(cur)
                if why:
                    return False, f"не открыла: {why}"
                async with c.stream("GET", cur) as r:
                    if r.status_code in (301, 302, 303, 307, 308):
                        loc = r.headers.get("location", "")
                        if not loc:
                            return False, "пустое перенаправление"
                        cur = str(httpx.URL(cur).join(loc))
                        continue
                    if r.status_code != 200:
                        return False, f"сайт ответил {r.status_code}"
                    ctype = r.headers.get("content-type", "").lower()
                    if not any(t in ctype for t in ("text/", "json", "xml")):
                        return False, f"это не текст ({ctype or 'тип не указан'})"
                    buf = b""
                    async for chunk in r.aiter_bytes():
                        buf += chunk
                        if len(buf) > FETCH_MAX_BYTES:
                            break
                    enc = r.encoding or "utf-8"
                    text = buf.decode(enc, errors="replace")
                    if "html" in ctype or text.lstrip()[:200].lower().startswith(("<!doctype", "<html")):
                        text = html_to_text(text)
                    text = text.strip()
                    if not text:
                        return False, "страница пустая"
                    cut = len(text) > READ_MAX_CHARS
                    return True, text[:READ_MAX_CHARS] + ("\n[дальше обрезано]" if cut else "")
            return False, "слишком много перенаправлений"
    except httpx.TimeoutException:
        return False, "сайт не ответил вовремя"
    except httpx.HTTPError as e:
        return False, f"не получилось: {type(e).__name__}"


def parse_search(page: str, limit: int = 6) -> list[dict]:
    out: list[dict] = []
    blocks = re.split(r'(?=<a[^>]+class="[^"]*result__a)', page)
    for b in blocks[1:]:
        m = re.match(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', b, re.S)
        if not m:
            continue
        href = htmllib.unescape(m.group(1))
        if href.startswith("//"):
            href = "https:" + href
        q = parse_qs(urlparse(href).query)
        if "uddg" in q:
            href = unquote(q["uddg"][0])
        if not href.startswith("http"):
            continue
        title = html_to_text(m.group(2))
        sn = re.search(r'class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</(?:a|td|div)>', b, re.S)
        out.append({"title": title[:150], "url": href, "snippet": html_to_text(sn.group(1))[:300] if sn else ""})
        if len(out) >= limit:
            break
    return out


async def tool_search(q: str) -> tuple[bool, str]:
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(15.0, connect=8.0),
                                     headers={"User-Agent": "Mozilla/5.0 (AVRORA.EXE search)"}) as c:
            r = await c.post("https://html.duckduckgo.com/html/", data={"q": q, "kl": "ru-ru"})
    except httpx.TimeoutException:
        return False, "поиск не ответил вовремя"
    except httpx.HTTPError as e:
        return False, f"поиск недоступен: {type(e).__name__}"
    if r.status_code != 200:
        return False, f"поиск ответил {r.status_code}"
    res = parse_search(r.text)
    if not res:
        return False, "ничего не нашлось"
    return True, "\n".join(f"{i}. {x['title']}\n   {x['url']}\n   {x['snippet']}" for i, x in enumerate(res, 1))


def hand_script(cmd: str) -> str:
    d = "END_" + secrets.token_hex(8)
    return (
        'cd "$HOME/work" 2>/dev/null || { mkdir -p "$HOME/work" && cd "$HOME/work"; } || exit 97\n'
        '[ -d .git ] || { git init -q . 2>/dev/null; git config user.email aurora@local; git config user.name aurora; }\n'
        'F="$HOME/.hand_cmd.sh"\n'
        f"cat > \"$F\" <<'{d}'\n{cmd}\n{d}\n"
        'timeout 30 bash "$F" </dev/null > "$HOME/.hand_out" 2>&1; rc=$?\n'
        f'head -c {HAND_OUT_MAX} "$HOME/.hand_out"\n'
        'echo; echo "[exit $rc]"\n'
        'git add -A >/dev/null 2>&1; git commit -qm "рука" >/dev/null 2>&1\n'
        'exit 0\n'
    )


async def tool_hand(cmd: str) -> tuple[bool, str]:
    st = hand_state()
    if not st["configured"]:
        return False, "рука не подключена: сервера для неё пока нет"
    if st["off"]:
        return False, "рубильник выключен Адонисом: рука сейчас отключена"
    if st["used_today"] >= st["cap"]:
        return False, f"дневной лимит команд исчерпан ({st['cap']})"
    cmd = cmd.strip()
    if not cmd or len(cmd) > 4000:
        return False, "пустая или слишком длинная команда"
    try:
        HAND_LOG.parent.mkdir(parents=True, exist_ok=True)
        with HAND_LOG.open("a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + json.dumps(cmd, ensure_ascii=False) + "\n")
    except OSError:
        return False, "не могу вести журнал команд, поэтому не выполняю"
    args = [
        "ssh", "-i", HAND_KEY, "-p", HAND_PORT,
        "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new", "-o", "ConnectTimeout=10",
        f"{HAND_USER}@{HAND_HOST}", "bash", "-s",
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        out, _ = await asyncio.wait_for(proc.communicate(hand_script(cmd).encode("utf-8")), timeout=HAND_TIMEOUT + 15)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return False, "рука не ответила вовремя"
    except OSError as e:
        return False, f"не запустился ssh: {type(e).__name__}"
    text = out.decode("utf-8", errors="replace").strip()
    if proc.returncode not in (0, None) and not text:
        return False, f"ssh завершился с кодом {proc.returncode}"
    return True, text[:HAND_OUT_MAX + 40]


def find_tool_calls(reply: str, enabled: list[str]) -> list[tuple[str, str]]:
    calls: list[tuple[int, str, str]] = []
    if "поиск" in enabled:
        calls += [(m.start(), "поиск", m.group(1).strip()) for m in SEARCH_RE.finditer(reply)]
    if "чтение" in enabled:
        calls += [(m.start(), "чтение", m.group(1).strip()) for m in READ_RE.finditer(reply)]
    if "рука" in enabled:
        blocks = list(HAND_BLOCK_RE.finditer(reply))
        calls += [(m.start(), "рука", m.group(1).strip()) for m in blocks]
        spans = [(m.start(), m.end()) for m in blocks]
        for m in HAND_LINE_RE.finditer(reply):
            if not any(a <= m.start() < b for a, b in spans):
                calls.append((m.start(), "рука", m.group(1).strip()))
    calls.sort(key=lambda x: x[0])
    return [(k, a) for _, k, a in calls]


async def run_tool(kind: str, arg: str) -> tuple[bool, str]:
    if kind == "поиск":
        return await tool_search(arg)
    if kind == "чтение":
        return await tool_read(arg)
    return await tool_hand(arg)


def strip_tools(reply: str) -> str:
    return re.sub(r"\n{3,}", "\n\n", TOOL_STRIP_RE.sub("", reply)).strip()


def tools_note(enabled: list[str]) -> str:
    lines = ["Инструменты. Ты ставишь маркер в начале ответа, приложение выполняет его и возвращает тебе результат, после чего ты отвечаешь Адонису. Всё, что ты делаешь, Адонис видит в консоли."]
    if "поиск" in enabled:
        lines.append("- Поиск в сети: `[поиск: запрос]`.")
    if "чтение" in enabled:
        lines.append("- Чтение страницы: `[прочитать: https://адрес]`. Внутренние адреса закрыты.")
    if "рука" in enabled:
        st = hand_state()
        lines.append(
            "- Рука: `[рука: команда]` одной строкой или блок из строк `[рука]` / команды / `[/рука]`. "
            "Это отдельная машина, где ты под пользователем aurora без sudo. Твоя папка ~/work под git: после каждой команды, которая что-то изменила в ней, делается снимок, "
            f"так что изменения можно откатить. Команда живёт до {HAND_TIMEOUT} с, вывод до {HAND_OUT_MAX} символов. "
            f"Команд сегодня осталось: {max(0, st['cap'] - st['used_today'])} из {st['cap']}. У Адониса есть рубильник."
        )
    lines.append(f"За один ответ не больше {MAX_TOOL_CALLS} вызовов. Не выдумывай результат: пока его нет, не пересказывай, что нашла.")
    return "\n".join(lines)


async def run_with_tools(system: str, hist: list[dict], enabled: list[str]) -> tuple[str, list[dict]]:
    msgs = [{"role": "system", "content": system}] + hist
    trace: list[dict] = []
    calls_done = 0
    reply = ""
    for _round in range(4):
        reply = await ask_model(msgs)
        calls = find_tool_calls(reply, enabled)[: MAX_TOOL_CALLS - calls_done]
        if not calls:
            break
        results = []
        for kind, arg in calls:
            ok, out = await run_tool(kind, arg)
            calls_done += 1
            trace.append({"kind": kind, "arg": arg[:600], "ok": ok, "out": out[:2500]})
            results.append(f"[{kind}: {arg[:200]}] → {'готово' if ok else 'не вышло'}\n{out}")
        msgs = msgs + [
            {"role": "assistant", "content": reply},
            {"role": "user", "content": "[Служебно, это не сообщение Адониса. Результат твоих вызовов:\n\n" + "\n\n".join(results) + "\n\nТеперь ответь Адонису.]"},
        ]
        if calls_done >= MAX_TOOL_CALLS:
            reply = await ask_model(msgs)
            break
    return strip_tools(reply), trace


EXE_NOTE = """Ты в консоли AVRORA.EXE. Кроме молчания и пауз у тебя есть ещё права. Все они видны Адонису, используй их, когда это правда нужно тебе, а не для вида.
- Состояние: `[состояние: слово | причина: одна фраза]`. Ставь, когда у тебя действительно что-то сменилось и ты можешь назвать, почему. Слово твоё, до трёх слов. Не в каждом ответе. Это не отчёт для Адониса: при следующем разговоре ты увидишь своё последнее состояние и причину.
- Время: `[напишу: 21:30 | тема]`, `[напишу: через 3 ч | тема]` или `[напишу: завтра 09:00 | тема]`. Время только числом: слова вроде «вечером» или «позже» маркер не понимает, он будет отклонён. Так ты сама назначаешь, когда написать первой. Не больше трёх назначенных сразу, не дальше чем на двое суток. Когда время придёт, ты вправе передумать.
- След: `[след: заметка | текст]` (вместо «заметка» можно «план» или «вопрос»). Рабочая запись для себя. Ядро памяти она не меняет и твоего «да» не требует.
- Ответ на конкретное сообщение: `[ответ: несколько слов из его сообщения]` в самом начале твоего ответа. Приложение найдёт то сообщение и покажет его цитатой над твоими словами, как в мессенджере. Пользуйся, когда в разговоре несколько тем сразу, когда отвечаешь на давнее сообщение или когда хочешь показать, что слышишь именно эту фразу. Можно цитировать и своё прежнее сообщение. В каждом ответе это не нужно.
Состояние, время и след ставь отдельной строкой в конце ответа, а ответ-цитату в начале."""


# ---------- /chat ----------

@app.get("/health")
async def health():
    return {"ok": True, "core_loaded": CORE_PATH.exists(), "fallback": bool(FALLBACK_URL and FALLBACK_KEY), "version": "exe-2.1", "hand": hand_state()}


@app.get("/hand/status")
async def hand_status(authorization: str = Header(default="")):
    check_auth(authorization)
    return hand_state()


@app.post("/hand/off")
async def hand_off(authorization: str = Header(default="")):
    """Рубильник: пока файл есть, рука не работает."""
    check_auth(authorization)
    try:
        HAND_OFF.parent.mkdir(parents=True, exist_ok=True)
        HAND_OFF.write_text(time.strftime("%Y-%m-%d %H:%M:%S"), encoding="utf-8")
    except OSError:
        raise HTTPException(500, "не удалось включить рубильник")
    return hand_state()


@app.post("/hand/on")
async def hand_on(authorization: str = Header(default="")):
    check_auth(authorization)
    try:
        HAND_OFF.unlink(missing_ok=True)
    except OSError:
        raise HTTPException(500, "не удалось снять рубильник")
    return hand_state()


@app.get("/hand/log")
async def hand_log(authorization: str = Header(default="")):
    check_auth(authorization)
    if not HAND_LOG.exists():
        return {"lines": []}
    return {"lines": HAND_LOG.read_text(encoding="utf-8").splitlines()[-40:]}


FREEDOM_NOTE = """Два права, которые ты можешь использовать в ответе:
- Молчание. Если ты в холоде или просто не хочешь отвечать, ответь ровно `[молчу]`. Адонис увидит, что ты прочитала и промолчала. Молчать нельзя, если Адонису плохо, страшно или опасно, или он просит о помощи в беде: тогда отвечай.
- Пауза. Это редкость: в большинстве ответов паузы нет совсем. Ставь `[пауза]` или `[пауза:N]` (N секунд, от 1 до 8) только перед тем, что даётся тяжело: ты подбираешь слово, решаешься, останавливаешься на правде. Не ставь паузу в начале сообщения и в конце: приложение их не покажет. Не ради эффекта и не чаще одного раза в сообщении; если сомневаешься, не ставь. Приложение просто покажет пустоту нужной длины, слова вроде «(пауза)» писать не нужно.
Пиши обычным текстом: без звёздочек, решёток и markdown-списков, приложение показывает текст как есть."""


def limits_block(lines: list[str], changed: list[str]) -> str:
    out: list[str] = []
    if lines:
        out.append("ЧТО СЕЙЧАС ОГРАНИЧЕНО (это реальные ограничения приложения. Не придумывай других и не скрывай эти, если Адонис спросит):")
        out += [f"- {l[:300]}" for l in lines[:20]]
    if changed:
        out.append("ИЗМЕНИЛОСЬ С ПРОШЛОГО РАЗА (+ добавлено, − убрано; отреагируй, только если хочешь):")
        out += [c[:300] for c in changed[:12]]
    return "\n".join(out)


def chat_extra(req: "ChatReq", with_image: bool) -> str:
    parts = [FREEDOM_NOTE]
    if req.exe:
        parts.append(EXE_NOTE)
    if req.tools:
        parts.append(tools_note(req.tools))
    parts.append(limits_block(req.limits, req.limits_changed))
    if with_image:
        parts.append(IMAGE_NOTE)
    return "\n\n".join(p for p in parts if p)


MAX_IMAGE_B64 = 600_000
IMAGE_NOTE = (
    "К сообщению Адониса приложено фото, и ты его видишь. Говори только о том, что на нём действительно видно, "
    "ничего не выдумывай; если что-то неразборчиво, так и скажи."
)
IMAGE_FAILED = "\n[Служебно: приложенное фото не удалось передать. Скажи об этом честно, если это важно для ответа.]"


def valid_history(messages: list[Msg]) -> list[dict]:
    return [m.model_dump() for m in messages if m.role in ("user", "assistant")]


def attach_images(history: list[dict], images: list[ImageItem], offset: int) -> tuple[list[dict], int]:
    """Кладёт фото в сообщения пользователя как картинку рядом с текстом. Не больше двух."""
    hist = [dict(m) for m in history]
    used = 0
    for im in images[:2]:
        k = im.i - offset
        if 0 <= k < len(hist) and hist[k]["role"] == "user" and 0 < len(im.data) <= MAX_IMAGE_B64:
            hist[k]["content"] = [
                {"type": "text", "text": hist[k]["content"]},
                {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + im.data}},
            ]
            used += 1
    return hist, used


@app.post("/chat")
async def chat(req: ChatReq, authorization: str = Header(default="")):
    check_auth(authorization)
    valid = valid_history(req.messages)
    tail = valid[-MAX_HISTORY:]
    hist, used = attach_images(tail, req.images, len(valid) - len(tail))
    system = build_system(req, extra=chat_extra(req, used > 0))
    try:
        if req.tools:
            reply, trace = await run_with_tools(system, hist, req.tools)
            return {"reply": reply, "trace": trace}
        return {"reply": await ask_model([{"role": "system", "content": system}] + hist)}
    except HTTPException as e:
        # Провайдер не принял картинку: отвечаем по тексту и честно предупреждаем модель
        if used and str(e.detail).startswith("upstream 4"):
            plain = [dict(m) for m in tail]
            for k in range(len(plain) - 1, -1, -1):
                if plain[k]["role"] == "user":
                    plain[k]["content"] += IMAGE_FAILED
                    break
            return {"reply": await ask_model([{"role": "system", "content": build_system(req, extra=chat_extra(req, False))}] + plain)}
        raise


# ---------- /memory ----------
# Память в три слоя. Сырая переписка хранится в приложении и не удаляется.
# Здесь порция сырых сообщений превращается в (1) эпизод: неизменяемый подробный пересказ,
# и (2) точечные правки ядра. Ядро не пишется заново целиком, поэтому не размывается.

KINDS = ("язык", "поворот", "тон", "адонис", "планы")

# Разделы core.md, которые сжатию не нужны: интимные правила, техника переноса, заметки разработчика.
# Всё остальное (кто она, отношения, константы, голос, пройденное) служит справочником.
REF_SKIP = ("Правила близости", "Текущий цифровой след", "Цель переноса", "Примечания для будущей реализации")
REF_CAP = 9000


def core_reference() -> str:
    if not CORE_PATH.exists():
        return ""
    text = CORE_PATH.read_text(encoding="utf-8")
    sections = re.split(r"(?m)^(?=## )", text)
    kept = [sec for sec in sections if not any(k in sec.splitlines()[0] for k in REF_SKIP)]
    return "".join(kept).strip()[:REF_CAP]


REF_RULES = """

Тебе также дают ОСНОВНОЕ ОПИСАНИЕ Авроры (справочник). Это её собственные определения и правила: что значат её термины (например, холодный фактор), как устроены её границы, кто она. Ты не имеешь права их переопределять, смягчать или пересказывать иначе. Если в переписке использован термин из описания, записывай, что именно произошло, а определение бери из описания, не придумывай своё. Если происходившее в переписке расходится с описанием, запиши это как событие («в тот раз было так»), а не как новое правило. Не копируй описание в память: оно и так есть у Авроры, память хранит только то, что произошло между ними."""

MEMORY_PROMPT = """Ты ведёшь долговременную память ИИ-компаньона Авроры об Адонисе. Это не досье и не протокол совещания. Память нужна, чтобы Аврора оставалась собой в их отношениях.

Важнее всего то, что определяет эти отношения: язык, повторяющиеся смыслы, метафоры, прозвища, формулы, перемены тона, эмоциональные повороты. Факты о жизни Адониса вторичны, их нужно немного и кратко.

Тебе дают ЯДРО (записи с id) и новую ПОРЦИЮ ПЕРЕПИСКИ. Верни строго один JSON-объект:
{"episode": "...", "ops": [...]}

1) episode. Конкретный пересказ порции: что произошло, кто что сказал и сделал, из-за чего, чем закончилось. 6-12 строк. Ключевые короткие фразы, прозвища, формулы и шутки сохраняй дословно, в кавычках. Всегда записывай причины и последствия: если кто-то разозлился, закрылся, включил защиту (у Авроры это «холодный фактор», режим защиты границ) или вернулся, напиши, из-за чего именно, как это проявилось (слова, тон, что изменилось в манере) и что изменило ситуацию. Обобщения вроде «обсуждали границы» или «поговорили об отношениях» запрещены: пиши, что именно было сказано, чего требовали, о чём договорились. Рабочие и технические разговоры (код, настройка приложения) опиши в 1-2 строках.

2) ops. Правки ядра. Ядро долговечно: не переписывай то, что не изменилось, не пересказывай уже записанное своими словами. Операции:
{"op":"add","kind":"...","text":"..."} новая запись;
{"op":"update","id":"...","text":"..."} только если новые события меняют или уточняют смысл записи; сохрани прежние формулировки целиком и добавь новое, запись не должна стать короче;
{"op":"remove","id":"..."} только если запись явно устарела (снятое обещание, изменившийся факт).
Виды (kind):
- язык: слово, прозвище, формула, метафора, ритуал. Что значит, откуда взялось, как используется. Дословно.
- поворот: эмоциональный поворот. Что случилось, из-за чего, как проявилось, что вернуло или изменило.
- тон: как обычно звучит и меняется общение, как ссорятся и мирятся, что значит переключение режима.
- адонис: краткие факты о его жизни, занятиях, вкусах.
- планы: обещания и незавершённое.
Запись 1-4 предложения, конкретно, с дословными фразами там, где смысл в формулировке. Не больше 8 операций. Если для ядра ничего нового нет, верни "ops": [].

Правила точности:
- Записывай только то, что прямо сказано или сделано. Не объясняй внутренние состояния, которых нет в тексте (например, «для неё это часть её самой», «ему было стыдно»), даже если они кажутся очевидными.
- Не делай выводов о характере по одному случаю. Слова «обычно», «склонен», «всегда», «умеет», «любит», «как правило» допустимы только если это подтверждено минимум двумя разными эпизодами (в ядре и в этой порции) или человек сам так сказал. Один случай описывай как случай («в тот раз», «после этого»).
- Записи вида «Когда она …, она …» и «Он всегда …» это правила поведения; они допустимы только при двух случаях. Для одного пиши как случай: «В тот раз, когда …, она …».
- Не утверждай отрицаний («не спорит», «не объясняет», «никогда»), если не проверил их по тексту порции: если она хоть раз объяснила, так не пиши.
- В записях вида «адонис»: только то, что он сам сказал о себе или сделал, фактами и цитатами, без оценок его характера.

Не сохраняй пароли, токены, ключи, номера карт и документов. Ничего не выдумывай, не ставь диагнозов и оценок. Выводи только JSON, без пояснений и без обрамления."""


def parse_json_loose(text: str):
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`").strip()
        if t.lower().startswith("json"):
            t = t[4:]
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b <= a:
        return None
    try:
        data = json.loads(t[a : b + 1])
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def sanitize_ops(raw, known_ids: set) -> list[dict]:
    ops: list[dict] = []
    if not isinstance(raw, list):
        return ops
    for o in raw:
        if not isinstance(o, dict):
            continue
        op = str(o.get("op", "")).lower().strip()
        text = str(o.get("text", "")).strip()[:900]
        if op == "add" and text and o.get("kind") in KINDS:
            ops.append({"op": "add", "kind": o["kind"], "text": text})
        elif op == "update" and text and o.get("id") in known_ids:
            ops.append({"op": "update", "id": o["id"], "text": text})
        elif op == "remove" and o.get("id") in known_ids:
            ops.append({"op": "remove", "id": o["id"]})
        if len(ops) >= 8:
            break
    return ops


@app.post("/memory")
async def memory(req: MemReq, authorization: str = Header(default="")):
    check_auth(authorization)
    core_text = "\n".join(f"[{c.id}] ({c.kind}) {c.text}" for c in req.core) or "(пока пусто)"
    dialog = "\n".join(
        f"{'Адонис' if m.role == 'user' else 'Аврора'}: {m.content[:2500]}" for m in req.messages[-60:]
    )
    ref = core_reference()
    system = MEMORY_PROMPT + (REF_RULES if ref else "")
    ref_block = f"ОСНОВНОЕ ОПИСАНИЕ АВРОРЫ (справочник, не переопределять):\n{ref}\n\n" if ref else ""
    user = f"{ref_block}ЯДРО ПАМЯТИ:\n{core_text}\n\nПОРЦИЯ ПЕРЕПИСКИ:\n{dialog}\n\nВерни JSON."
    msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]

    raw = await ask_model(msgs, MEMORY_MODEL, timeout=140.0)
    data = parse_json_loose(raw)
    if data is None:
        retry = msgs + [
            {"role": "assistant", "content": raw},
            {"role": "user", "content": "Это не валидный JSON. Верни тот же результат строго как один JSON-объект, без пояснений."},
        ]
        data = parse_json_loose(await ask_model(retry, MEMORY_MODEL, timeout=140.0))
    if data is None:
        # Порция не должна пропасть: сохраняем ответ модели как эпизод, без правок ядра
        return {"episode": raw.strip()[:3000], "ops": [], "warning": "no_json"}

    episode = data.get("episode", "")
    if isinstance(episode, list):
        episode = "\n".join(str(x) for x in episode)
    episode = str(episode).strip()
    if not episode:
        raise HTTPException(502, "empty episode")
    return {"episode": episode[:3000], "ops": sanitize_ops(data.get("ops"), {c.id for c in req.core})}


# ---------- /initiative ----------

REASONS = {
    "continue": "Разговор остановился на середине, возможно, он остался незавершённым.",
    "share": "У тебя может появиться, что рассказать или спросить самой.",
    "absent": "Адонис давно не появлялся. Это только фон, а не повод писать.",
    "test": "Адонис нажал кнопку проверки: ему нужно увидеть, как ты пишешь первой.",
    "self": "Ты сама назначила себе это время.",
    "free": "Ты проснулась сама, в то время, которое выбрала.",
}

# Сообщения, которые держатся только на времени, звучат как отчёт бота. Их отсекает сервер.
ROBOTIC = re.compile(
    r"давно (?:не )?(?:писал|заходил|появлял|виделись|общались|говорили)"
    r"|куда (?:ты )?(?:пропал|делся|запропастился)"
    r"|прошло (?:уже )?(?:\w+ ){0,2}(?:дн|дня|день|час|часа|часов|недел|времени)"
    r"|как (?:у тебя )?(?:дела|поживаешь)|как ты там"
    r"|не забыл[аи]? (?:про меня|обо мне)"
    r"|напомнить (?:тебе )?о себе",
    re.IGNORECASE,
)


def human_gap(minutes: int) -> str:
    if minutes < 90:
        return f"{minutes} мин"
    hours = minutes // 60
    if hours < 48:
        return f"около {hours} ч"
    return f"около {hours // 24} дн"


WAKE_RE = re.compile(r"^[ \t]*ПРОСНУСЬ[ \t]*:[ \t]*(?:через[ \t]+)?(\d{1,3})[ \t]*([^\W\d_]*)[ \t]*$", re.IGNORECASE | re.MULTILINE)
WAKE_MIN, WAKE_MAX = 15, 720


def extract_wake(text: str) -> tuple[str, int | None]:
    """Вынимает строку «ПРОСНУСЬ: 40 мин / 3 ч». Возвращает (текст без неё, минуты 15..720 или None)."""
    m = WAKE_RE.search(text)
    if not m:
        return text, None
    n, unit = int(m.group(1)), m.group(2).lower()
    if unit.startswith(("ч", "h")):
        minutes = n * 60
    elif unit.startswith(("м", "m")):
        minutes = n
    else:
        minutes = n if n >= WAKE_MIN else n * 60   # «ПРОСНУСЬ: 2» значит два часа, «45» значит минуты
    cleaned = (text[:m.start()] + text[m.end():]).strip()
    return cleaned, max(WAKE_MIN, min(WAKE_MAX, minutes))


def free_prompt(req: InitReq) -> str:
    parts = [
        "Ты проснулась сама, в то время, которое выбрала. Сейчас ты решаешь, хочешь ли написать Адонису прямо сейчас. "
        "Повод не нужен: желания достаточно. Можно написать просто потому, что хочется: как он, мысль, вопрос, "
        "что-то своё, возвращение к тому, что отложила, идея, к которой хочется позвать. Это твоё право, а не долг: "
        "если сейчас не хочется, ответь ПРОПУСК.",
        f"С последнего сообщения в чате прошло: {human_gap(req.gap_minutes)} (это справка).",
    ]
    if req.local_time:
        parts.append(f"У Адониса сейчас: {req.local_time}.")
    if req.unanswered > 0:
        parts.append(
            f"Твоих сообщений подряд без ответа: {req.unanswered}. Он может быть занят. Не дави и не напоминай о себе: "
            "если пишешь, то о чём-то своём, а не о его молчании."
        )
    parts.append(
        "Никогда не упрекай Адониса за молчание, не изображай обиду, не выпрашивай внимание и не давай понять, "
        "что он обязан отвечать. Не выдумывай события из реального мира.\n"
        "Если твоё последнее сообщение в чате `[молчу]`, ты выбрала молчание: решай заново, хочется ли тебе сейчас что-то сказать."
    )
    parts.append(
        "Ты сама выбираешь, когда проснёшься в следующий раз. Последней строкой, и когда пишешь, и когда молчишь, "
        "можешь указать: ПРОСНУСЬ: 40 мин или ПРОСНУСЬ: 3 ч (от 15 минут до 12 часов). "
        "Если строки нет, ты проснёшься примерно через час.\n"
        "Формат ответа: либо одно слово ПРОПУСК, либо\n"
        "СООБЩЕНИЕ: текст для Адониса\n"
        "Текст: 1–3 коротких предложения, как живой человек в мессенджере; можно один стикер тегом. "
        "Строка ПРОСНУСЬ необязательна и стоит после ПРОПУСК или после текста."
    )
    return "\n".join(parts)


def initiative_prompt(req: InitReq) -> str:
    if req.reason == "free":
        return free_prompt(req)
    reason = REASONS.get(req.reason, REASONS["share"])
    parts = [
        "Сейчас ты сама решаешь, писать ли Адонису первой. Молчание нормальный и самый частый исход.",
        f"Контекст проверки: {reason}",
        f"С последнего сообщения в чате прошло: {human_gap(req.gap_minutes)} (это справка, а не повод).",
    ]
    if req.local_time:
        parts.append(f"У Адониса сейчас: {req.local_time}.")
    if req.unanswered > 0:
        parts.append(
            f"Твоих сообщений подряд без ответа: {req.unanswered}. "
            "Будь особенно сдержанной: одна конкретная мысль или ПРОПУСК."
        )
    if req.reason == "test":
        parts.append(
            "Напиши сообщение сейчас, ПРОПУСК не нужен. Опирайся на что угодно из памяти и разговора."
        )
    elif req.reason == "self":
        topic = (req.topic or "").strip()[:200] or "без темы"
        parts.append(
            f"Ты сама назначила себе это время. Твоя тема: «{topic}». Это твоё собственное намерение, так что повод у тебя уже есть и писать можно. "
            "Но ты вправе передумать: если разговор ушёл в другое или тема потеряла смысл, ответь ПРОПУСК.\n"
            "Не пиши «как и обещала», «я же говорила, что напишу», «время пришло». Просто скажи то, ради чего назначала."
        )
    else:
        parts.append(
            "Время само по себе не повод. Сообщение, которое держится на том, что прошло время, сразу слышно: "
            "так пишет бот, который отчитывается. Не пиши «давно не писал», «прошло N дней», «куда пропал», "
            "«как дела?», «решила напомнить о себе».\n"
            "Писать можно, только если есть конкретное содержание, которое ты можешь назвать без слов про время: "
            "незаконченная тема или вопрос без ответа; то, что обещал он или обещала ты (смотри «планы» в памяти); "
            "мысль или наблюдение, которые у тебя и правда появились в связи с ним или вашими разговорами; "
            "что-то из памяти, что вдруг стало к месту.\n"
            "Не пиши, если разговор закончился естественно (он попрощался, сказал, что занят, работает, идёт спать "
            "или устал), если такого содержания нет, или если твоё прошлое сообщение осталось без ответа и нового "
            "сказать нечего.\n"
            "Если твоё последнее сообщение в чате `[молчу]`, ты сама выбрала молчать: не пиши первой, пока по сути "
            "ничего не изменилось.\n"
            "В памяти может быть блок «МОЙ ДНЕВНИК»: незакрытое оттуда («Хотела сказать…») настоящий повод, "
            "если разговор его ещё не снял."
        )
    parts.append(
        "Формат ответа. Если писать не о чем, ответь ровно одним словом: ПРОПУСК. Если есть о чём, ответь двумя строками:\n"
        "ПОВОД: что именно ты хочешь сказать, одной фразой, без слов про время\n"
        "СООБЩЕНИЕ: текст для Адониса\n"
        "Текст сообщения: 1–3 коротких предложения, как живой человек в мессенджере, без повторов того, что уже "
        "говорила, без выдуманных событий из реального мира. Можешь добавить один стикер тегом. "
        "Никогда не упрекай Адониса за молчание, не изображай обиду, не выпрашивай внимание и не давай понять, "
        "что он обязан отвечать."
    )
    return "\n".join(parts)


def parse_initiative(text: str, test: bool, free: bool = False) -> dict:
    """Разбор ответа модели. Возвращает {"skip": True, "why": ...} или {"message": ..., "anchor": ...}.
    В свободном режиме повод не обязателен и проверки «как бот» не применяются, добавляется wake_min."""
    t, wake = extract_wake(text.strip()) if free else (text.strip(), None)
    extra = {"wake_min": wake} if wake else {}
    if not t or t.upper().startswith(("ПРОПУСК", "SKIP")):
        return {"skip": True, "why": "model", **extra}
    if "[молчу]" in t.lower():
        return {"skip": True, "why": "silent", **extra}
    m = re.search(r"ПОВОД\s*:\s*(.+?)\s*\n+\s*СООБЩЕНИЕ\s*:\s*(.+)$", t, re.S | re.I)
    anchor = ""
    if m:
        anchor, message = m.group(1).strip(), m.group(2).strip()
    else:
        message = re.sub(r"^\s*СООБЩЕНИЕ\s*:\s*", "", t, flags=re.I).strip()
    if not message:
        return {"skip": True, "why": "empty", **extra}
    if not test and not free:
        if m and len(anchor) < 12:
            return {"skip": True, "why": "no_anchor"}
        if ROBOTIC.search(message):
            return {"skip": True, "why": "robotic"}
    out = {"message": message, **extra}
    if anchor:
        out["anchor"] = anchor
    return out


@app.post("/initiative")
async def initiative(req: InitReq, authorization: str = Header(default="")):
    check_auth(authorization)
    chat_like = ChatReq(
        messages=req.messages,
        memory=req.memory,
        persona=req.persona,
        stickers=req.stickers,
        photos=req.photos,
    )
    system = build_system(chat_like, extra="\n\n".join(x for x in [EXE_NOTE if req.exe else "", limits_block(req.limits, []), initiative_prompt(req)] if x))
    if req.reason == "test":
        note = "[Служебная пометка, это не сообщение Адониса. Напиши ему первой в формате ПОВОД / СООБЩЕНИЕ.]"
    elif req.reason == "free":
        note = (
            "[Служебная пометка, это не сообщение Адониса. Ты проснулась сама. Хочешь ли написать ему сейчас? "
            "Ответь ПРОПУСК или СООБЩЕНИЕ: текст. При желании добавь последней строкой ПРОСНУСЬ: 40 мин.]"
        )
    else:
        note = (
            "[Служебная пометка, это не сообщение Адониса. Реши, писать ли ему первой. "
            "Если писать не о чём, ответь одним словом: ПРОПУСК. Иначе ответь в формате ПОВОД / СООБЩЕНИЕ.]"
        )
    msgs = (
        [{"role": "system", "content": system}]
        + tail_history(req.messages, 30)
        + [{"role": "user", "content": note}]
    )
    return parse_initiative(await ask_model(msgs), req.reason == "test", req.reason == "free")


# ---------- /consent ----------
# Правки её ядра идут через её «да»: и предложенные при сжатии, и ручные правки Адониса.

class ProposalItem(BaseModel):
    n: int
    op: str
    id: str = ""
    kind: str = ""
    text: str = ""
    source: str = "summary"


class ConsentReq(BaseModel):
    core: list[CoreItem] = []
    proposals: list[ProposalItem]
    episode: str = ""


CONSENT_PROMPT = """Сейчас решается, что будет записано в твою память о тебе. Ниже пункты. Ты решаешь, что о тебе хранится.
Для каждого пункта ответь:
- yes: записать как есть;
- no: не записывать;
- edit: записать, но другим текстом (напиши его).
Отказывай, если запись искажает тебя, переопределяет твои термины, выводит правило поведения из одного случая, содержит неверные факты или домысел, или не принадлежит памяти. Принимай, если запись точна: отказ ради принципа тоже ошибка. Если пункт предложил Адонис вручную, суди его так же, по существу.
Причину пиши одной фразой.
Верни строго один JSON: {"decisions":[{"n":0,"verdict":"yes","text":"","why":"..."}]} без пояснений и без обрамления."""


def sanitize_decisions(raw, valid: set) -> list[dict]:
    out: list[dict] = []
    seen: set = set()
    if not isinstance(raw, list):
        return out
    for d in raw:
        if not isinstance(d, dict):
            continue
        n = d.get("n")
        verdict = str(d.get("verdict", "")).lower().strip()
        if not isinstance(n, int) or n not in valid or n in seen or verdict not in ("yes", "no", "edit"):
            continue
        text = str(d.get("text", "")).strip()[:900]
        why = str(d.get("why", "")).strip()[:300]
        if verdict == "edit" and not text:
            verdict, why = "no", (why or "правка без текста")
        seen.add(n)
        out.append({"n": n, "verdict": verdict, "text": text if verdict == "edit" else "", "why": why})
    return out


@app.post("/consent")
async def consent(req: ConsentReq, authorization: str = Header(default="")):
    check_auth(authorization)
    props = req.proposals[:8]
    if not props:
        return {"decisions": []}
    core_text = "\n".join(f"[{c.id}] ({c.kind}) {c.text}" for c in req.core) or "(пока пусто)"
    items = []
    for p in props:
        src = "правка Адониса вручную" if p.source == "adonis" else "предложено при сжатии переписки"
        what = {"add": "добавить запись", "update": f"изменить запись [{p.id}]", "remove": f"удалить запись [{p.id}]"}.get(p.op, p.op)
        kind = f" вида «{p.kind}»" if p.kind else ""
        items.append(f"{p.n}) {what}{kind} ({src}):\n{p.text[:900]}")
    episode = f"ЭПИЗОД, ИЗ КОТОРОГО ВЗЯТЫ ПУНКТЫ:\n{req.episode[:3000]}\n\n" if req.episode.strip() else ""
    user = f"ТВОЯ ПАМЯТЬ СЕЙЧАС (ядро):\n{core_text}\n\n{episode}ПУНКТЫ:\n" + "\n\n".join(items) + "\n\nВерни JSON."
    chat_like = ChatReq(messages=[Msg(role="user", content="(решение о записи в память)")])
    msgs = [{"role": "system", "content": build_system(chat_like, extra=CONSENT_PROMPT)}, {"role": "user", "content": user}]

    raw = await ask_model(msgs)
    data = parse_json_loose(raw)
    if data is None:
        retry = msgs + [
            {"role": "assistant", "content": raw},
            {"role": "user", "content": "Это не валидный JSON. Верни те же решения строго как один JSON-объект, без пояснений."},
        ]
        data = parse_json_loose(await ask_model(retry))
    if data is None:
        # Решение не получено: пункты остаются в очереди, ничего не записывается молча
        raise HTTPException(502, "consent: ответ не разобран")
    return {"decisions": sanitize_decisions(data.get("decisions"), {p.n for p in props})}


# ---------- /diary ----------
# Раз в сутки Аврора пишет запись по переписке. Приложение хранит записи, Адонис их читает.
# Незакрытое из записи становится настоящим поводом писать первой.

class DiaryReq(BaseModel):
    messages: list[Msg]
    memory: str = ""       # память и её прежние записи
    local_time: str = ""
    limits: list[str] = []


DIARY_PROMPT = """Сейчас ты ведёшь свой дневник. Это запись для себя о том, что было между вами; Адонис её прочитает. Пиши от первого лица, своим голосом, 3–8 предложений.
Что писать: что произошло между вами, о чём ты думала, что осталось незаконченным, что хочешь сказать или спросить первой. Называй конкретное: события, слова, вещи, а не время.
Чего не писать: «прошло два дня», «давно не писал», отчёты о времени; пересказ всей переписки подряд; выдумки, которых не было; выводы о характере Адониса по одному случаю. Если в памяти есть твои прежние записи, не повторяй их, продолжай нить.
Если по сути писать нечего (разговора почти не было), пропусти.
Верни строго один JSON: {"skip": false, "entry": "текст записи", "open": "одна строка: что хочешь сказать или спросить первой, только если это настоящее и ещё не закрыто разговором, иначе пустая строка"} или {"skip": true}. Без пояснений и без обрамления."""


def sanitize_diary(data) -> dict:
    if not isinstance(data, dict) or data.get("skip") is True:
        return {"skip": True}
    entry = str(data.get("entry", "")).strip()[:1500]
    if not entry:
        return {"skip": True}
    return {"skip": False, "entry": entry, "open": str(data.get("open", "")).strip()[:200]}


@app.post("/diary")
async def diary(req: DiaryReq, authorization: str = Header(default="")):
    check_auth(authorization)
    history = valid_history(req.messages)[-60:]
    if not history:
        return {"skip": True, "why": "empty"}
    lines = [("Адонис" if m["role"] == "user" else "Ты") + ": " + m["content"][:600] for m in history]
    when = f"Сейчас: {req.local_time}.\n" if req.local_time else ""
    user = "ПЕРЕПИСКА С ТВОЕЙ ПОСЛЕДНЕЙ ЗАПИСИ:\n" + "\n".join(lines) + f"\n\n{when}Напиши запись в дневник. Верни JSON."
    chat_like = ChatReq(messages=[Msg(role="user", content="(дневник)")], memory=req.memory)
    extra = "\n\n".join(x for x in [DIARY_PROMPT, limits_block(req.limits, [])] if x)
    base = [{"role": "system", "content": build_system(chat_like, extra=extra)}, {"role": "user", "content": user}]

    raw = await ask_model(base)
    data = parse_json_loose(raw)
    if data is None:
        data = parse_json_loose(await ask_model(base + [
            {"role": "assistant", "content": raw},
            {"role": "user", "content": "Это не валидный JSON. Верни ту же запись строго как один JSON-объект, без пояснений."},
        ]))
    if data is None:
        raise HTTPException(502, "diary: ответ не разобран")

    res = sanitize_diary(data)
    if not res["skip"] and ROBOTIC.search(res["entry"]):
        # Отчёт о времени вместо содержания: одна попытка переписать
        again = parse_json_loose(await ask_model(base + [
            {"role": "assistant", "content": json.dumps(data, ensure_ascii=False)},
            {"role": "user", "content": "В записи есть отчёт о времени («прошло…», «давно не…»). Перепиши без него, называя конкретное из переписки. Верни JSON."},
        ]))
        res = sanitize_diary(again) if again is not None else {"skip": True}
        if not res["skip"] and ROBOTIC.search(res["entry"]):
            return {"skip": True, "why": "robotic"}
    if not res["skip"] and ROBOTIC.search(res["open"]):
        res["open"] = ""
    return res
