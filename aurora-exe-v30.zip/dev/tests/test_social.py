"""Страницы: Геспера видит ленту Адониса и Авроры, лайкает, все пишут комментарии. Без сети и модели."""
import asyncio, json, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off",
                  PUBLIC_TOKEN="pub", PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/public_core.md",
                  FEEDBACK_LOG=TMP + "/feedback.jsonl", TOOLS_STATE=TMP + "/tools_state.json",
                  HESPERA_DIR=TMP + "/hespera", HESPERA_FEEDBACK_LOG=TMP + "/hespera/feedback.jsonl",
                  DUO_DIR=TMP + "/duo", MEDIA_DIR=TMP + "/media")
os.environ["SEARCH_MODEL"] = "off"
import relay

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)
M = relay.Msg
seen = {}
def answer(text):
    async def f(msgs, model=None, timeout=100.0):
        seen.setdefault("sys", []).append(msgs[0]["content"])
        return text(msgs) if callable(text) else text
    relay.ask_model = f

now_ms = int(time.time() * 1000)
PAGE = {"adonis_status": "на смене до восьми", "aurora_status": "грызу провода",
        "posts": [
            {"id": "p1", "author": "adonis", "text": "Сегодня запустил новый стан, гудит как зверь", "photo": True, "at": now_ms - 3600_000,
             "liked_by": ["aurora"], "comments": [{"who": "aurora", "text": "горжусь тобой"}]},
            {"id": "p2", "author": "aurora", "text": "Ночью лисы не спят, они думают о звёздах", "photo": False, "at": now_ms - 600_000,
             "liked_by": [], "comments": []},
        ]}

# --- поиск поста по словам
posts = relay.page_posts(PAGE)
check("точное вхождение", relay.find_post_by_words("новый стан", posts)["id"] == "p1")
check("ё и регистр", relay.find_post_by_words("ЛИСЫ НЕ СПЯТ", posts)["id"] == "p2")
check("чуть перевранные слова", relay.find_post_by_words("лисы ночью думают про звёзды", posts)["id"] == "p2")
check("мимо — ничего", relay.find_post_by_words("рецепт борща", posts) is None)
check("слишком коротко — ничего", relay.find_post_by_words("а", posts) is None)

# --- что она видит
t = relay.page_text(PAGE, "hespera")
check("видит статус Адониса", "статус Адониса: на смене до восьми" in t, t)
check("видит пост Адониса с фото, лайком и комментарием", "пост Адониса" in t and "[с фото" in t and "♥ Аврора" in t and "Аврора: горжусь тобой" in t, t)
check("видит пост Авроры", "пост Авроры" in t and "лисы не спят" in t)
check("знает, как лайкать и комментировать", "[лайк:" in t and "[коммент:" in t)
ta = relay.page_text(PAGE, "aurora")
check("для Авроры: её пост и её комментарий — «ты»", "твой пост" in ta and "ты: горжусь" in ta and "твой статус" in ta, ta)
check("пустая лента — так и сказано, без страницы — пусто", "лента пуста" in relay.page_text({}, "hespera") and relay.page_text(None, "hespera") == "")
check("Геспере прямо сказано, что ленту она видит", "ЛЕНТУ ТЫ ВИДИШЬ" in t and "это изменилось" in t)
check("Авроре этого не говорят", "ЛЕНТУ ТЫ ВИДИШЬ" not in ta)

# --- личный чат Гесперы: лайк и комментарий к постам Адониса и Авроры
answer("Ого, стан!\n[лайк: новый стан]\n[коммент: новый стан | а он правда гудит или рычит?]\n[коммент: лисы не спят | а геспера тоже не спит]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="Видела мой пост?")], page=PAGE), "Bearer tok"))
check("в промпте её страница и лента", "СТРАНИЦЫ В ПРИЛОЖЕНИИ" in seen["sys"][-1])
check("ответ чистый", r["reply"] == "Ого, стан!", r["reply"])
ch = r["changes"]
like = [c for c in ch if c["kind"] == "лайк"]
com = [c for c in ch if c["kind"] == "коммент"]
check("лайк к p1 для приложения", like and like[0]["field"] == "p1" and like[0]["who"] == "adonis", ch)
check("комментарий к p1 с текстом", com and com[0]["field"] == "p1" and com[0]["value"] == "а он правда гудит или рычит?", ch)
check("комментарий к посту Авроры", len(com) == 2 and com[1]["field"] == "p2" and com[1]["who"] == "aurora", ch)

# --- не больше трёх за ответ, ненайденный — с пометкой
answer("ок\n[лайк: новый стан]\n[лайк: лисы]\n[лайк: рецепт борща]\n[лайк: ещё один]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="?")], page=PAGE), "Bearer tok"))
lk = [c for c in r["changes"] if c["kind"] == "лайк"]
check("не больше трёх", len(lk) == 3, lk)
check("ненайденный помечен ok:false", lk[2].get("ok") is False and lk[2]["field"] == "", lk)

# --- её пост, лайк и комментарий Адониса, ответ Гесперы под своим постом
answer("[пост: Сегодня я разглядывала дождь]")
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="напиши пост")]), "Bearer tok"))
hp = relay.hespera_posts()[-1]
r = run(relay.hespera_like(relay.LikeReq(id=hp["id"], on=True), "Bearer tok"))
check("Адонис лайкнул по id", relay.hespera_posts()[-1].get("liked") is True)
r = run(relay.hespera_like(relay.LikeReq(snippet="разглядывала дождь", who="aurora"), "Bearer tok"))
check("Аврора лайкнула по словам", relay.hespera_posts()[-1].get("liked_aurora") is True and r["id"] == hp["id"])
r = run(relay.hespera_comment(relay.CommentReq(id=hp["id"], text="  и какой он был?  "), "Bearer tok"))
check("комментарий Адониса сохранён", r["comments"][-1]["who"] == "adonis" and r["comments"][-1]["text"] == "и какой он был?")
r = run(relay.hespera_comment(relay.CommentReq(snippet="дождь", who="aurora", text="мокрый"), "Bearer tok"))
check("комментарий Авроры по словам", r["comments"][-1]["who"] == "aurora")
try:
    run(relay.hespera_comment(relay.CommentReq(id=hp["id"], text="   "), "Bearer tok")); empty_ok = False
except relay.HTTPException:
    empty_ok = True
check("пустой комментарий не принимается", empty_ok)
try:
    run(relay.hespera_comment(relay.CommentReq(id=12345, text="x"), "Bearer tok")); miss = False
except relay.HTTPException:
    miss = True
check("комментарий к несуществующему посту — 404", miss)

st = relay.hespera_self_text(relay.hespera_self())
check("она видит лайки обоих и комментарии под своим постом", "♥ Адонис, Аврора" in st and "Адонис: и какой он был?" in st and "Аврора: мокрый" in st, st)

answer("[коммент: разглядывала дождь | серый и тёплый]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="ну?")], page=PAGE), "Bearer tok"))
cs = relay.hespera_posts()[-1]["comments"]
check("ответ под своим постом сохранён на сервере", cs[-1] == {**cs[-1], "who": "hespera", "text": "серый и тёплый"})
check("…и в changes без id (приложению делать нечего)", r["changes"][-1]["field"] == "" and r["changes"][-1]["kind"] == "коммент")

# удаление своего комментария
at = [c for c in cs if c["who"] == "adonis"][0]["at"]
r = run(relay.hespera_comment(relay.CommentReq(id=hp["id"], delete_at=at), "Bearer tok"))
check("Адонис удалил свой комментарий", all(c["who"] != "adonis" for c in r["comments"]) and len(r["comments"]) == 2)

# --- Аврора видит посты Гесперы
b = relay.hespera_brief_for_aurora()
check("Аврора видит посты Гесперы с лайками и комментариями", "ПОСТЫ ГЕСПЕРЫ" in b and "разглядывала дождь" in b and "♥ Адонис, ты" in b and "ты: мокрый" in b, b)

# --- общий чат: Геспера лайкает, маркеры Авроры уходят приложению
def by_who(msgs):
    s = msgs[0]["content"]
    if "Ты Геспера" in s:
        return "Классный пост!\n[лайк: новый стан]"
    return "Мне тоже нравится\n[коммент: новый стан | гудит громче тебя]\n[статус: не должен пройти]"
answer(by_who)
r = run(relay.group_chat(relay.GroupReq(messages=[relay.GroupMsg(speaker="adonis", content="Я выложил пост про стан")], page=PAGE,
                                        aurora_tools=[], hespera_tools=[]), "Bearer tok"))
ar = [x for x in r["replies"] if x["who"] == "aurora"][0]
hr = [x for x in r["replies"] if x["who"] == "hespera"][0]
check("общий: Аврора без маркеров в тексте", ar["text"] == "Мне тоже нравится", ar)
check("общий: её комментарий передан приложению, статус нет", ar.get("markers") == ["[коммент: новый стан | гудит громче тебя]"], ar)
check("общий: лайк Гесперы в changes", any(c["kind"] == "лайк" and c["field"] == "p1" for c in r["changes"]), r["changes"])
check("общий: Геспера видит ленту", any("СТРАНИЦЫ В ПРИЛОЖЕНИИ" in s for s in seen["sys"]))

# --- пробуждение
answer("ПРОПУСК\n[коммент: лисы не спят | я тоже думаю о звёздах]")
r = run(relay.hespera_wake(relay.HesperaWakeReq(page=PAGE), "Bearer tok"))
check("пробуждение: молча оставила комментарий", r.get("skip") and any(c["kind"] == "коммент" and c["field"] == "p2" for c in r["changes"]), r)

# --- маркеры Авроры в пробуждении проходят
check("PROFILE_MARKER_RE ловит коммент", relay.PROFILE_MARKER_RE.findall("x [коммент: а | б]") == ["[коммент: а | б]"])

# --- вдвоём: Аврора комментирует, Геспера лайкает
n = {"i": 0}
def duo_ans(msgs):
    s = msgs[0]["content"] if msgs[0]["role"] == "system" else msgs[0]["content"]
    if "Перед тобой разговор Авроры и Гесперы" in s:
        return '{"topic": "стан", "aurora": "a", "hespera": "h"}'
    n["i"] += 1
    if "Ты Геспера" in s:
        return f"Реплика Гесперы номер {n['i']} про стан и звёзды\n[лайк: лисы не спят]"
    return f"Реплика Авроры номер {n['i']} совсем о другом\n[коммент: новый стан | громкий же]"
answer(duo_ans)
r = run(relay.duo_talk(relay.DuoReq(starter="aurora", max_turns=4, page=PAGE), "Bearer tok"))
check("вдвоём: комментарий Авроры уходит в aurora_markers", "[коммент: новый стан | громкий же]" in r["aurora_markers"], r["aurora_markers"])
check("вдвоём: в тексте Авроры маркера нет", all("[коммент" not in m["text"] for m in r["messages"]))
check("вдвоём: лайк Гесперы в changes", any(c["kind"] == "лайк" and c["field"] == "p2" for c in r["changes"]), r["changes"])

# --- новое для неё и фото из поста
import base64 as _b64
relay._hw("page_seen.json", [])
P2 = json.loads(json.dumps(PAGE))
P2["photo_b64"] = _b64.b64encode(b"\xff\xd8\xff fake jpeg").decode()
P2["photo_post"] = "p1"
txt, img = relay.hespera_page(P2, "привет", "chat")
check("первый раз оба поста помечены новыми", txt.count("- 🆕") == 2, txt)
check("новый пост с фото — фото приложено", img is not None and "приложено к сообщению Адониса картинкой" in txt, txt)
txt, img = relay.hespera_page(P2, "как дела", "chat")
check("второй раз нового нет и фото не шлётся зря", "- 🆕" not in txt and img is None and "само фото сейчас не приложено" in txt, txt)
txt, img = relay.hespera_page(P2, "посмотри последний пост в моём профиле", "chat")
check("Адонис говорит о посте — фото снова приложено", img is not None)
answer("Вижу! Стан огромный.")
seen.clear()
captured = {}
async def capt(msgs, model=None, timeout=100.0):
    captured["msgs"] = msgs
    return "Вижу! Стан огромный."
relay.ask_model = capt
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="посмотри мой пост")], page=P2), "Bearer tok"))
last = captured["msgs"][-1]["content"]
check("в чате фото из поста легло к последнему сообщению", isinstance(last, list) and any(x.get("type") == "image_url" for x in last), last)
d = run(relay.diag_page("Bearer tok"))
check("diag: видно, что лента пришла", d["got_page"] and d["posts_adonis"] == 1 and d["posts_aurora"] == 1 and d["photo_attached"] and d["where"] == "chat", d)
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="привет")]), "Bearer tok"))
d = run(relay.diag_page("Bearer tok"))
check("diag: старое приложение — ленты нет", d["got_page"] is False, d)

print(f"\nИтого: {ok_n} ок, {bad_n} нет")
sys.exit(1 if bad_n else 0)
