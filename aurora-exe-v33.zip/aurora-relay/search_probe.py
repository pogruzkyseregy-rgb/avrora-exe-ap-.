#!/usr/bin/env python3
"""Есть ли у провайдера модели, которые сами ищут в интернете.

Спрашивает о вчерашних новостях: без поиска модель этого знать не может. Для каждой модели пробует
её «родной» способ включить поиск. Печатает: ответила ли, есть ли в ответе служебные ссылки-источники
(надёжный признак поиска), сколько ссылок в тексте и начало ответа. Ключи не печатаются.

Запуск на сервере:  python3 /opt/aurora-relay/search_probe.py
"""
import datetime, json, os, re, sys, time, urllib.error, urllib.request
from concurrent.futures import ThreadPoolExecutor

ENV = os.environ.get("AURORA_ENV", "/opt/aurora-relay/relay.env")


def read_env(path):
    env = {}
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    return env


env = read_env(ENV)
URL, KEY = env["UPSTREAM_URL"], env["UPSTREAM_KEY"]
yesterday = (datetime.date.today() - datetime.timedelta(days=1)).strftime("%d.%m.%Y")
Q = (f"Найди в интернете: какие были главные новости в Липецке {yesterday}? "
     "Дай 2–3 новости коротко и ссылки на источники. Если не можешь искать в интернете — так и скажи одной фразой.")

# (подпись, модель, дополнительные поля запроса)
TRIES = [
    ("Grok: живой поиск", "grok-4.7", {"search_parameters": {"mode": "on", "return_citations": True}}),
    ("Grok: инструмент web_search", "grok-4.7", {"tools": [{"type": "web_search"}]}),
    ("Gemini: google_search", "gemini-3.8-flash", {"tools": [{"google_search": {}}]}),
    ("Gemini: googleSearch", "gemini-3.8-flash", {"tools": [{"googleSearch": {}}]}),
    ("Gemini: :online", "gemini-3.8-flash:online", {}),
    ("GPT: web_search_options", "gpt-5.5", {"web_search_options": {}}),
    ("GPT: инструмент web_search", "gpt-5.5", {"tools": [{"type": "web_search"}]}),
    ("Qwen: enable_search", "qwen3.8-max", {"enable_search": True}),
    ("GLM: web_search", "glm-5.3", {"tools": [{"type": "web_search", "web_search": {"enable": True, "search_result": True}}]}),
    ("Claude: web_search", "claude-sonnet-5-5", {"tools": [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]}),
    ("без поиска (для сравнения)", "deepseek-v4-flash", {}),
]


def call(label, model, extra):
    body = {"model": model, "messages": [{"role": "user", "content": Q}], **extra}
    req = urllib.request.Request(URL, data=json.dumps(body).encode(),
                                 headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return label, model, f"ошибка {e.code}: {e.read().decode(errors='replace')[:140]}", 0, False, time.time() - t0
    except Exception as e:
        return label, model, f"{type(e).__name__}: {str(e)[:120]}", 0, False, time.time() - t0
    msg = (data.get("choices") or [{}])[0].get("message", {}) or {}
    text = msg.get("content") or ""
    if isinstance(text, list):
        text = " ".join(p.get("text", "") for p in text if isinstance(p, dict))
    raw = json.dumps(data, ensure_ascii=False)
    cited = bool(data.get("citations") or data.get("search_results") or msg.get("annotations")
                 or "url_citation" in raw or "grounding" in raw.lower() or "web_search_result" in raw)
    links = len(set(re.findall(r"https?://[^\s)\]>\"']+", text)))
    return label, model, text.replace("\n", " ").strip()[:220], links, cited, time.time() - t0


print(f"Вопрос: новости Липецка за {yesterday}. Без поиска модель этого знать не может.\n")
with ThreadPoolExecutor(6) as ex:
    rows = list(ex.map(lambda t: call(*t), TRIES))
for label, model, text, links, cited, dt in rows:
    mark = "ИЩЕТ ✅" if cited else ("возможно ⚠️" if links >= 2 and not text.startswith("ошибка") else "нет ❌")
    print(f"— {label} [{model}] {dt:.0f} с: {mark}  (источников в ответе: {'есть' if cited else 'нет'}, ссылок в тексте: {links})")
    print(f"  {text}\n")
print("«ИЩЕТ ✅» — провайдер вернул служебные источники: модель правда искала.")
print("«возможно ⚠️» — ссылки есть только в тексте: открой одну и проверь, что новость правда вчерашняя.")
