#!/usr/bin/env python3
"""Проверка зрения: видят ли модель, Аврора, Геспера и общий чат приложенное фото.

Рисует картинку с известным содержимым (красный круг слева, зелёный квадрат справа, белый фон),
спрашивает «что на картинке» и проверяет ответ по словам. Ключи и токены не печатаются.

Запуск на сервере:  python3 /opt/aurora-relay/vision_check.py [ещё_модель ...]
Дополнительные имена моделей проверяются у того же провайдера — так можно найти модель со зрением.
"""
import base64, json, os, struct, sys, urllib.error, urllib.request, zlib

ENV = os.environ.get("AURORA_ENV", "/opt/aurora-relay/relay.env")
RELAY = os.environ.get("RELAY_URL", "http://127.0.0.1:8765")
QUESTION = "Что изображено на картинке? Перечисли фигуры и их цвета. Ответь одним коротким предложением."


def read_env(path):
    env = {}
    try:
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        sys.exit(f"Не нашёл {path}. Укажи путь: AURORA_ENV=/путь/relay.env python3 vision_check.py")
    return env


def png(w=256, h=256):
    """PNG без сторонних библиотек: красный круг слева, зелёный квадрат справа."""
    rows = []
    for y in range(h):
        row = bytearray([0])
        for x in range(w):
            r, g, b = 255, 255, 255
            if (x - 72) ** 2 + (y - 128) ** 2 <= 46 ** 2:
                r, g, b = 220, 20, 20
            elif 150 <= x <= 230 and 88 <= y <= 168:
                r, g, b = 20, 170, 40
            row += bytes([r, g, b])
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows), 9)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", raw) + chunk(b"IEND", b"")


def verdict(text):
    t = (text or "").lower()
    red = "красн" in t or "red" in t
    green = "зелён" in t or "зелен" in t or "green" in t
    circle = "круг" in t or "circle" in t or "окружн" in t
    square = "квадрат" in t or "square" in t or "прямоуг" in t
    score = sum([red, green, circle, square])
    if score >= 3:
        return "ВИДИТ ✅"
    if score >= 1:
        return "частично (проверь ответ глазами) ⚠️"
    return "НЕ ВИДИТ ❌"


def post(url, headers, body, timeout=120):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={**headers, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, {"error": e.read().decode(errors="replace")[:300]}
    except Exception as e:  # сеть, таймаут
        return 0, {"error": f"{type(e).__name__}: {str(e)[:200]}"}


def show(title, status, text):
    print(f"\n— {title}")
    if status != 200:
        print(f"  ошибка {status}: {text}")
        print("  итог: НЕ ВИДИТ ❌ (запрос с картинкой не прошёл)")
        return
    print(f"  ответ: {text.strip()[:300]}")
    print(f"  итог: {verdict(text)}")


def main():
    env = read_env(ENV)
    url, key = env.get("UPSTREAM_URL", ""), env.get("UPSTREAM_KEY", "")
    model = env.get("MODEL", "")
    token = env.get("APP_TOKEN", "")
    b64 = base64.b64encode(png()).decode()
    image_part = {"type": "image_url", "image_url": {"url": "data:image/png;base64," + b64}}

    print("ПРОВЕРКА ЗРЕНИЯ. На картинке: красный круг слева и зелёный квадрат справа на белом фоне.")

    # 1. Модели напрямую у провайдера
    models = [m for m in [model, env.get("MEMORY_MODEL", "")] + sys.argv[1:] if m]
    seen = set()
    for m in models:
        if m in seen:
            continue
        seen.add(m)
        st, data = post(url, {"Authorization": f"Bearer {key}"},
                        {"model": m, "messages": [{"role": "user", "content": [{"type": "text", "text": QUESTION}, image_part]}]})
        text = data.get("choices", [{}])[0].get("message", {}).get("content", "") if st == 200 else data.get("error", "")
        show(f"модель напрямую: {m}", st, text)
    if env.get("FALLBACK_URL") and env.get("FALLBACK_KEY"):
        fm = env.get("FALLBACK_MODEL", "") or model
        st, data = post(env["FALLBACK_URL"], {"Authorization": f"Bearer {env['FALLBACK_KEY']}"},
                        {"model": fm, "messages": [{"role": "user", "content": [{"type": "text", "text": QUESTION}, image_part]}]})
        text = data.get("choices", [{}])[0].get("message", {}).get("content", "") if st == 200 else data.get("error", "")
        show(f"запасной провайдер: {fm}", st, text)

    # 2. Через сервер — так же, как это делает приложение
    auth = {"Authorization": f"Bearer {token}"}
    note = "[Адонис прислал фото, оно приложено к этому сообщению, ты его видишь]\n" + QUESTION
    img = [{"i": 0, "data": b64}]
    st, data = post(RELAY + "/chat", auth, {"messages": [{"role": "user", "content": note}], "images": img})
    show("Аврора (личка, /chat)", st, data.get("reply", "") if st == 200 else data.get("error", data.get("detail", "")))
    st, data = post(RELAY + "/hespera/chat", auth, {"messages": [{"role": "user", "content": note}], "images": img})
    show("Геспера (личка, /hespera/chat)", st, data.get("reply", "") if st == 200 else data.get("error", data.get("detail", "")))
    st, data = post(RELAY + "/group/chat", auth, {"messages": [{"speaker": "adonis", "content": "[фото] Аврора, Геспера, " + QUESTION}],
                                                  "images": img, "responders": ["aurora", "hespera"]}, timeout=240)
    if st == 200:
        for r in data.get("replies", []):
            show(f"общий чат: {r.get('who')}", 200, r.get("text", ""))
        if not data.get("replies"):
            show("общий чат", 200, "(обе промолчали)")
    else:
        show("общий чат", st, data.get("error", ""))

    # 3. Какие модели есть у провайдера (если он отдаёт список) — ищем со зрением
    base = url.rsplit("/chat/completions", 1)[0]
    try:
        req = urllib.request.Request(base + "/models", headers={"Authorization": f"Bearer {key}"})
        with urllib.request.urlopen(req, timeout=30) as r:
            ids = [x.get("id", "") for x in json.loads(r.read().decode()).get("data", [])]
        hints = ("vl", "vision", "4o", "gemini", "claude", "gpt-4.1", "gpt-5", "qwen3-vl", "pixtral", "llava", "omni")
        cand = sorted({i for i in ids if any(h in i.lower() for h in hints)})
        print(f"\nУ провайдера моделей: {len(ids)}. Похожие на модели со зрением: " + (", ".join(cand[:30]) if cand else "не нашёл по названиям"))
    except Exception as e:
        print(f"\nСписок моделей провайдер не отдал ({type(e).__name__}).")
    print("\nЕсли где-то «НЕ ВИДИТ»: пришли этот вывод — переключу фото на модель, которая видит.")


if __name__ == "__main__":
    main()
