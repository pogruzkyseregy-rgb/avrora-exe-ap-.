package ru.avrora.exe

import java.util.Calendar
import java.util.TimeZone

var aok = 0
var abad = 0
fun acheck(name: String, c: Boolean, info: String = "") { if (c) { aok++; println("[ОК]   $name") } else { abad++; println("[НЕТ]  $name $info") } }

fun main() {
    val tz = TimeZone.getTimeZone("Europe/Moscow")
    val cal = Calendar.getInstance(tz).apply { set(2026, Calendar.OCTOBER, 22, 14, 40, 0); set(Calendar.MILLISECOND, 0) }   // четверг
    val now = cal.timeInMillis
    fun at(dayShift: Int, h: Int, m: Int): Long = Calendar.getInstance(tz).apply { timeInMillis = now; add(Calendar.DAY_OF_YEAR, dayShift); set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

    acheck("разовый на позже сегодня", onceAtFor(18, 0, now, tz) == at(0, 18, 0))
    acheck("разовый на прошедшее время уходит на завтра", onceAtFor(7, 30, now, tz) == at(1, 7, 30))
    val once = AlarmItem("a", 7, 30, onceAt = onceAtFor(7, 30, now, tz))
    acheck("разовый звонит один раз", nextFire(once, now, tz) == at(1, 7, 30) && nextFire(afterFire(once, at(1, 7, 30)), at(1, 7, 31), tz) == null)
    val week = AlarmItem("b", 7, 0, days = setOf(1, 2, 3, 4, 5))
    acheck("по будням: следующий в пятницу", nextFire(week, now, tz) == at(1, 7, 0))
    acheck("по будням: после пятницы понедельник", nextFire(week, at(1, 7, 1), tz) == at(4, 7, 0))
    acheck("сегодня ещё не прошёл", nextFire(AlarmItem("c", 15, 0, days = setOf(4)), now, tz) == at(0, 15, 0))
    acheck("выключенный не звонит", nextFire(week.copy(enabled = false), now, tz) == null)
    val sn = snoozed(week, now)
    acheck("отложенный звонит через 10 минут", nextFire(sn, now, tz) == now + 10 * 60_000L && sn.lastAction == "snoozed")
    acheck("ближайший из нескольких", nextAlarm(listOf(week, once, AlarmItem("d", 16, 0, days = setOf(4))), now, tz)?.first?.id == "d")
    acheck("дни словами", alarmDaysText(week) == "по будням" && alarmDaysText(once) == "один раз" && alarmDaysText(AlarmItem("e", 1, 1, days = setOf(1, 3))) == "Пн Ср")

    val d = acceptAuroraAlarm(emptyList(), "через 20 мин", "проснись, есть новость", now, "x", tz)
    acheck("её будильник через 20 минут", d.alarm != null && d.alarm.onceAt == now + 20 * 60_000L && d.alarm.by == "aurora" && d.alarm.hour == 15 && d.alarm.minute == 0, d.toString())
    acheck("её будильник на время", acceptAuroraAlarm(emptyList(), "08:15", "утро", now, "y", tz).alarm?.onceAt == at(1, 8, 15))
    acheck("кривое время отклоняется с причиной", acceptAuroraAlarm(emptyList(), "утром", "", now, "z", tz).let { it.alarm == null && it.why.isNotBlank() })
    acheck("дальше двух суток нельзя", acceptAuroraAlarm(emptyList(), "через 60 ч", "", now, "z", tz).alarm == null)
    val three = (1..3).map { AlarmItem("h$it", 9, 0, by = "aurora", onceAt = now + it * 3_600_000L, created = now - 1000) }
    acheck("не больше трёх в сутки", acceptAuroraAlarm(three, "через 5 ч", "", now, "q", tz).alarm == null)
    val old = three.map { it.copy(created = now - 30 * 3_600_000L) }
    acheck("и не больше трёх ждущих", acceptAuroraAlarm(old, "через 5 ч", "", now, "q", tz).why.contains("ждут"))

    val ctx = alarmsContext(listOf(week, d.alarm!!, once.copy(by = "aurora", label = "вставай", lastAction = "dismissed", lastActionAt = now - 1000, enabled = false)), now, tz)
    acheck("контекст для неё", ctx.contains("по будням") && ctx.contains("ставила ты: «проснись, есть новость»") && ctx.contains("Адонис выключил"), ctx)
    acheck("пусто: контекста нет", alarmsContext(emptyList(), now, tz).isEmpty())

    val pp = parseParts("Не спи. [будильник: через 20 мин | есть разговор] Жду.")
    acheck("маркер будильника разобран", pp.any { it is Part.Alarm && it.whenText == "через 20 мин" && it.label == "есть разговор" } && pp.filterIsInstance<Part.Text>().none { it.s.contains("[") })
    acheck("маркер без подписи", parseParts("[будильник: 07:30]").any { it is Part.Alarm && it.whenText == "07:30" && it.label.isEmpty() })
    println("\nИТОГ: ок $aok, нет $abad")
    if (abad > 0) System.exit(1)
}
