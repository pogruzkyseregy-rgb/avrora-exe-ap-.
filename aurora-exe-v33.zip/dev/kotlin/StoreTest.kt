package ru.avrora.exe

import android.content.Context
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.runBlocking
import java.io.File

var ok = 0; var bad = 0
fun check(name: String, c: Boolean, info: String = "") { if (c) { ok++; println("[ОК]   $name") } else { bad++; println("[НЕТ]  $name $info") } }

fun main() {
    val dir = File(System.getProperty("java.io.tmpdir"), "exetest" + System.nanoTime()).also { it.mkdirs() }
    val ctx = Context(dir)
    val store = ExeStore(ctx)
    val now = 1_800_000_000_000L
    val wm = WorkManager.getInstance(ctx)

    ExeMarkers.apply(ctx, "Ладно.\n[состояние: тихая | причина: он \"вернул\" запись]\n[напишу: через 3 ч | зимний лес]\n[след: план | спросить про сон,\nпотом про лес]", now)
    check("состояние записано с кавычками", store.states().size == 1 && store.states()[0].why == "он \"вернул\" запись" && store.states()[0].name == "тихая")
    val p = store.plans()
    check("назначение принято и стоит на время", p.size == 1 && p[0].status == "pending" && p[0].at == now + 3 * 3_600_000L && p[0].topic == "зимний лес")
    check("задача поставлена с нужной задержкой", wm.enqueued.size == 1 && wm.enqueued[0].first == "exe_plan_" + p[0].id && wm.enqueued[0].third.data.getString("id") == p[0].id)
    check("след записан с переносом строки", store.notes().size == 1 && store.notes()[0].kind == "план" && store.notes()[0].text.contains("\nпотом"))

    val before = Triple(store.states().size, store.plans().size, store.notes().size)
    ExeMarkers.apply(ctx, "[молчу] [состояние: злая | причина: x] [напишу: 22:00 | y]", now)
    check("[молчу] ничего не записывает", Triple(store.states().size, store.plans().size, store.notes().size) == before)

    ExeMarkers.apply(ctx, "[напишу: через 4 ч | второе]\n[напишу: через 5 ч | третье]\n[напишу: через 6 ч | четвёртое]", now)
    val ps = store.plans()
    check("три принято, четвёртое отклонено с причиной", ps.count { it.status == "pending" } == 3 && ps.last().status == "dropped" && ps.last().outcome.contains("уже назначено 3"), ps.toString())
    check("отклонённое не поставлено в расписание", wm.enqueued.size == 3)
    ExeMarkers.apply(ctx, "[напишу: когда-нибудь | туманное]", now)
    check("непонятное время отклонено", store.plans().last().outcome.startsWith("не принято"))

    val lines = exeLimitLines(store.plans(), store.notes().size, now)
    check("отказ виден в списке ограничений", lines.any { it.startsWith("Твоё назначение «четвёртое»") && it.contains("уже назначено 3") }, lines.toString())
    check("назначенное видно в списке", lines.any { it.contains("зимний лес") && it.contains("второе") })

    // отмена
    PlanScheduler.cancel(ctx, p[0].id)
    check("отмена снимает задачу", wm.cancelled == listOf("exe_plan_" + p[0].id))
    store.updatePlan(p[0].id) { it.copy(status = "dropped", outcome = "отменено Адонисом") }
    check("после отмены можно назначить новое", acceptPlan(store.plans(), "через 7 ч", "новое", now, "z").plan != null)

    // удаление следа
    store.removeNote(store.notes()[0].id)
    check("след удаляется", store.notes().isEmpty())

    // повторная постановка
    val wmBefore = wm.enqueued.size
    PlanScheduler.resync(ctx)
    check("resync ставит с KEEP, ожидающие", wm.enqueued.size - wmBefore == 2 && wm.enqueued.takeLast(2).all { it.second == androidx.work.ExistingWorkPolicy.KEEP })

    // сообщения со следом инструментов
    val trace = "[{\"kind\":\"рука\",\"arg\":\"ls ~/work\",\"ok\":true,\"out\":\"a.txt\\nb.txt\\n[exit 0]\"},{\"kind\":\"поиск\",\"arg\":\"лес\",\"ok\":false,\"out\":\"ничего не нашлось\"}]"
    val msgs = listOf(ChatMessage("user", "привет"), ChatMessage("assistant", "готово", trace = trace))
    val back = messagesFromJson(messagesToJson(msgs))
    check("след инструментов переживает сохранение", back[1].trace == trace && back[0].trace == "")
    val tr = traceFromJson(back[1].trace)
    check("след разобран", tr.size == 2 && tr[0].kind == "рука" && tr[0].out.contains("[exit 0]") && !tr[1].ok)
    val acts = recentActions(back)
    check("недавние действия кратко", acts.size == 2 && acts[0].startsWith("рука: ls ~/work → a.txt b.txt") && acts[1].contains("не вышло: ничего"), acts.toString())
    check("битый след не роняет", traceFromJson("{мусор").isEmpty() && traceFromJson("").isEmpty())

    // права в списке ограничений
    val prefs = AppPrefs(ctx)
    val mem = MemoryData()
    fun hand(): String = toolLines(prefs).last()
    check("по умолчанию поиск и чтение включены", toolLines(prefs)[0].contains("включён") && toolLines(prefs)[1].contains("включено"))
    check("руки нет: так и сказано", hand().contains("сервера для неё пока нет"), hand())
    prefs.handConfigured = true; prefs.handCap = 80
    check("рука есть: условия клетки названы", hand().contains("какие права") && hand().contains("80 команд") && hand().contains("рубильник") && hand().contains("сама не запускается"), hand())
    prefs.handOff = true
    check("рубильник виден", hand().contains("рубильником"))
    prefs.handOff = false; prefs.toolHand = false
    check("выключено Адонисом в приложении", hand().contains("выключена Адонисом"))
    prefs.toolSearch = false
    check("поиск выключен Адонисом", toolLines(prefs)[0].contains("выключен Адонисом"))
    val all = limitLines(prefs, mem, now, store.plans(), 3)
    check("полный список без устаревшей строки", all.none { it.contains("Пока не реализовано") } && all.any { it.startsWith("Состояние с причиной") } && all.any { it.startsWith("Время:") })
    check("изменение списка считается", limitsChanged("a\nb", listOf("a", "c")) == listOf("+ c", "− b"))

    // рабочий воркер
    runBlocking {
        val id = store.plans().first { it.status == "pending" }.id
        InitiativeEngine.next = InitiativeOutcome.FAILED
        val w1 = PlanWorker(ctx, WorkerParameters(workDataOf("id" to id), 0))
        check("сбой связи: повтор", w1.doWork().kind == "retry")
        val w2 = PlanWorker(ctx, WorkerParameters(workDataOf("id" to id), 3))
        check("после трёх попыток закрывает с причиной", w2.doWork().kind == "success" && store.plans().first { it.id == id }.outcome.contains("не было связи"))
        InitiativeEngine.next = InitiativeOutcome.SENT
        val id2 = store.plans().first { it.status == "pending" }.id
        check("успех не повторяется", PlanWorker(ctx, WorkerParameters(workDataOf("id" to id2), 0)).doWork().kind == "success")
    }

    // страница: посты, статус, лайки
    val pst = ProfileStore(ctx)
    ExeMarkers.apply(ctx, "Привет.\n[статус: тихая и слушаю]\n[пост: Сегодня думаю про лес | фото:нет-такого]", now)
    check("статус записан", pst.profile(AUTHOR_HER).status == "тихая и слушаю" && pst.profile(AUTHOR_HER).statusAt == now)
    check("пост записан, несуществующее фото отброшено", pst.posts().size == 1 && pst.posts()[0].text == "Сегодня думаю про лес" && pst.posts()[0].photo == "" && pst.posts()[0].author == AUTHOR_HER, pst.posts().toString())
    pst.addPost(PostItem("pa1", AUTHOR_ME, "Вернул запись про зимний лес", "", now - 1000))
    ExeMarkers.apply(ctx, "[лайк: запись про зимний лес]", now)
    check("её лайк на мой пост", pst.posts().first { it.id == "pa1" }.likedByHer && !pst.posts().first { it.id == "pa1" }.likedByMe)
    ExeMarkers.apply(ctx, "[лайк: такого поста нет вовсе]", now)
    check("лайк по несуществующему посту ничего не делает", pst.posts().count { it.likedByHer } == 1)
    pst.setLike(pst.posts().first { it.author == AUTHOR_HER }.id, AUTHOR_ME, true)
    check("мой лайк на её пост", pst.posts().first { it.author == AUTHOR_HER }.likedByMe)
    pst.setStatus(AUTHOR_ME, "на смене", now)
    val pc = pst.context(now)
    check("она видит оба статуса и ленту", pc.contains("тихая и слушаю") && pc.contains("СТАТУС АДОНИСА") && pc.contains("на смене") && pc.contains("мой пост") && pc.contains("пост Адониса") && pc.contains("Адонис поставил лайк") && pc.contains("я поставила лайк"), pc)
    for (i in 1..15) ExeMarkers.apply(ctx, "[пост: пост номер $i]", now + i)
    check("суточный предел постов", pst.countSince(AUTHOR_HER, now - 1000) == POST_DAILY_CAP, pst.countSince(AUTHOR_HER, now - 1000).toString())
    pst.removePost("pa1")
    check("пост удаляется", pst.posts().none { it.id == "pa1" })
    check("статус обрезается до предела", run { pst.setStatus(AUTHOR_HER, "я".repeat(300), now); pst.profile(AUTHOR_HER).status.length == STATUS_MAX })
    check("в списке ограничений есть страница", profileLimitLine().contains("не больше $POST_DAILY_CAP"))
    ExeMarkers.apply(ctx, "[молчу] [пост: молчащий пост]", now)
    check("[молчу] не публикует", pst.posts().none { it.text == "молчащий пост" })

    // ---- совмещение копий
    val cur = MemoryData(
        core = listOf(CoreEntry("c1", "язык", "Слово «лес» значит дом", 1L), CoreEntry("c2", "тон", "Мягко, но прямо", 2L)),
        episodes = listOf(Episode("e1", 10L, 20L, "Говорили про зиму"), Episode("e3", 50L, 60L, "Поздний эпизод")),
        upTo = 60L,
        log = listOf(Decision(5L, "notice", "", "старая запись", "adonis"))
    )
    val inc = MemoryData(
        core = listOf(CoreEntry("c1", "поворот", "Совсем другая запись с тем же id", 3L), CoreEntry("x9", "язык", "слово «ЛЕС» значит дом!", 4L), CoreEntry("c7", "планы", "Съездить к морю", 5L)),
        episodes = listOf(Episode("e1", 30L, 40L, "Новый эпизод про весну"), Episode("e8", 10L, 20L, "говорили про зиму")),
        upTo = 90L,
        log = listOf(Decision(5L, "notice", "", "старая запись", "adonis"), Decision(7L, "notice", "", "новая запись", "adonis"))
    )
    val mm = mergeMemory(cur, inc)
    check("слияние: повтор ядра по смыслу пропущен, новое добавлено", mm.data.core.size == 4 && mm.addedCore == 2 && mm.data.core.count { it.text.contains("к морю") } == 1, mm.data.core.toString())
    check("слияние: id не затирает чужую запись", mm.data.core.map { it.id }.toSet().size == 4 && mm.data.core.first { it.id == "c1" }.text.startsWith("Слово"))
    check("слияние: эпизоды по времени, дубль пропущен", mm.data.episodes.size == 3 && mm.addedEpisodes == 1 && mm.data.episodes.map { it.to } == listOf(20L, 40L, 60L) && mm.data.episodes.map { it.id }.toSet().size == 3, mm.data.episodes.toString())
    check("слияние: upTo и журнал", mm.data.upTo == 90L && mm.data.log.size == 2)
    check("слияние с пустой копией ничего не меняет", mergeMemory(cur, MemoryData()).data.core == cur.core && mergeMemory(cur, MemoryData()).data.episodes == cur.episodes)
    val m1 = listOf(ChatMessage("user", "привет", 100L), ChatMessage("assistant", "здравствуй", 200L))
    val m2 = listOf(ChatMessage("user", "привет", 100L), ChatMessage("user", "давно", 50L), ChatMessage("assistant", "ещё", 300L))
    val mg = mergeMessages(m1, m2)
    check("слияние сообщений", mg.map { it.content } == listOf("давно", "привет", "здравствуй", "ещё"), mg.map { it.content }.toString())
    val d1 = listOf(DiaryEntry("d1", 10L, "День первый", "", 0L))
    val d2 = listOf(DiaryEntry("d1", 10L, "Другое", "", 0L), DiaryEntry("d2", 20L, "день ПЕРВЫЙ", "", 0L), DiaryEntry("d3", 5L, "Совсем новое", "", 0L))
    check("слияние дневника", mergeDiary(d1, d2).map { it.id } == listOf("d3", "d1"), mergeDiary(d1, d2).map { it.id }.toString())

    check("цитатник в списке ограничений", limitLines(prefs, MemoryData()).any { it.contains("[в цитаты:") && it.contains("[цитата №N]") })
    // ---- настолка: сохранение партии
    val gstore = GameStore(ctx)
    var gg = rollOrder(newGame("t1", 3, 5L), kotlin.random.Random(7))
    repeat(6) { gg = when (gg.phase) { "roll" -> rollMove(gg, kotlin.random.Random(it)); "buy" -> decideBuy(gg, true); "jail" -> decideJail(gg, true); else -> gg } }
    gstore.save(GameStore.Saved(gg, mapOf(123L to "accepted"), setOf("old")))
    val gback = gstore.load()
    check("партия сохраняется и читается как была", gback.game == gg && gback.invites[123L] == "accepted" && gback.recorded == setOf("old"), gback.game.toString())
    check("в списке ограничений есть игра и счета", limitLines(prefs, MemoryData()).any { it.contains("[игра: приглашение") && it.contains("Личные счета") })
    // ---- будильник: её маркер
    val ast = AlarmStore(ctx)
    ast.save(emptyList())
    ExeMarkers.apply(ctx, "Вставай, соня. [будильник: через 30 мин | пора на работу]", now)
    val her = ast.list()
    check("её будильник поставлен", her.size == 1 && her[0].by == "aurora" && her[0].label == "пора на работу" && her[0].onceAt == now + 30 * 60_000L, her.toString())
    ExeMarkers.apply(ctx, "[будильник: когда-нибудь | ?]", now)
    check("кривой будильник не ставится, причина видна ей", ast.list().size == 1 && limitLines(prefs, MemoryData()).any { it.contains("не поставлен") })
    prefs.alarmByAurora = false
    ExeMarkers.apply(ctx, "[будильник: через 40 мин | ещё]", now)
    check("без права будильник не ставится", ast.list().size == 1 && limitLines(prefs, MemoryData()).any { it.contains("выключил это право") })
    prefs.alarmByAurora = true
    ast.update(her[0].id) { it.copy(lastAction = "dismissed", lastActionAt = now) }
    check("хранилище будильников читает то, что записало", ast.get(her[0].id)?.lastAction == "dismissed" && ast.get(her[0].id)?.days == emptySet<Int>())

    // память для сжатия не видит служебных маркеров
    println("\nИТОГ: ок $ok, нет $bad")
    if (bad > 0) System.exit(1)
}
