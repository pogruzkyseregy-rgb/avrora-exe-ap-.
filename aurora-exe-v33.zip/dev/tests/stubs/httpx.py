class HTTPError(Exception): pass
class TimeoutException(HTTPError): pass
class ConnectTimeout(TimeoutException): pass
class ReadTimeout(TimeoutException): pass
class HTTPStatusError(HTTPError):
    def __init__(self, msg='', request=None, response=None):
        super().__init__(msg); self.response = response
class Timeout:
    def __init__(self, *a, **k): pass
class URL:
    def __init__(self, s): self.s = s
    def join(self, loc):
        from urllib.parse import urljoin
        return URL(urljoin(self.s, loc))
    def __str__(self): return self.s
class AsyncClient:  # заменяется в тестах
    def __init__(self, *a, **k): raise RuntimeError("сеть в тестах закрыта")
