"""Творчество: рисование через API, музыка нотами, метки медиа. Без сети и без синтезатора."""
import asyncio, base64, json, os, struct, sys, tempfile, zlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://up/v1/chat/completions", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=TMP + "/core.md",
                  FLOOR_PATH=TMP + "/floor.md", HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off", PUBLIC_TOKEN="pub",
                  PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/pc.md", FEEDBACK_LOG=TMP + "/f.jsonl",
                  TOOLS_STATE=TMP + "/t.json", HESPERA_DIR=TMP + "/h", DUO_DIR=TMP + "/d", SEARCH_MODEL="off",
                  MEDIA_DIR=TMP + "/media", CREATIVE_STATE=TMP + "/cs.json", CREATIVE_KEY="ck", IMAGE_DAILY_CAP="3", MUSIC_SF2="")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

def png():
    raw = b"".join(b"\x00" + b"\xff\x00\x00" * 4 for _ in range(4))
    ch = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", 4, 4, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b"")
PNG = png()

# --- маркеры
E = ["рисование", "музыка"]
r = "Сейчас.\n[нарисовать: лиса на крыше под северным сиянием]\n[музыка: Ночь]\nX:1\nK:Am\nA2 c2 e2|\n[/музыка]\nВот."
calls = relay.find_tool_calls(r, E)
check("маркеры рисования и музыки находятся", [k for k, _ in calls] == ["нарисовать", "музыка"] and calls[1][1].startswith("Ночь\nX:1"), calls)
check("без права — не находятся", relay.find_tool_calls(r, ["поиск"]) == [])
check("маркеры вычищаются из ответа", relay.strip_tools(r) == "Сейчас.\n\nВот." or relay.strip_tools(r).replace("\n", "") == "Сейчас.Вот.", relay.strip_tools(r))

# --- рисование: разбор разных ответов провайдера
class Resp:
    def __init__(self, status, data=None, content=b""):
        self.status_code = status; self._d = data; self.content = content; self.text = json.dumps(data) if data else ""
    def json(self): return self._d
script = []
class Client:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def post(self, url, headers=None, json=None):
        Client.posts.append((url, headers, json)); return script.pop(0)
    async def get(self, url): Client.gets.append(url); return Resp(200, content=PNG)
Client.posts, Client.gets = [], []
relay.httpx.AsyncClient = Client
b64 = base64.b64encode(PNG).decode()
script[:] = [Resp(200, {"data": [{"b64_json": b64}]})]
ok, err, raw = run(relay.gen_image_with("gpt-image-2", "лиса"))
check("картинка из /images/generations", ok and raw == PNG and Client.posts[0][0] == "http://up/v1/images/generations" and Client.posts[0][1]["Authorization"] == "Bearer ck", (ok, err))
script[:] = [Resp(404, {"error": "no"}), Resp(200, {"choices": [{"message": {"content": "вот", "images": [{"image_url": {"url": "data:image/png;base64," + b64}}]}}]})]
ok, err, raw = run(relay.gen_image_with("nano-banana-2", "лиса"))
check("если картинки отдаются через чат — берём оттуда", ok and raw == PNG, err)
script[:] = [Resp(400, {"error": "x"}), Resp(200, {"choices": [{"message": {"content": "Готово ![img](https://cdn.x/a.png)"}}]})]
ok, err, raw = run(relay.gen_image_with("grok-imagine-image", "лиса"))
check("ссылка на картинку в тексте — скачиваем", ok and Client.gets[-1] == "https://cdn.x/a.png", err)
script[:] = [Resp(400, {"error": "x"}), Resp(200, {"choices": [{"message": {"content": "не умею рисовать"}}]})]
ok, err, raw = run(relay.gen_image_with("deepseek", "лиса"))
check("модель не рисует — честная ошибка", not ok and "без картинки" in err, err)

calls_m = []
async def gen_ok(model, prompt):
    calls_m.append(model); return (model != "gpt-image-2", "" if model != "gpt-image-2" else "gpt-image-2: images 500", PNG)
relay.gen_image_with = gen_ok
ok, msg, tag, raw = run(relay.tool_draw("лиса на крыше"))
check("основная модель упала — рисует запасная", ok and calls_m[:2] == ["gpt-image-2", "nano-banana-2"] and "nano-banana-2" in msg, (msg, calls_m))
mid = tag.split(":", 1)[1].split("|")[0].strip()
check("файл сохранён, метка с названием", tag.startswith("[медиа: img_") and tag.endswith("| лиса на крыше]") and (relay.MEDIA_DIR / mid).read_bytes() == PNG, tag)
run(relay.tool_draw("2")); run(relay.tool_draw("3"))
ok, msg, tag, raw = run(relay.tool_draw("4"))
check("дневной лимит картинок", not ok and "кончились" in msg, msg)

# --- выдача файла приложению
resp = run(relay.media_get(mid, "Bearer tok"))
check("файл отдаётся приложению", resp.body == PNG and resp.media_type == "image/png")
try:
    run(relay.media_get("../../etc/passwd", "Bearer tok")); check("чужой путь не отдаётся", False)
except relay.HTTPException as e:
    check("чужой путь не отдаётся", e.status_code == 404)

# --- музыка
ok, msg, raw, secs = run(relay.render_abc("K:C\nCDEF|"))
import shutil
if not (shutil.which("abc2midi") and shutil.which("fluidsynth")):
    check("без синтезатора — подсказка, что поставить", not ok and "apt-get install -y abcmidi fluidsynth" in msg, msg)
async def render_ok(abc):
    render_ok.last = abc; return True, "", b"ID3mp3data", 83.0
relay.render_abc = render_ok
ok, msg, tag = run(relay.tool_music("Ночь над Липецком\nX:1\nK:Am\nA2 c2 e2 a2|"))
check("трек: метка, длительность, файл", ok and "1:23" in msg and tag.startswith("[медиа: mus_") and tag.endswith("| Ночь над Липецком]"), (msg, tag))
ok, msg, tag = run(relay.tool_music("Пусто\n"))
check("без нот — объясняем формат", not ok and "ABC" in msg, msg)

relay.CREATIVE_STATE.unlink()
# --- весь цикл: нарисовала и сочинила, ответ с настоящими метками
seq = ["Держи.\n[нарисовать: лиса]\n[музыка: Тема]\nX:1\nK:C\nCDEF GABc|\n[/музыка]",
       "Вот лиса и тема для неё. [медиа: img_1_deadbeef.png | фейк]"]
seen = []
async def model(msgs, model=None, timeout=100.0):
    seen.append(msgs); return seq.pop(0)
relay.ask_model = model
reply, trace = run(relay.run_with_tools("SYS", [{"role": "user", "content": "нарисуй и сыграй"}], E))
tags = relay.MEDIA_TAG_RE.findall(reply)
check("в ответе — настоящие метки, выдуманная убрана", len(tags) == 2 and "deadbeef" not in reply and reply.startswith("Вот лиса"), reply)
check("свою картинку она видит", isinstance(seen[1][-1]["content"], list) and seen[1][-1]["content"][1]["type"] == "image_url")
check("в консоли видно, что делала", [t["kind"] for t in trace] == ["нарисовать", "музыка"] and all(t["ok"] for t in trace), trace)

# --- пробуждение: промолчала, но с готовым треком — показывает
check("ПРОПУСК с треком превращается в сообщение", relay.attach_media("ПРОПУСК\nПРОСНУСЬ: 2 ч", ["[медиа: mus_1_aaaaaaaa.mp3 | Т]"]) ==
      "СООБЩЕНИЕ: [медиа: mus_1_aaaaaaaa.mp3 | Т]\nПРОСНУСЬ: 2 ч", relay.attach_media("ПРОПУСК\nПРОСНУСЬ: 2 ч", ["[медиа: mus_1_aaaaaaaa.mp3 | Т]"]))
out = relay.parse_initiative(relay.attach_media("ПРОПУСК\nПРОСНУСЬ: 2 ч", ["[медиа: mus_1_aaaaaaaa.mp3 | Т]"]), False, True)
check("…и уходит как сообщение с меткой и временем пробуждения", "медиа" in out.get("message", "") and out.get("wake_min") == 120, out)
note = relay.tools_note(E, who="hespera")
check("в правилах — как рисовать и как писать ноты", "[нарисовать:" in note and "%%MIDI program" in note and "Авророй" in note)
d = run(relay.diag_creative(0, "Bearer tok"))
check("проверка творчества: музыка играется", d["music"]["ok"] and d["music"]["media"].startswith("[медиа: mus_") and d["creative_key"] == "свой", d)
# --- общий чат: инструменты работают и там
relay.remember_tools(["рисование"], "aurora")
relay.remember_tools(["рисование", "музыка"], "hespera")
check("права запоминаются у каждой свои", relay.last_tools("aurora") == ["рисование"] and relay.last_tools("hespera") == ["рисование", "музыка"])
relay.CREATIVE_STATE.unlink(missing_ok=True)
seq2 = {"a": ["Делаю прогон себя. [нарисовать: серебряная лиса]", "Вот я."], "h": ["Обещаю: нарисую себя потом.", "[нарисовать: чёрные волосы, золотой глаз]", "Вот."]}
seen_g = []
async def gmodel(msgs, model=None, timeout=100.0):
    seen_g.append(msgs)
    return seq2["h" if "Ты Геспера" in msgs[0]["content"] else "a"].pop(0)
relay.ask_model = gmodel
G = relay.GroupMsg
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="adonis", content="Аврора, Геспера, нарисуйте себя")]), "Bearer tok"))
texts = {x["who"]: x["text"] for x in r["replies"]}
check("в общем чате Аврора рисует сразу", "[медиа: img_" in texts.get("aurora", "") and texts["aurora"].startswith("Вот я."), r)
check("Геспера пообещала — напоминание, и картинка есть", "[медиа: img_" in texts.get("hespera", "") and any("«Потом» не наступит" in str(m[-1]["content"]) for m in seen_g), texts)
check("в общем чате видно, что делали", all(x.get("trace") for x in r["replies"]))
check("правило общего чата: инструменты работают", "работают твои инструменты" in seen_g[0][0]["content"])
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
