"""Папки на машине руки, страница и аватар Гесперы. Без сети; ssh заменён запуском bash здесь же."""
import asyncio, base64, json, os, struct, subprocess, sys, tempfile, zlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://up/v1/chat/completions", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=TMP + "/core.md",
                  FLOOR_PATH=TMP + "/floor.md", HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off", PUBLIC_TOKEN="pub",
                  PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/pc.md", FEEDBACK_LOG=TMP + "/f.jsonl",
                  TOOLS_STATE=TMP + "/t.json", HESPERA_DIR=TMP + "/h", DUO_DIR=TMP + "/d", SEARCH_MODEL="off",
                  MEDIA_DIR=TMP + "/media", CREATIVE_STATE=TMP + "/cs.json", HAND_HOST="hand.test", FILE_MAX="1000")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

HOME = tempfile.mkdtemp()
os.makedirs(HOME + "/work/notes"); os.makedirs(HOME + "/work/.git")
open(HOME + "/work/notes/план.md", "w").write("# План\nсделать каркас")
open(HOME + "/work/big.bin", "wb").write(b"x" * 5000)
os.symlink("/etc", HOME + "/work/escape")
async def local_ssh(script, timeout=40):
    p = subprocess.run(["bash", "-s"], input=script.encode(), capture_output=True, env={**os.environ, "HOME": HOME})
    return p.returncode, p.stdout
relay.hand_ssh = local_ssh

r = run(relay.files_list("aurora", "", "Bearer tok"))
names = [(x["name"], x["dir"]) for x in r["items"]]
check("корень: папки первыми, .git скрыт", names[0] == ("escape", True) or names[0][1] and ".git" not in [n for n, _ in names], names)
check("файлы с размером", any(x["name"] == "big.bin" and x["size"] == 5000 and not x["dir"] for x in r["items"]), r)
r = run(relay.files_list("aurora", "notes", "Bearer tok"))
check("вложенная папка", [x["name"] for x in r["items"]] == ["план.md"], r)
resp = run(relay.files_get("aurora", "notes/план.md", "Bearer tok"))
check("файл отдаётся как есть", resp.body.decode() == "# План\nсделать каркас" and resp.media_type.startswith("text/"), resp.media_type)
for bad in ["../etc/passwd", "notes/../../x", "escape/passwd"]:
    try:
        if bad.startswith("escape"):
            run(relay.files_get("aurora", bad, "Bearer tok")); check(f"не выйти из папки: {bad}", False)
        else:
            run(relay.files_list("aurora", bad, "Bearer tok")); check(f"не выйти из папки: {bad}", False)
    except relay.HTTPException as e:
        check(f"не выйти из папки: {bad}", e.status_code in (400, 404), e.detail)
try:
    run(relay.files_get("aurora", "big.bin", "Bearer tok")); check("слишком большой файл", False)
except relay.HTTPException as e:
    check("слишком большой файл", e.status_code == 413, e.detail)
r = run(relay.files_list("hespera", "", "Bearer tok"))
check("папки Гесперы ещё нет — пусто и пояснение", r["items"] == [] and "ещё ничего" in r["note"], r)
os.makedirs(HOME + "/hespera"); open(HOME + "/hespera/я.txt", "w").write("я")
r = run(relay.files_list("hespera", "", "Bearer tok"))
check("её папка — своя", [x["name"] for x in r["items"]] == ["я.txt"], r)

# --- страница и аватар Гесперы
def png():
    raw = b"".join(b"\x00" + b"\x10\x20\x30" * 4 for _ in range(4))
    ch = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", 4, 4, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b"")
PNG = png()
mid = relay.media_save(PNG, "png", "img", "рисунок")
text = f"Вот я.\n[пост: Это я ночью | картинка]\n[аватар: картинка]\n[медиа: {mid} | рисунок]"
clean, ch = relay.apply_hespera_markers(text)
post = relay.hespera_posts()[-1]
check("пост с её рисунком", post["text"] == "Это я ночью" and post["media"] == mid, post)
run(relay.hespera_set_avatar(ch))
av = [c for c in ch if c["kind"] == "аватар"][0]
check("аватар из её рисунка", av.get("ok") and (relay.HESPERA_DIR / "avatar.png").read_bytes() == PNG, av)
clean, ch = relay.apply_hespera_markers("[аватар: фото]")
check("фото не прислано — честная ошибка", ch[0].get("ok") is False and "не прислал" in ch[0]["error"], ch)
# фото Адониса в её личке
async def model(msgs, model=None, timeout=100.0): return "Красиво. Это теперь я.\n[аватар: фото]\n[пост: Подарок от Адониса | фото]"
relay.ask_model = model
b64 = base64.b64encode(PNG).decode()
r = run(relay.hespera_chat(relay.HesperaReq(messages=[relay.Msg(role="user", content="[фото] возьми на аватар")], images=[relay.ImageItem(i=0, data=b64)]), "Bearer tok"))
av = [c for c in r["changes"] if c["kind"] == "аватар"][0]
post = relay.hespera_posts()[-1]
check("аватар из фото Адониса", av.get("ok") is True, r["changes"])
check("пост с фото Адониса", post["text"] == "Подарок от Адониса" and post["media"].startswith("img_"), post)
r = run(relay.hespera_like(relay.LikeReq(id=post["id"], on=True), "Bearer tok"))
check("лайк Адониса записан", relay.hespera_posts()[-1]["liked"] is True)
_st = relay.hespera_self_text(relay.hespera_self())
check("и она его видит", "Подарок от Адониса" in _st and "♥ Адонис" in _st, _st[-300:])
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
