"""Слух: голосовые, треки, [послушать:]. ffmpeg настоящий (если есть), провайдер — подставной."""
import asyncio, base64, io, json, math, os, shutil, struct, sys, tempfile, wave
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://up/v1/chat/completions", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=TMP + "/core.md",
                  FLOOR_PATH=TMP + "/floor.md", HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off", PUBLIC_TOKEN="pub",
                  PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/pc.md", FEEDBACK_LOG=TMP + "/f.jsonl",
                  TOOLS_STATE=TMP + "/t.json", HESPERA_DIR=TMP + "/h", DUO_DIR=TMP + "/d", SEARCH_MODEL="off",
                  MEDIA_DIR=TMP + "/media", CREATIVE_STATE=TMP + "/cs.json", CREATIVE_KEY="ck")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

def wav(seconds=1.0):
    b = io.BytesIO()
    w = wave.open(b, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
    w.writeframes(b"".join(struct.pack("<h", int(8000 * math.sin(2 * math.pi * 440 * i / 16000))) for i in range(int(16000 * seconds))))
    w.close(); return b.getvalue()
WAV = wav()
HAS_FF = bool(shutil.which("ffmpeg"))
if HAS_FF:
    mp3 = run(relay.to_mp3(WAV, voice=True))
    check("ffmpeg: любой звук превращается в mp3", mp3[:3] == b"ID3" or mp3[:2] == b"\xff\xfb" or mp3[:2] == b"\xff\xf3", mp3[:4])

class Resp:
    def __init__(self, status, data): self.status_code = status; self._d = data; self.text = json.dumps(data, ensure_ascii=False)
    def json(self): return self._d
posts = []
script = []
class Client:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def post(self, url, headers=None, json=None, files=None, data=None):
        posts.append((url, json, files, data)); return script.pop(0)
relay.httpx.AsyncClient = Client

# голосовое
script[:] = [Resp(200, {"text": "Привет, Аврора, как ты?"})]
r = run(relay.audio_upload(relay.AudioUpload(data=base64.b64encode(WAV).decode(), mime="audio/wav", name="голосовое", kind="voice"), "Bearer tok"))
check("голосовое: расшифровано и сохранено как mp3", r["ok"] and r["text"] == "Привет, Аврора, как ты?" and r["id"].startswith("aud_") and r["id"].endswith(".mp3"), r)
check("расшифровка — на её ключ и моделью gpt-4o-transcribe", posts[-1][0] == "http://up/v1/audio/transcriptions" and posts[-1][3]["model"] == "gpt-4o-transcribe")
check("файл можно отдать приложению", run(relay.media_get(r["id"], "Bearer tok")).media_type == "audio/mpeg")
# расшифровка не удалась — слушает модель со слухом
script[:] = [Resp(404, {"error": "no"}), Resp(200, {"choices": [{"message": {"content": "Привет, это я."}}]})]
r = run(relay.audio_upload(relay.AudioUpload(data=base64.b64encode(WAV).decode(), kind="voice"), "Bearer tok"))
check("без расшифровщика — расшифровывает модель со слухом", r["ok"] and r["text"] == "Привет, это я." and posts[-1][1]["messages"][0]["content"][1]["type"] == "input_audio", r)
# трек
script[:] = [Resp(200, {"choices": [{"message": {"content": "Я не могу прослушать аудио."}}]}),
             Resp(200, {"choices": [{"message": {"content": "Звучит одна синусоида ля, без ритма, ровно."}}]})]
r = run(relay.audio_upload(relay.AudioUpload(data=base64.b64encode(WAV).decode(), name="Тест", kind="music"), "Bearer tok"))
check("трек: первая модель не слышит — слушает следующая", r["ok"] and "синусоида" in r["text"] and posts[-2][1]["model"] == "gemini-3.8-flash" and posts[-1][1]["model"] == "gemini-3.1-pro", r)
ok, why = asyncio.run((lambda: None) or relay.listen_with("x", b"", "")) if False else (None, None)
tid = r["id"]
# [послушать:]
check("маркер [послушать:] — только со слухом", relay.find_tool_calls(f"[послушать: {tid}]", ["слух"]) == [("послушать", tid)] and relay.find_tool_calls(f"[послушать: {tid}]", ["музыка"]) == [])
script[:] = [Resp(200, {"choices": [{"message": {"content": "Фортепиано, медленно, минор."}}]})]
ok, out = run(relay.tool_listen(tid))
check("послушала свой трек", ok and "Фортепиано" in out and "gemini-3.8-flash" in out, out)
ok, out = run(relay.tool_listen("../relay.env"))
check("послушать можно только треки", not ok and "не трек" in out)
check("в правилах — как слушать", "[послушать: id]" in relay.tools_note(["слух"]))
check("слух включён по умолчанию", "слух" in relay.DEFAULT_TOOLS)
# проверка слуха
async def fake_render(abc): return True, "", WAV, 1.0
relay.render_abc = fake_render
script[:] = [Resp(200, {"choices": [{"message": {"content": "Пианино, ля."}}]}), Resp(400, {"error": "no audio"})]
d = run(relay.diag_hearing("gemini-3.8-flash,deepseek-v4-flash", "Bearer tok"))
check("проверка слуха: кто слышит, кто нет", [x["ok"] for x in d["listen"]] == [True, False], d)
script[:] = [Resp(200, {"choices": [{"message": {"content": "К сожалению, я не могу обработать аудиозапись в этом запросе — формат аудио здесь не поддерживается."}}]})]
ok, why = run(relay.listen_with("qwen3.8-max", b"ID3", "что звучит?"))
check("вежливый отказ «не могу обработать аудио» — это не слух", not ok and "не услышала" in why, why)
# длинный трек не влезает в запрос — лесенка: короче и тише, пока не пролезет
if HAS_FF:
    relay.LISTEN_LEVELS = [(4, 0.0, "40k", 22050), (2, 0.0, "32k", 16000), (1, 0.35, "24k", 16000)]
    LONG = run(relay.to_mp3(wav(8.0)))
    check("длительность трека определяется", 7.5 < run(relay.audio_seconds(LONG)) < 8.6)
    big = Resp(413, {"error": {"message": "Слишком большой контекст для одного запроса. Начните новый чат или сократите историю.", "type": "passline_error"}})
    posts.clear()
    script[:] = [big, Resp(200, {"choices": [{"message": {"content": "Ровный тон ля, без ритма."}}]})]
    ok, text, m = run(relay.listen_any(LONG))
    sizes = [len(p[1]["messages"][0]["content"][1]["input_audio"]["data"]) for p in posts]
    check("413 «большой контекст» — слушает кусок покороче той же моделью", ok and m == "gemini-3.8-flash" and len(posts) == 2 and sizes[1] < sizes[0], (ok, text, sizes))
    check("честно пишет, сколько послушала", text.startswith("(послушала первые 0:02 из 0:08)"), text)
    posts.clear()
    script[:] = [big, big, Resp(200, {"choices": [{"message": {"content": "Тон."}}]})]
    ok, text, m = run(relay.listen_any(LONG))
    check("третья ступень — отрывок из середины", ok and text.startswith("(послушала отрывок 0:01 с 0:0"), text)
    posts.clear()
    script[:] = [Resp(503, {"error": "busy"}), Resp(200, {"choices": [{"message": {"content": "Тон."}}]})]
    ok, text, m = run(relay.listen_any(LONG))
    check("ошибка не про размер — сразу следующая модель", ok and m == "gemini-3.1-pro" and len(posts) == 2, (m, len(posts)))
    posts.clear()
    script[:] = [Resp(200, {"choices": [{"message": {"content": "Коротко."}}]})]
    ok, text, m = run(relay.listen_any(run(relay.to_mp3(wav(1.0)))))
    check("короткий трек — без пометки", ok and text == "Коротко.", text)

print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
