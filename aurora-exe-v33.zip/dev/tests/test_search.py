"""Поиск: разбор выдачи разных поисковиков и гонка между ними. Без сети."""
import asyncio, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off", PUBLIC_TOKEN="pub", PUBLIC_LOG=TMP + "/public.jsonl",
                  PUBLIC_CORE_PATH=TMP + "/public_core.md", FEEDBACK_LOG=TMP + "/f.jsonl", TOOLS_STATE=TMP + "/t.json",
                  HESPERA_DIR=TMP + "/h", DUO_DIR=TMP + "/d", SEARCH_TIMEOUT="1")
os.environ["SEARCH_MODEL"] = "off"
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)

bing = '''<ol id="b_results"><li class="b_algo" data-x="1"><div class="b_tpcn"></div><h2><a href="https://www.bing.com/ck/a?!&amp;&amp;p=abc&amp;u=a1aHR0cHM6Ly9leGFtcGxlLmNvbS9wYWdl&amp;ntb=1" h="ID=SERP">Пример <strong>страницы</strong></a></h2>
<div class="b_caption"><p class="b_lineclamp2">Описание <strong>страницы</strong> тут.</p></div></li>
<li class="b_algo"><h2><a href="https://ru.wikipedia.org/wiki/Липецк">Липецк — Википедия</a></h2><div class="b_caption"><p>Город в России.</p></div></li></ol>'''
r = relay.parse_bing(bing)
check("Bing: ссылки, в том числе через перенаправление", [x["url"] for x in r] == ["https://example.com/page", "https://ru.wikipedia.org/wiki/Липецк"], r)
check("Bing: заголовок и описание без тегов", r[0]["title"] == "Пример страницы" and r[0]["snippet"].startswith("Описание страницы"), r)

mojeek = '''<ul class="results-standard"><li><a class="ob" href="https://a.ru/x"><p class="i">a.ru</p></a><h2><a class="title" href="https://a.ru/x">Заголовок A</a></h2><p class="s">Текст A</p></li>
<li><a class="ob" href="https://b.ru/"></a><h2><a class="title" href="https://b.ru/">Заголовок B</a></h2><p class="s">Текст B</p></li></ul>'''
r = relay.parse_mojeek(mojeek)
check("Mojeek", [(x["title"], x["url"], x["snippet"]) for x in r] == [("Заголовок A", "https://a.ru/x", "Текст A"), ("Заголовок B", "https://b.ru/", "Текст B")], r)

lite = '''<table><tr><td><a rel="nofollow" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fc.ru%2Fpage&amp;rut=1" class='result-link'>Страница C</a></td></tr>
<tr><td class='result-snippet'>Сниппет C</td></tr></table>'''
r = relay.parse_ddg_lite(lite)
check("DuckDuckGo lite", r and r[0]["url"] == "https://c.ru/page" and r[0]["snippet"] == "Сниппет C", r)

def run(c): return asyncio.run(c)
def eng(res, delay=0.0, exc=None):
    async def f(c, q):
        await asyncio.sleep(delay)
        if exc: raise exc
        return res
    return f
R = lambda t, n=2: [{"title": f"{t}{i}", "url": f"https://{t}.ru/{i}", "snippet": ""} for i in range(n)]
import httpx
class Dummy:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
relay.httpx.AsyncClient = Dummy
relay.SEARCH_CACHE_TTL = 0
relay.SEARCH_STAGE_WAIT = 0.4
def setup(**e):
    relay.SEARCH_ENGINES = e; relay.SEARCH_REST.clear()

setup(ddg_lite=eng(R("ddg"), 0.2), bing=eng(R("bing"), 0.05), wiki=eng(R("wiki"), 0))
okk, text = run(relay.tool_search("тест"))
check("DuckDuckGo и Bing вместе, выдача слита, DuckDuckGo первым", okk and "ddg_lite, bing" in text and text.index("ddg0") < text.index("bing0") and "wiki" not in text, text)
setup(ddg_lite=eng(R("ddg"), 3), bing=eng(R("bing"), 0.05))
t0 = time.time(); okk, text = run(relay.tool_search("тест")); dt = time.time() - t0
check("зависший DuckDuckGo не держит: Bing отдаётся быстро", okk and "bing" in text and dt < 1, (text, dt))
setup(ddg_lite=eng([], 0, RuntimeError("ddg-limit")), bing=eng(R("bing"), 0.05), ddg=eng(R("ddg"), 0))
okk, text = run(relay.tool_search("тест"))
check("DuckDuckGo просит подождать — Bing отвечает, а DuckDuckGo отдыхает", okk and "bing" in text and relay.SEARCH_REST.get("ddg", 0) > time.time(), (text, relay.SEARCH_REST))
setup(ddg_lite=eng([], 0), bing=eng([], 0), ddg=eng(R("ddg"), 0), wiki=eng(R("wiki"), 0))
okk, text = run(relay.tool_search("тест"))
check("пара пустая — вторая версия DuckDuckGo", okk and "поисковики: ddg" in text or "поисковик: ddg" in text, text)
setup(ddg_lite=eng([], 0), bing=eng([], 0), ddg=eng([], 0), wiki=eng(R("wiki"), 0))
okk, text = run(relay.tool_search("тест"))
check("все пусто — Википедия", okk and "wiki" in text, text)
setup(ddg_lite=eng([], 0, httpx.ReadTimeout("x")), bing=eng([], 0, httpx.ConnectTimeout("x")))
okk, text = run(relay.tool_search("тест"))
check("все молчат — честно «не ответил вовремя»", not okk and text == "поиск не ответил вовремя", text)
setup(ddg_lite=eng([], 0, httpx.ReadTimeout("x")), bing=eng([], 0.05))
okk, text = run(relay.tool_search("тест"))
check("причины неудачи видны", not okk and "ddg_lite: не ответил вовремя" in text and "bing: пусто" in text, text)
setup(mojeek=eng(R("moj"), 0), bing=eng([], 0))
okk, text = run(relay.tool_search("тест"))
check("Mojeek по умолчанию не зовётся (капча)", not okk, text)
os.environ["SEARCH_ORDER"] = "bing,mojeek"
okk, text = run(relay.tool_search("тест"))
check("…но включается через SEARCH_ORDER", okk and "mojeek" in text, text)
del os.environ["SEARCH_ORDER"]
relay.SEARCH_CACHE_TTL = 1800
calls_n = []
async def counting(c, q):
    calls_n.append(q); return R("bing")
setup(bing=counting)
run(relay.tool_search("Кэш")); run(relay.tool_search("кэш "))
check("одинаковый запрос берётся из памяти", len(calls_n) == 1, calls_n)
relay.SEARCH_CACHE_TTL = 0
setup(ddg=eng([], 0), bing=eng(R("bing"), 0))
_sleep = relay.asyncio.sleep
async def fast(_): return None
relay.asyncio.sleep = fast
d = run(relay.diag_search("тест", "Bearer tok"))
relay.asyncio.sleep = _sleep
check("проверка поисковиков: по строке на каждый", {x["engine"] for x in d["engines"]} == {"ddg", "bing", "ai:off"} and d["tool_ok"], d)
# --- поиск моделью
async def ai_ok(q): return True, "1. Новость про Липецк https://lipetsk.ru/a"
async def ai_bad(q): return False, "grok-4.7: ответ без ссылок"
relay.SEARCH_MODEL = "grok-4.7"
setup(bing=eng(R("bing"), 0))
relay.ai_search = ai_ok
okk, text = run(relay.tool_search("липецк"))
check("сводка модели первой, ссылки поисковика ниже", okk and text.startswith("Сводка поиска (grok-4.7") and "lipetsk.ru/a" in text and "bing0" in text and text.index("lipetsk.ru") < text.index("bing0"), text)
relay.ai_search = ai_bad
okk, text = run(relay.tool_search("липецк2"))
check("модель без ссылок — остаётся поисковик", okk and "Сводка" not in text and "bing0" in text, text)
relay.ai_search = ai_ok
setup(bing=eng([], 0))
okk, text = run(relay.tool_search("липецк3"))
check("поисковики пусты — хватает сводки модели", okk and "Сводка поиска" in text and "Ссылки из поисковика" not in text, text)
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
