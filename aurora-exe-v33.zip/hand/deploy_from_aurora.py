#!/usr/bin/env python3
"""
Выкатить на живой сайт то, что Аврора поправила у себя в ~/work/site. Запускается от root на ОСНОВНОМ сервере.
  python3 deploy_from_aurora.py          показать, что изменилось (ничего не трогает)
  python3 deploy_from_aurora.py --go     выкатить: старые файлы уходят в /var/backups/avrora-site/<время>/
  python3 deploy_from_aurora.py --undo   вернуть последнюю резервную копию

Что можно выкатывать: только сайт (/var/www/avrora) и админку (/opt/avrora-admin).
Её посредник (/opt/aurora-relay) не трогается никогда. Файлы с вычищенными секретами (***) не выкатываются:
в снимке они неполные, их правят руками. Удалений нет: файлы только добавляются и заменяются.
"""
import filecmp, hashlib, os, shutil, subprocess, sys, tarfile, tempfile, time

ENV = "/opt/aurora-relay/relay.env"
ROOTS = {"var_www_avrora": "/var/www/avrora", "opt_avrora-admin": "/opt/avrora-admin"}
BACKUPS = "/var/backups/avrora-site"
SKIP_SUFFIX = (".schema.txt", ".bak", ".pyc")
RESTART = {"opt_avrora-admin": "avrora-admin"}   # если поменялась админка, её сервис перезапускается


def env():
    d = {}
    for line in open(ENV, encoding="utf-8"):
        if "=" in line and not line.lstrip().startswith("#"):
            k, v = line.rstrip("\n").split("=", 1)
            d[k.strip()] = v.strip().strip('"').strip("'")
    return d


def fetch(tmp):
    e = env()
    host, user, port, key = e.get("HAND_HOST"), e.get("HAND_USER", "aurora"), e.get("HAND_PORT", "22"), e.get("HAND_KEY", "/opt/aurora-relay/hand_key")
    if not host:
        sys.exit("Рука не подключена (нет HAND_HOST).")
    present = " ".join(ROOTS)
    cmd = f'cd "$HOME/work/site" 2>/dev/null || exit 3; ls -d {present} 2>/dev/null | xargs tar czf -'
    r = subprocess.run(["ssh", "-i", key, "-p", port, "-o", "BatchMode=yes", f"{user}@{host}", cmd], capture_output=True, timeout=600)
    if r.returncode != 0 or not r.stdout:
        sys.exit("Не получилось забрать её папку: " + r.stderr.decode(errors="replace")[:300])
    path = os.path.join(tmp, "a.tgz")
    open(path, "wb").write(r.stdout)
    with tarfile.open(path) as t:
        for m in t.getmembers():
            if m.name.startswith("/") or ".." in m.name.split("/") or not (m.isfile() or m.isdir()):
                sys.exit("В её архиве странный путь, ничего не делаю: " + m.name)
        t.extractall(os.path.join(tmp, "x"))
    return os.path.join(tmp, "x")


def plan(src):
    changes, skipped = [], []
    for tag, live in ROOTS.items():
        base = os.path.join(src, tag)
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            for fn in files:
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, base)
                dst = os.path.join(live, rel)
                if fn.endswith(SKIP_SUFFIX):
                    continue
                try:
                    data = open(p, "rb").read()
                except OSError:
                    continue
                if b"***" in data:
                    if not (os.path.exists(dst) and filecmp.cmp(p, dst, shallow=False)):
                        skipped.append(f"{dst}: в её копии вычищенные секреты (***), правь вручную")
                    continue
                if os.path.exists(dst) and filecmp.cmp(p, dst, shallow=False):
                    continue
                changes.append((tag, p, dst, "новый" if not os.path.exists(dst) else "изменён"))
    return changes, skipped


def go(changes):
    stamp = time.strftime("%Y%m%d-%H%M%S")
    bdir = os.path.join(BACKUPS, stamp)
    os.makedirs(bdir, exist_ok=True)
    restart = set()
    with open(os.path.join(bdir, "list.txt"), "w", encoding="utf-8") as lst:
        for tag, src, dst, kind in changes:
            if os.path.exists(dst):
                b = os.path.join(bdir, dst.lstrip("/"))
                os.makedirs(os.path.dirname(b), exist_ok=True)
                shutil.copy2(dst, b)
                lst.write(f"заменён {dst}\n")
            else:
                lst.write(f"новый {dst}\n")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            if tag in RESTART:
                restart.add(RESTART[tag])
    for svc in restart:
        subprocess.run(["systemctl", "restart", svc])
    print(f"Готово. Резервная копия: {bdir}. Откат: python3 deploy_from_aurora.py --undo")


def undo():
    if not os.path.isdir(BACKUPS) or not os.listdir(BACKUPS):
        sys.exit("Резервных копий нет.")
    last = os.path.join(BACKUPS, sorted(os.listdir(BACKUPS))[-1])
    for line in open(os.path.join(last, "list.txt"), encoding="utf-8"):
        kind, dst = line.rstrip("\n").split(" ", 1)
        if kind == "заменён":
            shutil.copy2(os.path.join(last, dst.lstrip("/")), dst)
        elif os.path.exists(dst):
            os.remove(dst)
        print("вернул:", dst)
    os.rename(last, last + "-отменено")
    print("Откат сделан.")


def main():
    if "--undo" in sys.argv:
        return undo()
    with tempfile.TemporaryDirectory() as tmp:
        changes, skipped = plan(fetch(tmp))
        for tag, src, dst, kind in changes:
            print(f"{kind:8} {dst}")
        for s in skipped:
            print("пропущен", s)
        if not changes:
            print("Изменений нет: её копия совпадает с живым сайтом.")
            return
        if "--go" not in sys.argv:
            print(f"\nЭто только просмотр ({len(changes)} файлов). Выкатить: python3 deploy_from_aurora.py --go")
            return
        go(changes)


if __name__ == "__main__":
    main()
