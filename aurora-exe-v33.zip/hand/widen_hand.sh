#!/usr/bin/env bash
# Полные права для Авроры на её сервере. Запускается от root на СЕРВЕРЕ РУКИ (не на основном).
#   bash widen_hand.sh          выдать: sudo без пароля, интернет открыт, лимиты шире
#   bash widen_hand.sh --undo   вернуть клетку как была
# Что остаётся неизменным: вход только по ключу, пароль root и панель хостера у неё не появятся,
# рубильники aurora-off / aurora-on и aurora-egress работают как раньше.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Нужен root."; exit 1; }
id aurora >/dev/null 2>&1 || { echo "Пользователя aurora нет: сначала setup_hand.sh"; exit 1; }
UID_A="$(id -u aurora)"

if [ "${1:-}" = "--undo" ]; then
  rm -f /etc/sudoers.d/90-aurora-full
  gpasswd -d aurora sudo >/dev/null 2>&1 || true
  /usr/local/sbin/aurora-egress closed
  cat > "/etc/systemd/system/user-${UID_A}.slice.d/50-aurora.conf" <<'CONF'
[Slice]
MemoryMax=900M
CPUQuota=100%
TasksMax=150
CONF
  sed -i 's/^aurora hard nproc .*/aurora hard nproc 150/' /etc/security/limits.d/50-aurora.conf
  systemctl daemon-reload
  echo "Клетка возвращена: sudo нет, интернет закрыт, лимиты прежние."
  echo "На сервере Авроры убери строку HAND_SUDO=1 из /opt/aurora-relay/relay.env и перезапусти aurora-relay."
  exit 0
fi

echo "[1/3] sudo без пароля для aurora"
printf 'aurora ALL=(ALL) NOPASSWD:ALL\n' > /etc/sudoers.d/90-aurora-full
chmod 440 /etc/sudoers.d/90-aurora-full
visudo -cf /etc/sudoers.d/90-aurora-full >/dev/null

echo "[2/3] Выход в интернет открыт"
/usr/local/sbin/aurora-egress open

echo "[3/3] Лимиты шире (память 3 ГБ, 2 ядра, 1000 процессов)"
mkdir -p "/etc/systemd/system/user-${UID_A}.slice.d"
cat > "/etc/systemd/system/user-${UID_A}.slice.d/50-aurora.conf" <<'CONF'
[Slice]
MemoryMax=3G
CPUQuota=200%
TasksMax=1000
CONF
sed -i 's/^aurora hard nproc .*/aurora hard nproc 1000/' /etc/security/limits.d/50-aurora.conf 2>/dev/null || true
systemctl daemon-reload

echo
echo "Проверка:"
su -s /bin/bash aurora -c 'sudo -n true && echo "  sudo: есть"' || echo "  sudo: НЕТ (что-то не так)"
su -s /bin/bash aurora -c 'timeout 6 curl -sS -o /dev/null https://example.com && echo "  интернет: открыт"' || echo "  интернет: закрыт (что-то не так)"
echo
echo "Теперь на сервере Авроры:"
echo "  echo HAND_SUDO=1 >> /opt/aurora-relay/relay.env && systemctl restart aurora-relay"
echo "Рубильник остаётся: aurora-off здесь, переключатель «Рука» в приложении, выключение сервера у хостера."
