"""Эст: персона, задачи, исполнение, проверка, общий чат. Без сети и модели."""
import asyncio, json, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok",
                  CORE_PATH=TMP + "/core.md", FLOOR_PATH=TMP + "/floor.md",
                  HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off",
                  PUBLIC_TOKEN="pub", PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/public_core.md",
                  FEEDBACK_LOG=TMP + "/feedback.jsonl", TOOLS_STATE=TMP + "/tools_state.json",
                  HESPERA_DIR=TMP + "/hespera", HESPERA_FEEDBACK_LOG=TMP + "/hespera/feedback.jsonl",
                  DUO_DIR=TMP + "/duo", MEDIA_DIR=TMP + "/media", EST_DIR=TMP + "/est")
os.environ["SEARCH_MODEL"] = "off"
import relay

ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)
M, G = relay.Msg, relay.GroupMsg
seen = {"sys": []}
def answer(text):
    async def f(msgs, model=None, timeout=100.0):
        seen["sys"].append(msgs[0]["content"]); seen["msgs"] = msgs
        return text(msgs) if callable(text) else text
    relay.ask_model = f

check("до первого разговора Эст девчонкам о ней не говорят", relay.est_block("aurora") == "" and not relay.est_active())
check("без руки у Эст всё, кроме руки", relay.est_tools() == ["поиск", "чтение", "рисование", "музыка", "слух"], relay.est_tools())

# --- личка с Эст: персона и задача
answer("Сделаю.\n[задача: аврора | найди три свежих новости про Android 17 и пришли ссылки]\n[запомню: Адонис любит, когда коротко]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="Эст, пусть Аврора найдёт новости про Android 17")]), "Bearer tok"))
sysp = seen["sys"][-1]
check("персона: Эст, равная Адонису, руководит девчонками", "Ты Эст" in sysp and "равная ему" in sysp and "руководишь их работой" in sysp)
check("серьёзная, но чудит: шутки, сговор, розыгрыши, сценки",
      "Внутри — чудишь" in sysp and "подыгрываешь" in sysp and "Саботаж понарошку — твоё" in sysp and "сама затеваешь" in sysp
      and "не инструмент" in sysp)
check("граница — только настоящий вред, и вместо морали безвредная версия",
      "по-настоящему вредит" in sysp and "можно сделать вид, что сломали" in sysp and "считай шуткой и подыграй" in sysp)
check("в промпте доска и маркеры", "ДОСКА ЗАДАЧ" in sysp and "[задача: аврора" in sysp)
check("ответ без маркеров", r["reply"] == "Сделаю.", r)
check("задача №1 поставлена и отдана приложению", r["tasks_new"] == [1] and relay.est_tasks()[0]["to"] == "aurora" and relay.est_tasks()[0]["status"] == "new", r)
check("заметка в её память", "коротко" in relay.est_memory_text())
check("теперь Эст активна", relay.est_active())

# --- Аврора видит задачу в своём чате и отчитывается
answer("Нашла, держи.\n[сделано: 1 | три ссылки на новости про Android 17]")
r = run(relay.chat(relay.ChatReq(messages=[M(role="user", content="привет")], exe=True), "Bearer tok"))
check("Аврора видит задачу и что Эст главнее", "ТВОИ ЗАДАЧИ ОТ ЭСТ" in seen["sys"][-1] and "№1" in seen["sys"][-1] and "Выше Эст только Адонис" in seen["sys"][-1])
check("её [сделано] убран из ответа, задача закрыта", r["reply"] == "Нашла, держи." and r.get("tasks_done") == [1] and relay.est_tasks()[0]["status"] == "done", r)

# --- Эст проверяет: возвращает и принимает
answer("Ссылок две, а не три.\n[переделать: 1 | нужно три ссылки, а не две]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="проверь")]), "Bearer tok"))
check("возврат на доработку", r["tasks_redo"] == [1] and relay.est_tasks()[0]["status"] == "redo" and "три ссылки" in relay.est_tasks()[0]["note"], r)

# --- исполнение задачи: Аврора делает и отчитывается
answer(lambda msgs: "Переделала, вот три: a, b, c.\n[сделано: 1 | три ссылки]\n[пост: нашла новости]")
r = run(relay.task_run(relay.TaskRunReq(id=1, memory="память", persona="характер", tools=[]), "Bearer tok"))
last_user = seen["msgs"][-1]["content"]
check("исполнительнице сказано, что это задача Эст и доработка", "Эст дала тебе задачу №1" in last_user and "Это доработка" in last_user, last_user[:300])
check("отчёт для общего чата без маркеров, пост — приложению", r["who"] == "aurora" and r["text"] == "Переделала, вот три: a, b, c." and r["markers"] == ["[пост: нашла новости]"], r)
check("задача снова сделана, попытка учтена", relay.est_tasks()[0]["status"] == "done" and relay.est_tasks()[0]["runs"] == 1)
r = run(relay.task_run(relay.TaskRunReq(id=1), "Bearer tok"))
check("закрытую задачу второй раз не запускают", r.get("skip"))
answer("Принято. Хорошо.\n[принять: 1]")
run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="ну?")]), "Bearer tok"))
check("принята", relay.est_tasks()[0]["status"] == "accepted")

# --- Геспера: задача из общего чата, исполнение без маркера
answer("[задача: геспера | нарисуй обложку для поста Адониса про стан]\nГеспера, на тебе обложка.")
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="adonis", content="Эст, раздай работу")], hespera_tools=[], aurora_tools=[]), "Bearer tok"))
check("обратился к Эст — отвечает только она", [x["who"] for x in r["replies"]] == ["est"], r)
check("её задача из общего чата", r["replies"][0].get("tasks_new") == [2] and r["replies"][0]["text"] == "Геспера, на тебе обложка.", r)
answer("Нарисовала тёмный стан с искрами, повесила на страницу.")
r = run(relay.task_run(relay.TaskRunReq(id=2, tools=[]), "Bearer tok"))
check("Геспера в роли исполнительницы видит свои задачи", "ТВОИ ЗАДАЧИ ОТ ЭСТ" in seen["sys"][-1] and "Ты Геспера" in seen["sys"][-1])
check("забыла [сделано] — отчёт всё равно засчитан", relay.est_tasks()[1]["status"] == "done" and "искрами" in relay.est_tasks()[1]["report"])

# --- проверка Эст в общем чате по responders
answer("Принято.\n[принять: 2]")
r = run(relay.group_chat(relay.GroupReq(messages=[G(speaker="hespera", content="Нарисовала")], responders=["est"]), "Bearer tok"))
check("приложение зовёт Эст проверить — отвечает она", [x["who"] for x in r["replies"]] == ["est"] and relay.est_tasks()[1]["status"] == "accepted", r)

# --- пределы
answer("\n".join(f"[задача: геспера | дело {i}]" for i in range(4)))
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="загрузи её")]), "Bearer tok"))
check("не больше двух задач за ответ", len(r["tasks_new"]) == 2 and r.get("tasks_refused"), r)
answer("[задача: геспера | дело 5]\n[задача: геспера | дело 6]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="ещё")]), "Bearer tok"))
check("не больше трёх открытых у одной", len(r["tasks_new"]) == 1 and any("открытые" in x for x in r["tasks_refused"]), r)
answer("[задача: кому-то | что-то]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="?")]), "Bearer tok"))
check("непонятно кому — не ставится", r["tasks_new"] == [] and r["tasks_refused"], r)

# --- переделки кончаются
n = r["tasks_new"] or [x["id"] for x in relay.est_tasks() if x["status"] == "new"][:1]
tid = n[0]
for i in range(relay.TASK_RUNS_MAX):
    answer(f"попытка {i}\n[сделано: {tid} | вот]")
    run(relay.task_run(relay.TaskRunReq(id=tid, tools=[]), "Bearer tok"))
    answer(f"[переделать: {tid} | плохо]")
    rr = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="?")]), "Bearer tok"))
t = next(x for x in relay.est_tasks() if x["id"] == tid)
check("после трёх попыток задача не возвращается бесконечно", t["status"] == "failed" and t["runs"] == relay.TASK_RUNS_MAX, t)

# --- Адонис снимает задачу
open_ = [x for x in relay.est_tasks() if x["status"] == "new"]
run(relay.task_cancel(relay.TaskIdReq(id=open_[0]["id"]), "Bearer tok"))
check("Адонис снял задачу", next(x for x in relay.est_tasks() if x["id"] == open_[0]["id"])["status"] == "cancelled")

# --- пробуждение Эст
answer("ПРОПУСК\n[задача: аврора | проверь, что сайт avrora-exe.ru открывается, и скажи время ответа]\nПРОСНУСЬ: 3 ч")
r = run(relay.est_wake(relay.EstWakeReq(), "Bearer tok"))
check("пробуждение: молча поставила задачу и выбрала, когда проснуться", r.get("skip") and len(r["tasks_new"]) == 1 and r.get("wake_min") == 180, r)
check("в пробуждении видна доска", "ДОСКА ЗАДАЧ" in seen["sys"][-1] and "ПРОПУСК" in seen["sys"][-1])

# --- Геспера в личке видит Эст
answer("ладно")
run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="привет")]), "Bearer tok"))
check("Геспера знает про Эст", "ЭСТ. В команду Адонис добавил Эст" in seen["sys"][-1])

# --- порядок в общем чате
o = relay.group_order([G(speaker="adonis", content="Аврора, как дела?")])
check("без Эст в сообщении она не лезет", "est" not in o, o)
o = relay.group_order([G(speaker="adonis", content="Эст и Аврора, гляньте")])
check("Эст и Аврора — только они", o == ["est", "aurora"], o)
o = relay.group_order([G(speaker="adonis", content="кто сделал задачу?")])
check("про задачи — Эст подключается последней", o[-1] == "est", o)
o = relay.group_order([G(speaker="adonis", content="а давайте устроим розыгрыш")])
check("про розыгрыш — Эст подключается", o[-1] == "est", o)
check("файлы Эст можно смотреть", "est" in relay.FILE_ROOTS)

d = run(relay.est_tasks_get("Bearer tok"))
check("доска для приложения", d["active"] and len(d["tasks"]) >= 5)
# --- страница Эст: статус, настроение, пост с рисунком
os.makedirs(TMP + "/media", exist_ok=True)
answer("Готово.\n[статус: на страже]\n[настроение: спокойна | девчонки работают]\n[пост: Сегодня порт закрыт. Хорошая работа. | картинка]\n[медиа: img_1_abcdef12.png | клинок]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="как ты?")]), "Bearer tok"))
me = relay.est_self()
check("статус и настроение записаны", me["status"] == "на страже" and me["mood"]["word"] == "спокойна", me)
ep = relay.owner_posts("est")
check("пост записан", ep and ep[-1]["text"] == "Сегодня порт закрыт. Хорошая работа.", ep)
relay._ew("posts.json", [])
_c, _ev = relay.apply_est_marks("[пост: Сегодня порт закрыт. Хорошая работа. | картинка]\n[медиа: img_1_abcdef12.png | клинок]")
ep = relay.owner_posts("est")
check("нарисованное в ответе прикладывается к посту", ep[-1].get("media") == "img_1_abcdef12.png", ep)
check("в changes — что изменилось на странице", {c["kind"] for c in r["changes"]} >= {"статус", "настроение", "пост"}, r["changes"])
check("в промпте Эст — её страница", "Твой статус на странице" in relay.est_system() and "спокойна" in relay.est_system())

# --- лайки и комменты Эст: посты Адониса (через приложение), Гесперы (на сервере)
now_ms = int(time.time() * 1000)
PAGE = {"posts": [{"id": "p1", "author": "adonis", "text": "Запустили новый стан, гудит как зверь", "at": now_ms, "liked_by": [], "comments": []}]}
relay._hw("posts.json", [{"id": 777, "at": time.time(), "text": "Разглядывала дождь за окном"}])
answer("[лайк: новый стан]\n[коммент: новый стан | громкий. Одобряю.]\n[лайк: разглядывала дождь]")
r = run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="лента")], page=PAGE), "Bearer tok"))
ch = r["changes"]
check("лайк и коммент к посту Адониса — приложению", any(c["kind"] == "лайк" and c["field"] == "p1" for c in ch) and any(c["kind"] == "коммент" and c["field"] == "p1" and "Одобряю" in c["value"] for c in ch), ch)
check("лайк посту Гесперы записан на сервере", relay.hespera_posts()[-1].get("liked_est") is True)
check("Эст видит ленту Адониса", "пост Адониса" in seen["sys"][-1])

# --- Геспера и Аврора — к постам Эст
answer("[лайк: порт закрыт]\n[коммент: порт закрыт | а кто закрыл-то?]")
r = run(relay.hespera_chat(relay.HesperaReq(messages=[M(role="user", content="привет")]), "Bearer tok"))
ep = relay.owner_posts("est")[-1]
check("Геспера видит посты Эст", "ПОСТЫ ЭСТ" in seen["sys"][-1])
check("Геспера лайкнула и прокомментировала пост Эст", ep.get("liked_hespera") and ep["comments"][-1] == {**ep["comments"][-1], "who": "hespera", "text": "а кто закрыл-то?"}, ep)
r = run(relay.hespera_like(relay.LikeReq(snippet="порт закрыт", who="aurora"), "Bearer tok"))
check("Аврора лайкнула пост Эст по словам (через тот же адрес)", r["owner"] == "est" and relay.owner_posts("est")[-1].get("liked_aurora"))
r = run(relay.hespera_like(relay.LikeReq(id=ep["id"], owner="est"), "Bearer tok"))
r = run(relay.hespera_comment(relay.CommentReq(id=ep["id"], owner="est", text="Молодцы обе"), "Bearer tok"))
check("Адонис лайкнул и прокомментировал пост Эст", relay.owner_posts("est")[-1].get("liked") and r["comments"][-1]["who"] == "adonis")
answer("[коммент: порт закрыт | Аврора. Геспера проверила логи.]")
run(relay.est_chat(relay.EstReq(messages=[M(role="user", content="?")]), "Bearer tok"))
check("Эст отвечает под своим постом", relay.owner_posts("est")[-1]["comments"][-1]["who"] == "est")
st = relay.est_self_text()
check("Эст видит, кто лайкнул её пост и комментарии", "♥" in st and "Адонис" in st and "Геспера: а кто закрыл-то?" in st, st)

# --- профиль и эпизоды
answer('{"episode": "Адонис спросил, как я. Я ответила коротко.", "notes": ["Адонис работает посменно"]}')
r = run(relay.est_reflect(relay.EstReflectReq(messages=[M(role="user", content="как ты?"), M(role="assistant", content="На страже.")], upto="c-1"), "Bearer tok"))
check("эпизод и заметка", r["episode"] and r["notes"] == 1)
r = run(relay.est_reflect(relay.EstReflectReq(messages=[M(role="user", content="как ты?")], upto="c-1"), "Bearer tok"))
check("одна порция дважды не пересказывается", r.get("skipped"))
pr = run(relay.est_profile("Bearer tok"))
check("профиль: статус, настроение, поля, посты, память", pr["status"] == "на страже" and pr["mood"]["word"] == "спокойна" and len(pr["fields"]) >= 5
      and pr["posts"] and pr["episodes_n"] == 1 and "посменно" in " ".join(pr["notes"]), pr)
check("эпизоды в её памяти", "ЧТО БЫЛО РАНЬШЕ" in relay.est_memory_text())

print(f"\nИтого: {ok_n} ок, {bad_n} нет")
sys.exit(1 if bad_n else 0)
