"""Запасные модели: пропал канал у основной — отвечает следующая; упавшая отдыхает; диагностика."""
import asyncio, json, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
TMP = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://up/v1/chat/completions", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=TMP + "/core.md",
                  FLOOR_PATH=TMP + "/floor.md", HAND_LOG=TMP + "/hand.log", HAND_OFF=TMP + "/hand.off", PUBLIC_TOKEN="pub",
                  PUBLIC_LOG=TMP + "/public.jsonl", PUBLIC_CORE_PATH=TMP + "/pc.md", FEEDBACK_LOG=TMP + "/f.jsonl",
                  TOOLS_STATE=TMP + "/t.json", HESPERA_DIR=TMP + "/h", DUO_DIR=TMP + "/d", SEARCH_MODEL="off",
                  MODEL="deepseek-v4-flash", MODEL_SPARE="gemini-3.8-flash,grok-4.7",
                  FALLBACK_URL="http://fb/v1/chat/completions", FALLBACK_KEY="fk", FALLBACK_MODEL="deepseek-chat")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
def run(c): return asyncio.run(c)

class Resp:
    def __init__(self, status, data): self.status_code = status; self._d = data; self.text = json.dumps(data, ensure_ascii=False)
    def json(self): return self._d
calls = []
behave = {}
class Client:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def post(self, url, headers=None, json=None, **k):
        m = json["model"]
        calls.append((url, m))
        b = behave.get(m, "ok")
        if b == "gone":
            return Resp(503, {"error": {"code": "model_not_found", "message": "No available channel for model " + m}})
        if b == "bad":
            return Resp(400, {"error": "bad image"})
        if b == "quota":
            return Resp(429, {"error": "rate limit"})
        return Resp(200, {"choices": [{"message": {"content": "ответ " + m}}]})
relay.httpx.AsyncClient = Client
M = [{"role": "user", "content": "привет"}]

behave.clear(); calls.clear()
check("основная жива — отвечает она", run(relay.ask_model(M)) == "ответ deepseek-v4-flash" and len(calls) == 1)

behave["deepseek-v4-flash"] = "gone"; calls.clear()
out = run(relay.ask_model(M))
check("у основной пропал канал — отвечает запасная того же провайдера", out == "ответ gemini-3.8-flash" and calls[-1] == ("http://up/v1/chat/completions", "gemini-3.8-flash"), calls)
calls.clear()
run(relay.ask_model(M))
check("упавшая отдыхает: следующий запрос сразу к запасной", calls == [("http://up/v1/chat/completions", "gemini-3.8-flash")], calls)

behave.update({"gemini-3.8-flash": "gone", "grok-4.7": "gone"}); relay.MODEL_DEAD.clear(); calls.clear()
out = run(relay.ask_model(M))
check("все модели провайдера упали — отвечает запасной провайдер", out == "ответ deepseek-chat" and calls[-1][0] == "http://fb/v1/chat/completions", calls)

behave.clear(); behave["deepseek-chat"] = "gone"; behave.update({"deepseek-v4-flash": "gone", "gemini-3.8-flash": "gone", "grok-4.7": "gone"})
relay.MODEL_DEAD.clear()
try:
    run(relay.ask_model(M)); err = ""
except relay.HTTPException as e:
    err = str(e.detail)
check("не ответил никто — понятная ошибка со списком", "ни одна модель не ответила" in err and "gemini-3.8-flash" in err, err)

behave.clear(); behave["deepseek-v4-flash"] = "bad"; relay.MODEL_DEAD.clear(); calls.clear()
try:
    run(relay.ask_model(M)); err = ""
except relay.HTTPException as e:
    err = str(e.detail)
check("ошибка в самом запросе (400) — запасные не дёргаются", err.startswith("upstream 400") and len(calls) == 1, (err, calls))

behave.clear(); behave["deepseek-v4-flash"] = "quota"; relay.MODEL_DEAD.clear(); calls.clear()
out = run(relay.ask_model(M))
check("лимит провайдера (429) — сразу запасной провайдер, не перебор моделей", out == "ответ deepseek-chat" and [c[1] for c in calls] == ["deepseek-v4-flash", "deepseek-chat"], calls)

behave.clear(); behave["deepseek-v4-flash"] = "gone"; relay.MODEL_DEAD.clear()
d = run(relay.diag_models("", "Bearer tok"))
st = {p["model"]: p["ok"] for p in d["probe"]}
check("диагностика: видно, кто жив", st == {"deepseek-v4-flash": False, "gemini-3.8-flash": True, "grok-4.7": True, "запасной провайдер: deepseek-chat": True}, d)
check("диагностика: основная и запасные", d["main"] == "deepseek-v4-flash" and d["spare"] == ["gemini-3.8-flash", "grok-4.7"])
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
