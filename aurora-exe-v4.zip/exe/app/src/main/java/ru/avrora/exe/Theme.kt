package ru.avrora.exe

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Shapes
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Палитра «флюорит»: почти чёрный с фиолетовым оттенком, флюоритовая бирюза для Авроры, фиолет для Адониса.
val Night = Color(0xFF09060F)
val Panel = Color(0xFF120D1E)
val BubbleAurora = Color(0xFF141026)
val BubbleUser = Color(0xFF2A1B52)
val Glow = Color(0xFF5EEAD4)       // флюоритовая бирюза: её цвет
val Violet = Color(0xFFA78BFA)     // фиолет: цвет Адониса и акценты
val TextMain = Color(0xFFE6E1F2)
val TextDim = Color(0xFF9088AB)
val Edge = Color(0xFF2B2145)
val Terminal = Color(0xFF07040C)
val ErrorRed = Color(0xFFFF8F8F)

val AuroraColors = darkColorScheme(
    primary = Glow,
    onPrimary = Night,
    secondary = Violet,
    background = Night,
    onBackground = TextMain,
    surface = Panel,
    onSurface = TextMain,
    onSurfaceVariant = TextDim,
    outline = Edge,
    primaryContainer = BubbleUser,
    onPrimaryContainer = TextMain,
    error = Color(0xFFFF8F8F)
)

/** Обычный шрифт мессенджера. Моноширинным остаются только служебные строки и имя системы. */
val ConsoleTypography: Typography = Typography()

/** Скруглённые углы мессенджера. */
val ConsoleShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun auroraFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextMain,
    unfocusedTextColor = TextMain,
    cursorColor = Glow,
    focusedBorderColor = Violet.copy(alpha = 0.8f),
    unfocusedBorderColor = Edge,
    focusedPlaceholderColor = TextDim,
    unfocusedPlaceholderColor = TextDim,
    focusedLabelColor = Glow,
    unfocusedLabelColor = TextDim
)
