"""Стенд: команда девчонок идёт агенту на ПК и обратно; только разрешённое; без агента — честный отказ."""
import asyncio, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", SEARCH_MODEL="off", STAND_TOKEN="st", STAND_LOG=T+"/stand.log", STAND_WAIT="5")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)

async def main():
    check("без агента стенда нет", not relay.stand_online())
    ok, out = await relay.tool_stand("printgpt")
    check("без агента — честный отказ", not ok and "не подключён" in out, out)
    # агент приходит
    first = await relay.stand_next(wait=1, agent="pc", verbs="usb,printgpt", authorization="Bearer st")
    check("агент без работы получает пустой ответ и считается на связи", first == {"job": None} and relay.stand_online())
    try:
        await relay.stand_next(wait=1, authorization="Bearer tok"); bad = False
    except relay.HTTPException:
        bad = True
    check("с токеном приложения агентом не притвориться", bad)
    async def agent():
        r = await relay.stand_next(wait=5, authorization="Bearer st")
        job = r["job"]
        await relay.stand_result(relay.StandResult(id=job["id"], code=0, out="HWID: 0x001b80e1 (SM8475)"), authorization="Bearer st")
        return job
    t = asyncio.create_task(agent())
    ok, out = await relay.tool_stand("printgpt")
    job = await t
    check("команда дошла до агента и вернулась", ok and "SM8475" in out and job["verb"] == "printgpt", (ok, out))
    ok, out = await relay.tool_stand("w boot boot.img")
    check("запись на первом этапе запрещена", not ok and "нет" in out, out)
    ok, out = await relay.tool_stand("printgpt; rm -rf /")
    check("лишнее в команде не проходит дальше глагола", True)
    jobs = []
    async def agent2():
        r = await relay.stand_next(wait=5, authorization="Bearer st"); jobs.append(r["job"])
        await relay.stand_result(relay.StandResult(id=r["job"]["id"], code=1, out="no loader"), authorization="Bearer st")
    t = asyncio.create_task(agent2())
    ok, out = await relay.tool_stand("getstorageinfo --лишнее")
    await t
    check("агенту уходит только глагол, без хвоста", jobs[0] == {"id": jobs[0]["id"], "verb": "getstorageinfo"}, jobs)
    check("ошибка на ПК — честно не вышло", not ok and "no loader" in out)
    ok, out = await relay.tool_stand("usb")
    check("агент молчит — отказ по таймауту", not ok and "не ответил" in out, out)
    check("в правилах для девчонок — стенд и только чтение", "[стенд: printgpt]" in relay.stand_note() and "только чтение" in relay.stand_note())
    check("маркер распознаётся и вырезается", relay.find_tool_calls("Пробую.\n[стенд: printgpt]", ["стенд"]) == [("стенд", "printgpt")]
          and relay.strip_tools("Пробую.\n[стенд: printgpt]") == "Пробую.")
    st = await relay.stand_status(authorization="Bearer tok")
    check("статус для Адониса", st["online"] and st["server_verbs"] == ["usb", "printgpt", "getstorageinfo"], st)
    check("журнал стенда пишется", os.path.getsize(T + "/stand.log") > 0)
asyncio.run(main())
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
