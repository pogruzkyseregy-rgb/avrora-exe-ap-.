"""Маркеры руки: блок с переносами, блок в одну строку, одной строкой; невыполненное не уходит в чат."""
import os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="t", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h", HAND_OFF=T+"/o",
                  PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb", TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", SEARCH_MODEL="off")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
cases = [
    ("блок в одну строку (как у Гесперы)", "Смотрю.\n[рука]echo '== ls =='; ls -la /home/aurora/work/site/ 2>/dev/null | head -30; find /home/aurora -iname '*184106*' | head[/рука]",
     ["echo '== ls =='; ls -la /home/aurora/work/site/ 2>/dev/null | head -30; find /home/aurora -iname '*184106*' | head"], "Смотрю."),
    ("блок с переносами", "[рука]\nls\npwd\n[/рука]\nготово", ["ls\npwd"], "готово"),
    ("одной строкой", "[рука: ls -la ~/hespera]", ["ls -la ~/hespera"], ""),
    ("после текста, со скобками внутри", "Проверю. [рука: [ -f x ] && echo yes]", ["[ -f x ] && echo yes"], "Проверю."),
    ("две команды", "[рука]ls[/рука]\n[рука: pwd]", ["ls", "pwd"], ""),
]
for name, txt, want, rest in cases:
    got = [a for _, a in relay.find_tool_calls(txt, ["рука"])]
    check(name + ": распознан", got == want, got)
    check(name + ": из текста вырезан", relay.strip_tools(txt) == rest, repr(relay.strip_tools(txt)))
check("без права «рука» не выполняется", relay.find_tool_calls("[рука]ls[/рука]", ["поиск"]) == [])
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
