"""Стенд: команды девчонок идут агенту на ПК и обратно; полный доступ к телефону; без агента — честный отказ."""
import asyncio, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", SEARCH_MODEL="off", STAND_TOKEN="st", STAND_LOG=T+"/stand.log", STAND_WAIT="2")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)

async def answer(code, out, jobs):
    r = await relay.stand_next(wait=5, authorization="Bearer st")
    jobs.append(r["job"])
    await relay.stand_result(relay.StandResult(id=r["job"]["id"], code=code, out=out), authorization="Bearer st")

async def main():
    check("без агента стенда нет", not relay.stand_online())
    ok, out = await relay.tool_stand("edl printgpt")
    check("без агента — честный отказ", not ok and "не подключён" in out, out)
    first = await relay.stand_next(wait=1, agent="pc", verbs="usb,edl,fastboot,adb", authorization="Bearer st")
    check("агент без работы получает пустой ответ и считается на связи", first == {"job": None} and relay.stand_online())
    try:
        await relay.stand_next(wait=1, authorization="Bearer tok"); bad = False
    except relay.HTTPException:
        bad = True
    check("с токеном приложения агентом не притвориться", bad)
    jobs = []
    t = asyncio.create_task(answer(0, "HWID: 0x001b80e1 (SM8475)", jobs))
    ok, out = await relay.tool_stand("printgpt")
    await t
    check("короткое «printgpt» — это edl, дошло и вернулось", ok and "SM8475" in out and jobs[-1]["cmd"] == "edl printgpt", (ok, out, jobs))
    t = asyncio.create_task(answer(0, "Wrote boot_a", jobs))
    ok, out = await relay.tool_stand("edl w boot_a boot.img")
    await t
    check("запись разделов теперь можно", ok and jobs[-1]["cmd"] == "edl w boot_a boot.img", (ok, out))
    for cmd in ("fastboot flash boot_a boot.img", "adb reboot edl", "скачать https://example.org/fw.zip fw.zip", "файлы"):
        t = asyncio.create_task(answer(0, "ok", jobs))
        ok, out = await relay.tool_stand(cmd)
        await t
        check(f"проходит: {cmd}", ok and jobs[-1]["cmd"] == cmd, (ok, jobs[-1]))
    ok, out = await relay.tool_stand("powershell rm -r C:\\")
    check("чужие программы не проходят", not ok and "нет такого" in out, out)
    t = asyncio.create_task(answer(1, "no loader", jobs))
    ok, out = await relay.tool_stand("edl getstorageinfo")
    await t
    check("ошибка на ПК — честно не вышло", not ok and "no loader" in out)
    # долгая команда: агент берёт, но отвечает позже
    ok, out = await relay.tool_stand("fastboot flash super super.img")
    jid = out.split("№")[1].split(")")[0] if "№" in out else ""
    check("долгая команда возвращает номер", ok and jid and f"итог {jid}" in out, out)
    ok, out = await relay.tool_stand(f"итог {jid}")
    check("итог пока — «ещё идёт»", ok and "ещё идёт" in out, out)
    r = await relay.stand_next(wait=1, authorization="Bearer st")
    await relay.stand_result(relay.StandResult(id=r["job"]["id"], code=0, out="Finished. Total time: 300s"), authorization="Bearer st")
    ok, out = await relay.tool_stand(f"итог №{jid}")
    check("итог после конца — вывод", ok and "Finished" in out, out)
    ok, out = await relay.tool_stand("итог zzzzzz")
    check("итог несуществующей — честно нет", not ok, out)
    note = relay.stand_note()
    check("в правилах — полный доступ и папка стенда", "[стенд: usb]" in note and "можно всё" in note and "папки стенда" in note)
    check("маркер распознаётся и вырезается", relay.find_tool_calls("Пробую.\n[стенд: edl printgpt]", ["стенд"]) == [("стенд", "edl printgpt")]
          and relay.strip_tools("Пробую.\n[стенд: edl printgpt]") == "Пробую.")
    st = await relay.stand_status(authorization="Bearer tok")
    check("статус для Адониса", st["online"] and st["agent_tools"] == ["usb", "edl", "fastboot", "adb"] and "edl" in st["server_tools"], st)
    check("журнал стенда пишется", os.path.getsize(T + "/stand.log") > 0)
asyncio.run(main())
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
