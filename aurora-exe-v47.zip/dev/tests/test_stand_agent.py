"""Агент стенда на ПК: полный доступ к телефону через edl/fastboot/adb, но файлы — только в папке стенда, без оболочки ПК."""
import importlib.util, os, shutil, sys, tempfile, stat
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "..", "stand", "stand_agent.py")
D = tempfile.mkdtemp(); shutil.copy(SRC, D)
spec = importlib.util.spec_from_file_location("stand_agent", os.path.join(D, "stand_agent.py"))
A = importlib.util.module_from_spec(spec); spec.loader.exec_module(A)
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
fake = {}
for tool in ("edl", "fastboot", "adb"):
    p = os.path.join(D, "fake_" + tool)
    open(p, "w").write("#!/bin/sh\necho \"%s $@\"\npwd\n" % tool)
    os.chmod(p, os.stat(p).st_mode | stat.S_IEXEC); fake[tool] = p
c = {**A.DEFAULT, "token": "t", **fake}
W = os.path.realpath(os.path.join(D, "стенд"))
code, out = A.handle(c, "edl w boot_a boot.img")
check("edl запись идёт, файл — внутри папки стенда", code == 0 and "edl w boot_a" in out and W + "/boot.img" in out and W in out, out)
code, out = A.handle(c, 'fastboot flash boot_a "прошивки/boot new.img"')
check("подпапки и пробелы в кавычках", code == 0 and W + "/прошивки/boot new.img" in out, out)
code, out = A.handle(c, "edl printgpt --loader=loaders/sm8475.elf")
check("--loader=файл тоже в папке стенда", code == 0 and "--loader=" + W + "/loaders/sm8475.elf" in out, out)
for bad in ("edl r boot_a ../boot.img", "edl r boot_a C:\\Windows\\x.img", "fastboot flash boot /etc/passwd", "adb push ../../x.bin /sdcard/",
            "edl printgpt --loader=/tmp/x.elf"):
    code, out = A.handle(c, bad)
    check(f"вне папки — нет: {bad}", code != 0 and "вне папки" in out, out)
code, out = A.handle(c, "adb shell getprop ro.product.model")
check("adb shell на телефоне — можно", code == 0 and "adb shell getprop" in out, out)
for bad in ("adb forward tcp:1 tcp:2", "adb connect 1.2.3.4", "adb tcpip 5555", "edl server"):
    code, out = A.handle(c, bad)
    check(f"сеть ПК — нет: {bad}", code != 0 and "выключен" in out, out)
for bad in ("cmd /c dir", "powershell ls", "python -c 1", "edl; rm -rf /"):
    code, out = A.handle(c, bad)
    check(f"чужое — нет: {bad}", code != 0, out)
code, out = A.handle(c, "edl printgpt; rm -rf x")
check("без оболочки: «;» — просто аргумент edl", code == 0 and "rm -rf x" in out and os.path.exists(D), out)
code, out = A.handle(c, "adb push magisk.apk /sdcard/Download/")
check("adb push: файл ПК из папки, путь телефона как есть", code == 0 and W + "/magisk.apk /sdcard/Download/" in out, out)
code, out = A.handle(c, "adb pull /sdcard/DCIM/a.jpg")
check("adb pull без места — в папку стенда", code == 0 and "/sdcard/DCIM/a.jpg " + W in out, out)
code, out = A.handle(c, "adb pull /sdcard/a.jpg C:\\Users\\a.jpg")
check("adb pull на диск ПК — нет", code != 0, out)
code, out = A.handle(c, "adb shell ls -l /data/local/tmp")
check("adb shell с путями телефона — можно", code == 0 and "/data/local/tmp" in out, out)
open(os.path.join(W, "boot.img"), "wb").write(b"x" * 4096)
code, out = A.handle(c, "файлы")
check("файлы — список папки стенда", code == 0 and "boot.img" in out, out)
code, out = A.handle(c, "скачать http://x/y.zip y.zip")
check("скачивать — только https", code != 0, out)
code, out = A.handle(c, "скачать https://x/y.zip ../y.zip")
check("скачивать — только в папку стенда", code != 0, out)
c2 = {**c, "tools": ["usb", "edl"]}
code, out = A.handle(c2, "fastboot devices")
check("инструмент, выключенный в настройках, — нет", code != 0 and "не разрешён" in out, out)
c3 = {**c, "fastboot": os.path.join(D, "нет_такого")}
code, out = A.handle(c3, "fastboot devices")
check("нет программы — подсказка про install.bat", code != 0 and "install.bat" in out, out)
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
