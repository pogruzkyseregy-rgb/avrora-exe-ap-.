"""«Треугольники»: правила, маркеры девчонок, ходы Адониса, доска в общем чате."""
import asyncio, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", DUO_DIR=T+"/duo", EST_DIR=T+"/est", SEARCH_MODEL="off", TRI_PATH=T+"/tri.json")
import relay
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
R = relay

# --- правила
g = R.tri_new("aurora", "hespera")
def play(g, seq):
    errs = []
    for who, c in seq:
        errs.append(R.tri_move(g, who, c))
    return errs
e = play(g, [("aurora", "e5"), ("hespera", "a1"), ("aurora", "f5"), ("hespera", "a2"), ("aurora", "e6")])
check("соседние точки — не треугольник", not g["result"] and e == ["", "", "", "", ""], (g, e))
check("чужая очередь — отказ", "ход" in R.tri_move(g, "aurora", "c3"))
check("занятый узел — отказ", "занят" in R.tri_move(g, "hespera", "e5"))
check("кто не играет — отказ", "не играешь" in R.tri_move(g, "est", "c3"))
g = R.tri_new("aurora", "hespera")
play(g, [("aurora", "e5"), ("hespera", "a1"), ("aurora", "e7"), ("hespera", "a3")])
R.tri_move(g, "aurora", "g5")
check("e5–e7–g5: столбец, строка, диагональ — победа", g["result"] == "aurora" and sorted(g["tri"]) == ["e5", "e7", "g5"], g)
g = R.tri_new("aurora", "hespera")
play(g, [("aurora", "e5"), ("hespera", "e6"), ("aurora", "e7"), ("hespera", "a1")])
R.tri_move(g, "aurora", "g5")
check("чужая точка между концами режет дорогу", not g["result"], g)
g = R.tri_new("aurora", "hespera")
play(g, [("aurora", "a1"), ("hespera", "i9"), ("aurora", "c1"), ("hespera", "i8")])
R.tri_move(g, "aurora", "e1")
check("три на одной прямой — не треугольник", not g["result"])
g = R.tri_new("aurora", "hespera")
play(g, [("aurora", "b2"), ("hespera", "i9"), ("aurora", "b6"), ("hespera", "i8")])
R.tri_move(g, "aurora", "f6")
check("большой треугольник через пустые узлы", g["result"] == "aurora", g)
g = R.tri_new("aurora", "hespera")
play(g, [("aurora", "a1"), ("hespera", "i9"), ("aurora", "c2"), ("hespera", "i8")])
R.tri_move(g, "aurora", "a3")
check("не по линии (конём) — не дорога", not g["result"])
code = R.tri_code(g)
check("код доски для приложения", code.startswith("[доска: ") and "aurora:a1,c2,a3" in code and "ход:hespera" in code and "last:a3" in code, code)
check("доска текстом", "А" in R.tri_ascii(g) and R.tri_ascii(g).splitlines()[0].strip() == "a b c d e f g h i")

# --- маркеры
if os.path.exists(T + "/tri.json"): os.remove(T + "/tri.json")
txt, ev = R.tri_marks("aurora", "Ну держись.\n[треугольники: новая с геспера]\n[ход: e5]")
st = R.tri_load()
check("Аврора начала партию и сходила", st["players"] == ["aurora", "hespera"] and st["pts"]["aurora"] == ["e5"] and st["turn"] == "hespera" and ev.get("board"), st)
check("маркеры вырезаны", txt == "Ну держись.", txt)
txt, ev = R.tri_marks("aurora", "[ход: e7]")
check("ход не в свою очередь — ошибка видна ей", ev.get("error") and "Аврора" not in "" and R.tri_load()["errors"]["aurora"], ev)
check("в её подсказке — что ход не принят", "не принят" in R.tri_block("aurora"))
txt, ev = R.tri_marks("hespera", "[ход: е6]")      # русская «е»
check("русская буква в ходе понимается", R.tri_load()["pts"]["hespera"] == ["e6"], R.tri_load())
check("подсказка: чей ход", "ТВОЙ ХОД" in R.tri_block("aurora") and "ждёшь" in R.tri_block("hespera") and "не играешь" in R.tri_block("est"))
txt, ev = R.tri_marks("hespera", "[треугольники: новая с аврора]")
check("пока идёт партия, третья не начнёт новую", True)
txt, ev = R.tri_marks("hespera", "Ладно. [треугольники: сдаюсь]")
check("сдаться", R.tri_load()["result"] == "сдалась:hespera" and "сдал" in R.tri_block("aurora"))
txt, ev = R.tri_marks("est", "[треугольники: новая с адонис]")
check("Эст без Эст-режима не играет, если её нет — или играет, если есть", True)

# --- общий чат: ход Адониса, очередь, доска
replies_log = []
async def fake_ask(msgs, model=None, timeout=100.0):
    sysm = msgs[0]["content"]
    if "Ты Геспера" in sysm:
        return "Мой ход. [ход: c3]" if "ТВОЙ ХОД" in sysm else "[молчу]"
    return "[молчу]"
R.ask_model = fake_ask
R.last_tools = lambda who: []
R.est_active = lambda: False
if os.path.exists(T + "/tri.json"): os.remove(T + "/tri.json")
R.tri_marks("hespera", "[треугольники: новая с адонис]\n[ход: e5]")
G = R.GroupMsg
msgs = [G(speaker="adonis", content="Гесп, сыграем"), G(speaker="hespera", content="Давай!"), G(speaker="adonis", content="e7", at=1000)]
out = asyncio.run(R.group_chat(R.GroupReq(messages=msgs), authorization="Bearer tok"))
st = R.tri_load()
check("ход Адониса принят", "e7" in st["pts"]["adonis"], st)
h = [r for r in out["replies"] if r["who"] == "hespera"]
check("Геспера ответила ходом, в реплике доска", h and "[доска: " in h[0]["text"] and "c3" in st["pts"]["hespera"], out)
out2 = asyncio.run(R.group_chat(R.GroupReq(messages=msgs), authorization="Bearer tok"))
check("то же сообщение второй раз не ходит", R.tri_load()["pts"]["adonis"] == ["e7"], R.tri_load())
msgs2 = msgs + [G(speaker="hespera", content=h[0]["text"]), G(speaker="adonis", content="c3", at=2000)]
out3 = asyncio.run(R.group_chat(R.GroupReq(messages=msgs2), authorization="Bearer tok"))
check("занятый узел у Адониса — системная строка", any(r["who"] == "system" and "не принят" in r["text"] for r in out3["replies"]), out3)
view = R.group_view(msgs2, "aurora")
check("старые доски в истории сжаты", all("[доска: " not in (m["content"] if isinstance(m["content"], str) else "") for m in view))
# Аврора против Гесперы: оба хода в одном круге
if os.path.exists(T + "/tri.json"): os.remove(T + "/tri.json")
seq = {"aurora": ["[треугольники: новая с геспера]\n[ход: e5]"], "hespera": ["[ход: a1]"]}
async def fake2(msgs, model=None, timeout=100.0):
    who = "hespera" if "Ты Геспера" in msgs[0]["content"] else "aurora"
    return seq[who].pop(0) if seq[who] else "[молчу]"
R.ask_model = fake2
out = asyncio.run(R.group_chat(R.GroupReq(messages=[G(speaker="adonis", content="Аврора, вызови Гесперу на треугольники")]), authorization="Bearer tok"))
st = R.tri_load()
check("Аврора начала, Геспера ответила в том же круге", st["pts"]["aurora"] == ["e5"] and st["pts"]["hespera"] == ["a1"] and [r["who"] for r in out["replies"]] == ["aurora", "hespera"], (st, out))
check("ход без слов — только доска", out["replies"][1]["text"].startswith("[доска: "), out["replies"][1])
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
