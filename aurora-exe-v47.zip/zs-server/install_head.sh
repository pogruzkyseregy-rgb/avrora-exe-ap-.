#!/usr/bin/env bash
# Сервер Zero Spin на машине Авроры. Запуск от root НА СЕРВЕРЕ РУКИ:
#   ssh root@37.220.86.132 "bash -s" < install_zs.sh
# Ставит: Python-сервер (служба zs-server под пользователем aurora, код в /home/aurora/zs-server, Аврора его видит)
# и Caddy (HTTPS с бесплатным сертификатом на адрес вида 37-220-86-132.sslip.io). Повторный запуск обновляет код, ключи сохраняет.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Нужен root."; exit 1; }
id aurora >/dev/null 2>&1 || { echo "Нет пользователя aurora"; exit 1; }
DIR=/home/aurora/zs-server
IP="$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')"
HOST="$(echo "$IP" | tr . -).sslip.io"

echo "[1/6] Пакеты"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3-venv caddy curl >/dev/null

echo "[2/6] Код в $DIR"
install -d -o aurora -g aurora "$DIR"
base64 -d <<'PAYLOAD' | tar xzf - -C "$DIR"
