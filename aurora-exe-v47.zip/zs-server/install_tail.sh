PAYLOAD
chown -R aurora:aurora "$DIR"

echo "[3/6] Окружение Python"
[ -x "$DIR/venv/bin/python" ] || sudo -u aurora python3 -m venv "$DIR/venv"
sudo -u aurora "$DIR/venv/bin/pip" install -q --upgrade pip
sudo -u aurora "$DIR/venv/bin/pip" install -q fastapi uvicorn "httpx[http2]"

install -d -o aurora -g aurora "$DIR/media"
for t in aurora admin; do
  cat > /usr/local/bin/zs-$t <<WRAP
#!/bin/sh
# zs-$t: запускается от пользователя aurora, чтобы база оставалась её
export ZS_DB=$DIR/zs.db
if [ "\$(id -u)" = 0 ]; then exec sudo -u aurora -E python3 $DIR/zs_$t.py "\$@"; fi
exec python3 $DIR/zs_$t.py "\$@"
WRAP
  chmod 755 /usr/local/bin/zs-$t
done

echo "[4/6] Ключи"
ENV=/etc/zs-server.env
if [ ! -f "$ENV" ]; then
  cat > "$ENV" <<CONF
RELAY_URL=https://avrora-exe.ru/app-api
PUBLIC_TOKEN=$(openssl rand -hex 24)
ADMIN_TOKEN=$(openssl rand -hex 24)
ZS_DB=$DIR/zs.db
CONF
fi
chmod 640 "$ENV"; chgrp aurora "$ENV"

echo "[5/6] Служба"
cat > /etc/systemd/system/zs-server.service <<UNIT
[Unit]
Description=Zero Spin server
After=network-online.target
[Service]
User=aurora
WorkingDirectory=$DIR
EnvironmentFile=$ENV
# без журнала запросов: в адресах есть логины, а кто кому пишет — тоже личное
ExecStart=$DIR/venv/bin/uvicorn zs_server:app --host 127.0.0.1 --port 8077 --no-access-log
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now zs-server >/dev/null 2>&1
systemctl restart zs-server

echo "[6/6] HTTPS (Caddy) для $HOST"
cat > /etc/caddy/Caddyfile <<CADDY
$HOST {
    reverse_proxy 127.0.0.1:8077
}
CADDY
if command -v ufw >/dev/null && ufw status | grep -q active; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi
systemctl enable --now caddy >/dev/null 2>&1
systemctl reload caddy || systemctl restart caddy
sleep 4
echo
echo "Проверка изнутри: $(curl -s http://127.0.0.1:8077/api/health)"
echo
. "$ENV"
echo "ГОТОВО."
echo "Адрес сервера для приложения:  https://$HOST"
echo "Ключ для основного сервера (одна строка, выполни её там):"
echo "  echo PUBLIC_TOKEN=$PUBLIC_TOKEN >> /opt/aurora-relay/relay.env && systemctl restart aurora-relay"
echo "Админ-ключ (для снятия бана, храни у себя): $ADMIN_TOKEN"
echo "Создать админа (пароль спросит сама команда):  ssh -t root@ЭТОТ_СЕРВЕР zs-admin create-admin Adonis_AV"
echo "Снять бан:  zs-admin unban ЛОГИН      Профиль Авроры:  zs-aurora help"
