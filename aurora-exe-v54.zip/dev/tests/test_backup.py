"""Копия приложения на сервере: загрузка кусками, сборка, проверка, скачивание, ротация."""
import asyncio, base64, io, os, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs")); sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", SEARCH_MODEL="off", APP_BACKUP_DIR=T+"/bk", APP_BACKUP_KEEP="2")
import relay as R
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
A = "Bearer tok"
def make_zip(extra=b""):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("files/chat.json", '[{"role":"user","content":"привет"}]')
        z.writestr("files/hespera_chat.json", "[]")
        z.writestr("files/media/big.bin", os.urandom(9 * 1024 * 1024) + extra)
    return b.getvalue()
def upload(data, bid):
    P = R.APP_BACKUP_PART
    parts = [data[i:i + P] for i in range(0, len(data), P)]
    for n, c in enumerate(parts):
        r = asyncio.run(R.backup_part(R.BackupPart(id=bid, n=n, data=base64.b64encode(c).decode(), last=n == len(parts) - 1), authorization=A))
    return r, len(parts)
check("без копии — exists false", asyncio.run(R.backup_info(authorization=A)) == {"exists": False})
z1 = make_zip()
r, np_ = upload(z1, "aaaa1111")
check("копия из нескольких кусков собрана", r.get("saved") and np_ >= 3, (r, np_))
info = asyncio.run(R.backup_info(authorization=A))
check("инфо о последней копии", info["exists"] and info["size"] == len(z1) and info["parts"] == np_, info)
got = b"".join(base64.b64decode(asyncio.run(R.backup_get(info["name"], n, authorization=A))["data"]) for n in range(info["parts"]))
check("скачанная копия совпадает байт в байт", got == z1)
check("внутри — переписка", "files/chat.json" in zipfile.ZipFile(io.BytesIO(got)).namelist())
try:
    asyncio.run(R.backup_part(R.BackupPart(id="bbbb2222", n=1, data=base64.b64encode(b"x").decode(), last=True), authorization=A)); bad = False
except R.HTTPException:
    bad = True
check("пропущенный кусок — отказ", bad)
try:
    asyncio.run(R.backup_part(R.BackupPart(id="cccc3333", n=0, data=base64.b64encode(b"not a zip").decode(), last=True), authorization=A)); bad = False
except R.HTTPException:
    bad = True
check("не архив — отказ, мусор не остаётся", bad and len(R.app_backups()) == 1)
for bid in ("dddd4444", "eeee5555"):
    import time; time.sleep(1.1)
    upload(make_zip(bid.encode()), bid)
check("хранятся последние 2 копии", len(R.app_backups()) == 2 and "eeee5555" in R.app_backups()[-1].name, [p.name for p in R.app_backups()])
for bad_name in ("../relay.env", "backup-1-zz.zip"):
    try:
        asyncio.run(R.backup_get(bad_name, 0, authorization=A)); bad = False
    except R.HTTPException:
        bad = True
    check(f"чужой файл не отдаётся: {bad_name}", bad)
try:
    asyncio.run(R.backup_info(authorization="Bearer x")); bad = False
except R.HTTPException:
    bad = True
check("без токена — нет", bad)
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
