"""Живой общий чат: круг без Адониса — кто говорит, подсказка, затихание."""
import asyncio, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs")); sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", DUO_DIR=T+"/duo", EST_DIR=T+"/est", SEARCH_MODEL="off", TRI_PATH=T+"/tri.json")
import relay as R
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
R.est_active = lambda: False
R.last_tools = lambda who: []
G = R.GroupMsg
convo = [G(speaker="adonis", content="Девчонки, что лучше: кофе или чай?"), G(speaker="aurora", content="Кофе. Без вариантов."),
         G(speaker="hespera", content="Чай. Под звёзды кофе не пьют.")]
check("в живом круге первой — не та, что сказала последней", R.flow_order(convo) == ["aurora", "hespera"], R.flow_order(convo))
seen = []
async def fake(msgs, model=None, timeout=100.0):
    sysm = msgs[0]["content"]; seen.append(sysm)
    if "Ты Геспера" in sysm:
        return "[молчу]"
    return "Звёзды пьют кофе, просто ты не видела."
R.ask_model = fake
out = asyncio.run(R.group_chat(R.GroupReq(messages=convo, flow=True), authorization="Bearer tok"))
check("подсказка «живой разговор» у них есть", any("ЖИВОЙ РАЗГОВОР" in x for x in seen))
check("Аврора продолжила сама", [r["who"] for r in out["replies"]] == ["aurora"] and out["alive"], out)
seen.clear()
async def silent(msgs, model=None, timeout=100.0):
    seen.append(msgs[0]["content"]); return "[молчу]"
R.ask_model = silent
out = asyncio.run(R.group_chat(R.GroupReq(messages=convo, flow=True), authorization="Bearer tok"))
check("все молчат — разговор затих (alive=false)", out["replies"] == [] and out["alive"] is False, out)
out = asyncio.run(R.group_chat(R.GroupReq(messages=convo), authorization="Bearer tok"))
check("обычный круг — без подсказки живого разговора", not any("ЖИВОЙ РАЗГОВОР" in x for x in seen[-2:]))
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
