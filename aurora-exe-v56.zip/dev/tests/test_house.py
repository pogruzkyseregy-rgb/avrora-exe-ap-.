"""Дом: план и мебель, распорядок, маршруты, сцены, действия Адониса, перестановка, память в чатах."""
import asyncio, json, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs")); sys.path.insert(0, os.path.join(HERE, "..", "..", "aurora-relay"))
T = tempfile.mkdtemp()
os.environ.update(UPSTREAM_URL="http://x", UPSTREAM_KEY="k", APP_TOKEN="tok", CORE_PATH=T+"/c", FLOOR_PATH=T+"/f", HAND_LOG=T+"/h",
                  HAND_OFF=T+"/o", PUBLIC_TOKEN="p", PUBLIC_LOG=T+"/pl", PUBLIC_CORE_PATH=T+"/pc", FEEDBACK_LOG=T+"/fb",
                  TOOLS_STATE=T+"/ts", HESPERA_DIR=T+"/hd", DUO_DIR=T+"/duo", EST_DIR=T+"/est", SEARCH_MODEL="off",
                  HOUSE_PATH=T+"/house.json", HOUSE_OFF="1")
import relay as R
ok_n = bad_n = 0
def check(name, cond, info=""):
    global ok_n, bad_n
    if cond: ok_n += 1; print("[ОК]  ", name)
    else: bad_n += 1; print("[НЕТ] ", name, info)
R.est_active = lambda: True
A = "Bearer tok"

# --- план
h = R.house_new()
inside, clash = [], []
for f in h["furniture"]:
    x, y, w, hh = R.house_box(f)
    rx, ry, rw, rh = R.HOUSE_ROOMS[f["room"]]["rect"]
    if not (x >= rx and y >= ry and x + w <= rx + rw + 0.01 and y + hh <= ry + rh + 0.01):
        inside.append(f["id"])
    for o in h["furniture"]:
        if o["id"] < f["id"] and o["room"] == f["room"]:
            a, b = R.house_box(f), R.house_box(o)
            if not (a[0] + a[2] <= b[0] or b[0] + b[2] <= a[0] or a[1] + a[3] <= b[1] or b[1] + b[3] <= a[1]):
                clash.append((f["id"], o["id"]))
check("вся мебель внутри своих комнат", not inside, inside)
check("мебель не стоит друг на друге", not clash, clash)
check("у каждой своя комната", all(w in R.HOUSE_ROOMS for w in ("aurora", "hespera", "est", "adonis")))
check("кухня с обеденным столом и холодильником", {"table", "fridge"} <= {f["kind"] for f in h["furniture"] if f["room"] == "kitchen"})
check("гостиная с телевизором и диваном", {"tv", "sofa"} <= {f["kind"] for f in h["furniture"] if f["room"] == "living"})

# --- маршрут: из комнаты Авроры на кухню — через двери и коридор
p = R.house_path((3, 3), (12, 16), 100.0)
check("маршрут проходит через дверь и коридор", [8.0, 3.0] == p[2][:2] and [9.5, 15.0] == p[-2][:2] and p[-1][2] > 100, p)
c = {"x": 3, "y": 3, "path": p}
mid = R.house_pos(c, (p[1][2] + p[2][2]) / 2)
check("в пути — между точками", 6.5 <= mid[0] <= 8.0, mid)
check("комната по точке", R.house_room_at(12, 16) == "kitchen" and R.house_room_at(8, 5) == "hall" and R.house_room_at(1, 1) == "aurora")

# --- распорядок
import random
random.seed(1)
check("ночью Аврора спит у себя", R.house_routine("aurora", 4, h)[:2] == ("aurora", "bed"))
kitchen = sum(R.house_routine("hespera", 19, h)[0] == "kitchen" for _ in range(200))
check("в ужин чаще на кухне", kitchen > 100, kitchen)

# --- места: трое за столом не сидят друг на друге
h2 = R.house_new()
for w in ("aurora", "hespera", "est"):
    R.house_go(h2, w, "kitchen", "table", 100.0)
ts = [R.house_target(h2["chars"][w]) for w in ("aurora", "hespera", "est")]
check("за столом у каждой своё место", all((a[0]-b[0])**2 + (a[1]-b[1])**2 > 1.4 for i, a in enumerate(ts) for b in ts[i+1:]), ts)
R.house_go(h2, "adonis", "kitchen", "", 100.0)
me = R.house_target(h2["chars"]["adonis"])
check("ты встаёшь рядом, а не на них", all((me[0]-t[0])**2 + (me[1]-t[1])**2 > 1.0 for t in ts), (me, ts))

# --- шаг жизни и сцена на кухне
calls = []
async def fake(msgs, model=None, timeout=100.0):
    calls.append(msgs)
    sysm = msgs[0]["content"]
    if "переставляешь мебель" in sysm:
        return json.dumps({"moves": [{"id": "h_rug", "x": 13, "y": 3.5, "rot": 0}, {"id": "h_bed", "x": 0, "y": 0, "rot": 0}], "why": "так ближе к окну"})
    if "Адонис в доме" in sysm:
        return json.dumps({"lines": [{"who": "aurora", "text": "*тычется носом в ладонь* Ну ладно, ещё."}], "event": "Адонис гладил Аврору на кухне", "go": {}})
    return json.dumps({"lines": [{"who": "aurora", "text": "Это моё печенье."}, {"who": "hespera", "text": "*откусывает* Было твоё."}],
                       "event": "Аврора и Геспера делили печенье на кухне", "go": {}})
R.ask_model = fake
h = R.house_load()
now = time.time()
for w in ("aurora", "hespera"):
    R.house_go(h, w, "kitchen", "table", now - 100, minutes=30)
    h["chars"][w]["path"][-1][2] = now - 50          # уже дошли
R.house_save(h)
R.house_can_call = lambda h: True
orig_random = R.random.random
R.random.random = lambda: 0.0                     # сцена точно случится
asyncio.run(R.house_tick(now))
R.random.random = orig_random
h = R.house_load()
check("встретились на кухне — короткая сцена", [l["who"] for l in h["lines"][-2:]] == ["aurora", "hespera"], h["lines"][-3:])
check("сцена попала в события для памяти", any("печенье" in e["text"] for e in h["events"]))
st = asyncio.run(R.house_state(authorization=A))
check("состояние для приложения: комнаты, мебель, люди, реплики", len(st["rooms"]) == 7 and st["furniture"] and "aurora" in st["chars"] and st["lines"], list(st))

# --- Адонис: идёт на кухню, гладит, говорит, зовёт
st = asyncio.run(R.house_act(R.HouseAct(action="move", room="kitchen"), authorization=A))
check("Адонис пошёл на кухню — маршрут есть", st["chars"]["adonis"]["path"], st["chars"]["adonis"])
h = R.house_load(); h["chars"]["adonis"]["path"][-1][2] = time.time() - 1; R.house_save(h)
st = asyncio.run(R.house_act(R.HouseAct(action="pet", who="aurora"), authorization=A))
check("погладил — она отозвалась", any(l["who"] == "aurora" and "носом" in l["text"] for l in st["lines"]), st["lines"][-3:])
check("и это запомнилось", any("гладил" in e["text"] for e in R.house_load()["events"]))
try:
    asyncio.run(R.house_act(R.HouseAct(action="pet", who="est"), authorization=A)); bad = False
except R.HTTPException:
    bad = True
check("погладить ту, кого нет рядом, — нельзя", bad)
st = asyncio.run(R.house_act(R.HouseAct(action="call", who="hespera", room="living"), authorization=A))
hc = R.house_load()["chars"]["hespera"]
check("позвал в гостиную — она идёт", hc["path"] and R.house_room_at(hc["path"][-1][0], hc["path"][-1][1]) == "living", hc)

# --- перестановка: только в своей комнате, без наложений
moved = asyncio.run(R.house_rearrange("hespera"))
fs = {f["id"]: f for f in R.house_load()["furniture"]}
check("ковёр передвинут", fs["h_rug"]["x"] == 13 and fs["h_rug"]["y"] == 3.5, fs["h_rug"])
check("кровать за стену не уехала", fs["h_bed"]["x"] == 13.5, fs["h_bed"])
check("перестановка — в событиях", any("переставила" in e["text"] for e in R.house_load()["events"]))

# --- память в чатах
b = R.house_brief("hespera")
check("в её чате: где кто и заметное из дома", "ДОМ" in b and "ты —" in b and "Аврора —" in b and "печенье" in b, b)
check("дом попал в подсказки всех троих", all("ДОМ (" in x for x in (R.build_system(R.ChatReq(messages=[])), R.hespera_system(), R.est_system())))
print(f"\nИТОГ: ок {ok_n}, нет {bad_n}")
sys.exit(1 if bad_n else 0)
