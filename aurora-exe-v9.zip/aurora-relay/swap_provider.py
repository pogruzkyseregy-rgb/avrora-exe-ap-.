#!/usr/bin/env python3
"""
Меняет местами основного и запасного провайдера в /opt/aurora-relay/relay.env.
Ключи нигде не печатаются. Перед изменением делается копия файла.
Повторный запуск возвращает всё как было.

Запуск с телефона:  unzip -p "$Z" aurora-relay/swap_provider.py | ssh root@СЕРВЕР "python3 -"
"""
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request

ENV = os.environ.get("AURORA_ENV", "/opt/aurora-relay/relay.env")
DROP = {"UPSTREAM_URL", "UPSTREAM_KEY", "MODEL", "FALLBACK_URL", "FALLBACK_KEY", "FALLBACK_MODEL"}


def key_of(line: str):
    s = line.strip()
    if not s or s.startswith("#") or "=" not in s:
        return None
    return s.split("=", 1)[0].strip()


def main() -> None:
    if not os.path.exists(ENV):
        sys.exit("Нет файла " + ENV)
    lines = open(ENV, encoding="utf-8").read().splitlines()

    vals = {}
    for line in lines:
        k = key_of(line)
        if k:
            vals[k] = line.strip().split("=", 1)[1].strip()   # при повторах берётся последняя строка, как у systemd

    missing = [k for k in ("UPSTREAM_URL", "UPSTREAM_KEY", "MODEL", "FALLBACK_URL", "FALLBACK_KEY") if not vals.get(k)]
    if missing:
        sys.exit("Менять местами нечего: в relay.env нет " + ", ".join(missing) +
                 ". Файл не тронут. Сначала запиши ключ запасного скрытым вводом.")

    main_set = (vals["UPSTREAM_URL"], vals["UPSTREAM_KEY"], vals["MODEL"])
    back_set = (vals["FALLBACK_URL"], vals["FALLBACK_KEY"], vals.get("FALLBACK_MODEL") or vals["MODEL"])

    backup = ENV + ".bak-" + time.strftime("%Y%m%d-%H%M%S")
    shutil.copy2(ENV, backup)

    kept = [l for l in lines if key_of(l) not in DROP]
    kept += [
        f"UPSTREAM_URL={back_set[0]}", f"UPSTREAM_KEY={back_set[1]}", f"MODEL={back_set[2]}",
        f"FALLBACK_URL={main_set[0]}", f"FALLBACK_KEY={main_set[1]}", f"FALLBACK_MODEL={main_set[2]}",
    ]
    tmp = ENV + ".new"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(kept) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, ENV)

    host = lambda u: urllib.parse.urlparse(u).netloc
    print("Копия прежнего файла:", backup)
    print(f"Основной теперь: {host(back_set[0])}, модель {back_set[2]}")
    print(f"Запасной теперь: {host(main_set[0])}, модель {main_set[2]}")
    if vals.get("MEMORY_MODEL"):
        print(f"Внимание: отдельно задан MEMORY_MODEL={vals['MEMORY_MODEL']}, он должен существовать у нового основного провайдера.")

    if os.environ.get("AURORA_NO_RESTART") == "1":
        return
    try:
        subprocess.run(["systemctl", "restart", "aurora-relay"], check=True)
    except Exception as e:
        sys.exit("Файл изменён, но перезапуск не удался (" + type(e).__name__ + "). Выполни: systemctl restart aurora-relay")
    time.sleep(3)
    try:
        h = json.load(urllib.request.urlopen("http://127.0.0.1:8765/health", timeout=10))
        print("Сервис после перезапуска:", json.dumps(h, ensure_ascii=False))
    except Exception as e:
        print("Сервис не ответил на /health (" + type(e).__name__ + "). Посмотри: systemctl status aurora-relay")


main()
