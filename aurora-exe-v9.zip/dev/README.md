# Проверки без телефона (для разработки)

- `tests/test_exe.py` — сервер: инструменты, защита адресов, рука на настоящем bash, цикл вызовов (нужны заглушки из `tests/stubs`, запуск: `python3 -I test_exe.py`).
- `tests/test_probes.py` — режимы `exe` и `tools` в probes.py на готовых ответах.
- `kotlin/LogicTest.kt` — чистая логика (маркеры, время «напишу», правила назначений), собирается вместе с `Markers.kt` и `ExeLogic.kt`.
- `kotlin/StoreTest.kt` + `kotlin/stubs` — хранилище, применение маркеров и права в списке ограничений на заглушках Android; с теми же заглушками проверяется типизация ViewModel, Initiative, Diary и AuroraApi. Экраны Compose таким образом не проверяются: их проверяет только сборка в GitHub Actions.
Компилятор Kotlin лежит в `lib` установленного Gradle (`kotlin-compiler-embeddable`), запуск через `org.jetbrains.kotlin.cli.jvm.K2JVMCompiler`.
