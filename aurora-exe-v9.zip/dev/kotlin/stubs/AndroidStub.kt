package android.content

import java.io.File

interface SharedPreferences {
    fun getString(k: String, d: String?): String?
    fun getInt(k: String, d: Int): Int
    fun getLong(k: String, d: Long): Long
    fun getBoolean(k: String, d: Boolean): Boolean
    fun edit(): Editor
    interface Editor {
        fun putString(k: String, v: String?): Editor
        fun putInt(k: String, v: Int): Editor
        fun putLong(k: String, v: Long): Editor
        fun putBoolean(k: String, v: Boolean): Editor
        fun apply()
    }
}

class MemPrefs : SharedPreferences {
    val m = HashMap<String, Any?>()
    override fun getString(k: String, d: String?) = m[k] as? String ?: d
    override fun getInt(k: String, d: Int) = m[k] as? Int ?: d
    override fun getLong(k: String, d: Long) = m[k] as? Long ?: d
    override fun getBoolean(k: String, d: Boolean) = m[k] as? Boolean ?: d
    override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
        override fun putString(k: String, v: String?) = also { m[k] = v }
        override fun putInt(k: String, v: Int) = also { m[k] = v }
        override fun putLong(k: String, v: Long) = also { m[k] = v }
        override fun putBoolean(k: String, v: Boolean) = also { m[k] = v }
        override fun apply() {}
    }
}

open class Context(val filesDir: File) {
    val prefs = HashMap<String, MemPrefs>()
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences = prefs.getOrPut(name) { MemPrefs() }
    val applicationContext: Context get() = this
    @Suppress("UNCHECKED_CAST")
    fun <T> getSystemService(c: Class<T>): T = android.app.NotificationManager() as T
    fun checkSelfPermission(p: String): Int = 0
    companion object { const val MODE_PRIVATE = 0 }
}
