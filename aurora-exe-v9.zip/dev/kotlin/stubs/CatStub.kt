package ru.avrora.exe

data class CatalogItem(val id: String, val desc: String, val builtIn: Boolean, val model: Any, val aspect: Float)
