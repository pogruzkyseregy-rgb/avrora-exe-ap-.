package androidx.core.app

import android.app.PendingIntent
import android.content.Context

class Notification
class NotificationCompat {
    class BigTextStyle { fun bigText(t: CharSequence) = this }
    class Builder(c: Context, ch: String) {
        fun setSmallIcon(i: Int) = this
        fun setContentTitle(t: CharSequence) = this
        fun setContentText(t: CharSequence) = this
        fun setStyle(s: BigTextStyle) = this
        fun setContentIntent(p: PendingIntent) = this
        fun setAutoCancel(b: Boolean) = this
        fun build() = Notification()
    }
}
class NotificationManagerCompat {
    fun notify(id: Int, n: Notification) {}
    fun cancel(id: Int) {}
    companion object { fun from(c: Context) = NotificationManagerCompat() }
}
