package ru.avrora.exe
class R { object drawable { const val ic_notif = 1 } }
class MainActivity
