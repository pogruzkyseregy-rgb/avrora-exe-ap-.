package ru.avrora.exe

import android.content.Context

enum class InitiativeOutcome { SENT, SILENT, NOT_NOW, NO_CHAT, NO_TOKEN, FAILED }

object InitiativeEngine {
    var next = InitiativeOutcome.FAILED
    val calls = ArrayList<String>()
    suspend fun tickSelf(ctx: Context, planId: String): InitiativeOutcome { calls.add(planId); return next }
}
