package org.json

class JSONException(m: String) : Exception(m)

class JSONObject() {
    private val m = LinkedHashMap<String, Any?>()
    constructor(s: String) : this() { val p = P(s); val v = p.value(); if (v !is JSONObject) throw JSONException("not object"); v.m.forEach { (k, x) -> m[k] = x } }
    fun put(k: String, v: Any?): JSONObject { m[k] = v; return this }
    fun has(k: String) = m.containsKey(k)
    fun getString(k: String): String = (m[k] ?: throw JSONException("no $k")).toString()
    fun optString(k: String, d: String = ""): String = m[k]?.let { if (it is String) it else it.toString() } ?: d
    fun optLong(k: String, d: Long = 0L): Long = (m[k] as? Number)?.toLong() ?: d
    fun optInt(k: String, d: Int = 0): Int = (m[k] as? Number)?.toInt() ?: d
    fun optDouble(k: String, d: Double = Double.NaN): Double = (m[k] as? Number)?.toDouble() ?: d
    fun optBoolean(k: String, d: Boolean = false): Boolean = (m[k] as? Boolean) ?: d
    fun optJSONArray(k: String): JSONArray? = m[k] as? JSONArray
    fun getJSONArray(k: String): JSONArray = m[k] as? JSONArray ?: throw JSONException("no array $k")
    fun getJSONObject(k: String): JSONObject = m[k] as? JSONObject ?: throw JSONException("no object $k")
    fun optJSONObject(k: String): JSONObject? = m[k] as? JSONObject
    override fun toString(): String = m.entries.joinToString(",", "{", "}") { "\"${esc(it.key)}\":${enc(it.value)}" }
}

class JSONArray() {
    private val l = ArrayList<Any?>()
    constructor(s: String) : this() { val v = P(s).value(); if (v !is JSONArray) throw JSONException("not array"); v.l.forEach { l.add(it) } }
    constructor(c: Collection<*>) : this() { l.addAll(c) }
    fun put(v: Any?): JSONArray { l.add(v); return this }
    fun length() = l.size
    fun getJSONObject(i: Int): JSONObject = l[i] as? JSONObject ?: throw JSONException("not object")
    fun getString(i: Int): String = l[i].toString()
    override fun toString(): String = l.joinToString(",", "[", "]") { enc(it) }
}

internal fun esc(s: String): String = buildString {
    for (c in s) when (c) { '"' -> append("\\\""); '\\' -> append("\\\\"); '\n' -> append("\\n"); '\r' -> append("\\r"); '\t' -> append("\\t"); else -> append(c) }
}
internal fun enc(v: Any?): String = when (v) { null -> "null"; is String -> "\"" + esc(v) + "\""; is Number, is Boolean -> v.toString(); else -> v.toString() }

private class P(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws()
        return when (s[i]) {
            '{' -> { i++; val o = JSONObject(); ws(); if (s[i] == '}') { i++; return o }
                while (true) { ws(); val k = str(); ws(); i++; o.put(k, value()); ws(); if (s[i++] == '}') break }; o }
            '[' -> { i++; val a = JSONArray(); ws(); if (s[i] == ']') { i++; return a }
                while (true) { a.put(value()); ws(); if (s[i++] == ']') break }; a }
            '"' -> str()
            't' -> { i += 4; true }
            'f' -> { i += 5; false }
            'n' -> { i += 4; null }
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "-+.eE")) i++
                val t = s.substring(st, i); if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else t.toLong() }
        }
    }
    fun str(): String {
        i++ ; val b = StringBuilder()
        while (s[i] != '"') { if (s[i] == '\\') { i++; when (s[i]) { 'n' -> b.append('\n'); 'r' -> b.append('\r'); 't' -> b.append('\t'); 'u' -> { b.append(s.substring(i + 1, i + 5).toInt(16).toChar()); i += 4 }; else -> b.append(s[i]) } } else b.append(s[i]); i++ }
        i++; return b.toString()
    }
}
