package ru.avrora.exe

import android.net.Uri
import java.io.File

class Library(ctx: android.content.Context) {
    val sentDir = File("/tmp")
    fun builtIn(): Pair<List<CatalogItem>, List<CatalogItem>> = Pair(emptyList(), emptyList())
    fun user(): Pair<List<CatalogItem>, List<CatalogItem>> = Pair(emptyList(), emptyList())
    fun addSticker(uri: Uri, desc: String, cutBlack: Boolean): CatalogItem = CatalogItem("a", desc, false, "", 1f)
    fun addPhoto(uri: Uri, desc: String): CatalogItem = CatalogItem("a", desc, false, "", 1f)
    fun saveSnap(uri: Uri): String = "x"
    fun remove(item: CatalogItem) {}
}
fun imageAspect(f: File): Float = 1f
fun encodeForModel(file: File, maxSide: Int = 896): String? = null
