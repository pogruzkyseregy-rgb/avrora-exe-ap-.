package okhttp3

import java.util.concurrent.TimeUnit

class MediaType { companion object { fun String.toMediaType(): MediaType = MediaType() } }
class RequestBody { companion object { fun String.toRequestBody(t: MediaType? = null): RequestBody = RequestBody() } }
class ResponseBody { fun string(): String = "" }
class Response : AutoCloseable {
    val code: Int = 200
    val isSuccessful: Boolean = true
    val body: ResponseBody? = null
    override fun close() {}
}
class Call { fun execute(): Response = Response() }
class Request private constructor() {
    class Builder {
        fun url(u: String) = this
        fun header(k: String, v: String) = this
        fun post(b: RequestBody) = this
        fun get() = this
        fun build() = Request()
    }
}
class OkHttpClient private constructor() {
    class Builder {
        fun connectTimeout(n: Long, u: TimeUnit) = this
        fun readTimeout(n: Long, u: TimeUnit) = this
        fun callTimeout(n: Long, u: TimeUnit) = this
        fun build() = OkHttpClient()
    }
    fun newCall(r: Request) = Call()
}
