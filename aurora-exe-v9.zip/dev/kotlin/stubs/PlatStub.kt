package android.app

import android.content.Context
import java.io.File

open class Application(dir: File = File("/tmp")) : Context(dir)
class NotificationChannel(val id: String, val name: CharSequence, val importance: Int)
class NotificationManager {
    companion object { const val IMPORTANCE_DEFAULT = 3 }
    fun getNotificationChannel(id: String): NotificationChannel? = null
    fun createNotificationChannel(c: NotificationChannel) {}
}
class PendingIntent {
    companion object {
        const val FLAG_IMMUTABLE = 1
        const val FLAG_UPDATE_CURRENT = 2
        fun getActivity(c: Context, r: Int, i: android.content.Intent, f: Int): PendingIntent = PendingIntent()
    }
}
