package android.content

class Intent(c: Context, k: Class<*>) { var flags = 0
    companion object { const val FLAG_ACTIVITY_NEW_TASK = 1; const val FLAG_ACTIVITY_CLEAR_TOP = 2 } }
