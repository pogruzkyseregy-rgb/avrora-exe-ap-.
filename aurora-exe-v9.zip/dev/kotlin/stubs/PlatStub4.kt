package android
class Manifest { object permission { const val POST_NOTIFICATIONS = "p" } }
