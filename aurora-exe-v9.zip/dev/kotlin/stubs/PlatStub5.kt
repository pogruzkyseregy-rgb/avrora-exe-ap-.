package android.os
class Build { object VERSION { const val SDK_INT = 34 } }
