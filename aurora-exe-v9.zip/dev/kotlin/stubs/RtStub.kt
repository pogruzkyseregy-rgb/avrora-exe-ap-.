package androidx.compose.runtime

import kotlin.reflect.KProperty

class MutableState<T>(var value: T)
operator fun <T> MutableState<T>.getValue(thisRef: Any?, p: KProperty<*>): T = value
operator fun <T> MutableState<T>.setValue(thisRef: Any?, p: KProperty<*>, v: T) { value = v }
fun <T> mutableStateOf(v: T) = MutableState(v)
class SnapshotStateList<T> : ArrayList<T>()
fun <T> mutableStateListOf(): SnapshotStateList<T> = SnapshotStateList()
