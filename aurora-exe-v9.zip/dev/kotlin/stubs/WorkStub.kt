package androidx.work

import android.content.Context
import java.util.concurrent.TimeUnit

enum class NetworkType { CONNECTED }
enum class ExistingWorkPolicy { REPLACE, KEEP }
enum class ExistingPeriodicWorkPolicy { KEEP, UPDATE }
class Data(val m: Map<String, Any?>) { fun getString(k: String) = m[k] as? String }
fun workDataOf(vararg p: Pair<String, Any?>) = Data(p.toMap())
class Constraints private constructor() {
    class Builder { fun setRequiredNetworkType(t: NetworkType) = this; fun build() = Constraints() }
}
class WorkerParameters(val data: Data = Data(emptyMap()), val attempt: Int = 0)
abstract class ListenableWorker(val ctx: Context, val params: WorkerParameters) {
    val inputData get() = params.data
    val runAttemptCount get() = params.attempt
    class Result private constructor(val kind: String) {
        companion object { fun success() = Result("success"); fun retry() = Result("retry") }
    }
}
abstract class CoroutineWorker(ctx: Context, params: WorkerParameters) : ListenableWorker(ctx, params) {
    val applicationContext: Context get() = ctx
    abstract suspend fun doWork(): Result
}
class OneTimeWorkRequest(val delayMs: Long, val data: Data)
class OneTimeWorkRequestBuilder0 {
    var delay = 0L; var data = Data(emptyMap())
    fun setInitialDelay(d: Long, u: TimeUnit) = also { delay = u.toMillis(d) }
    fun setInputData(d: Data) = also { data = d }
    fun setConstraints(c: Constraints) = this
    fun build() = OneTimeWorkRequest(delay, data)
}
inline fun <reified W : ListenableWorker> OneTimeWorkRequestBuilder() = OneTimeWorkRequestBuilder0()
class PeriodicWorkRequest
class PeriodicBuilder { fun setConstraints(c: Constraints) = this; fun build() = PeriodicWorkRequest() }
@Suppress("FunctionName")
inline fun <reified W : ListenableWorker> PeriodicWorkRequestBuilder(n: Long, u: TimeUnit) = PeriodicBuilder()
class WorkManager private constructor() {
    val enqueued = ArrayList<Triple<String, ExistingWorkPolicy, OneTimeWorkRequest>>()
    val cancelled = ArrayList<String>()
    fun enqueueUniqueWork(name: String, p: ExistingWorkPolicy, r: OneTimeWorkRequest) { enqueued.add(Triple(name, p, r)) }
    fun cancelUniqueWork(name: String) { cancelled.add(name) }
    fun enqueueUniquePeriodicWork(name: String, p: ExistingPeriodicWorkPolicy, r: PeriodicWorkRequest) {}
    companion object { val inst = WorkManager(); fun getInstance(ctx: Context) = inst }
}
