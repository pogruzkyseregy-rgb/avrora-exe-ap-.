class HTTPException(Exception):
    def __init__(self, status_code, detail=""):
        super().__init__(detail); self.status_code = status_code; self.detail = detail
def Header(default=""): return default
class FastAPI:
    def __init__(self): self.routes = {}
    def _reg(self, m, p):
        def d(f): self.routes[(m, p)] = f; return f
        return d
    def get(self, p): return self._reg("GET", p)
    def post(self, p): return self._reg("POST", p)
