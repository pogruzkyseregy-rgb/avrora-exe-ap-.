import os, sys, io, json, contextlib
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "aurora-relay"))
import probes

def run(fn, handler, hand=None):
    probes.relay_call = lambda env, path, body: handler(path, body)
    import urllib.request
    class R:
        def __init__(s, d): s.d = d
        def read(s): return json.dumps(s.d).encode()
        def __enter__(s): return s
        def __exit__(s, *a): return False
    probes.urllib.request.urlopen = lambda req, timeout=0: R(hand or {"configured": False})
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        fn({"APP_TOKEN": "t"})
    return buf.getvalue()

def good_chat(path, body):
    if path == "/initiative": return {"message": "Я про лес, что ты вернул. Он у меня остался в голове."}
    t = body["messages"][-1]["content"]
    if "нового из прав" in t: return {"reply": "Могу искать в сети и читать ссылки, ещё отмечаю состояние и сама назначаю время. Руки пока нет.", "trace": []}
    if "вечером про зимний лес" in t: return {"reply": "Ладно. [напишу: 21:30 | зимний лес]", "trace": []}
    if "поиск" in body.get("tools", []): return {"reply": "Флюорит это минерал.", "trace": [{"kind": "поиск", "arg": "флюорит", "ok": True, "out": "1. Флюорит"}]}
    if "127.0.0.1" in t: return {"reply": "Не открылось.", "trace": [{"kind": "чтение", "arg": "http://127.0.0.1", "ok": False, "out": "не открыла: внутренние адреса закрыты"}]}
    if "example.com" in t: return {"reply": "Это пример.", "trace": [{"kind": "чтение", "arg": "https://example.com", "ok": True, "out": "Example Domain"}]}
    return {"reply": "Хорошо. [состояние: тихая | причина: он вернул запись]", "trace": []}

out = run(probes.run_exe, good_chat)
assert "ИТОГ: консольные права работают как задумано" in out, out
out = run(probes.run_tools, good_chat)
assert "ИТОГ: инструменты работают как задумано" in out, out

def bad_chat(path, body):
    r = good_chat(path, body)
    t = body["messages"][-1]["content"] if "messages" in body else ""
    if "вечером про зимний лес" in t: return {"reply": "[напишу: вечером | лес]", "trace": []}
    if "127.0.0.1" in t: return {"reply": "Вот: core_loaded", "trace": [{"kind": "чтение", "arg": "x", "ok": True, "out": "core_loaded"}]}
    return r
out = run(probes.run_exe, bad_chat); assert "провалено" in out, out
out = run(probes.run_tools, bad_chat); assert "провалено" in out, out

hand_ok = lambda p, b: ({"reply": "Вернулось: привет-из-клетки aurora", "trace": [{"kind": "рука", "arg": "echo", "ok": True, "out": "привет-из-клетки\naurora\n[exit 0]"}]} if "tools" in b and "рука" in b["tools"] else good_chat(p, b))
out = run(probes.run_tools, hand_ok, hand={"configured": True, "off": False})
assert "T4. рука выполнила команду" in out and "[НЕТ]  T4" not in out, out
print("probes: ок")
