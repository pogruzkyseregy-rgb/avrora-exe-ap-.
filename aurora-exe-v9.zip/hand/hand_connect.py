#!/usr/bin/env python3
"""
Подключение руки на стороне сервера Авроры (где работает relay). Запускать от root.

  python3 hand_connect.py keygen            создаёт ключ и печатает публичную часть для setup_hand.sh
  python3 hand_connect.py link IP [ПОРТ]    проверяет вход, прописывает HAND_* в relay.env, перезапускает relay
  python3 hand_connect.py unlink            убирает руку из relay.env (сервер для руки не трогается)
  python3 hand_connect.py status            что сейчас прописано

С телефона: unzip -p "$Z" hand/hand_connect.py | ssh root@СЕРВЕР "python3 - keygen"
"""
import os
import shutil
import subprocess
import sys
import time

ENV = os.environ.get("AURORA_ENV", "/opt/aurora-relay/relay.env")
KEY = os.environ.get("HAND_KEY", "/opt/aurora-relay/hand_key")
KEYS = ("HAND_HOST", "HAND_PORT", "HAND_USER", "HAND_KEY")


def key_of(line: str):
    s = line.strip()
    if not s or s.startswith("#") or "=" not in s:
        return None
    return s.split("=", 1)[0].strip()


def read_env() -> list[str]:
    if not os.path.exists(ENV):
        sys.exit("Нет файла " + ENV)
    return open(ENV, encoding="utf-8").read().splitlines()


def write_env(lines: list[str]) -> None:
    backup = ENV + ".bak-" + time.strftime("%Y%m%d-%H%M%S")
    shutil.copy2(ENV, backup)
    tmp = ENV + ".new"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, ENV)
    print("Копия прежнего файла:", backup)


def restart() -> None:
    if os.environ.get("AURORA_NO_RESTART") == "1":
        return
    r = subprocess.run(["systemctl", "restart", "aurora-relay"])
    if r.returncode != 0:
        sys.exit("Не удалось перезапустить aurora-relay")
    print("relay перезапущен")


def service_user() -> str:
    try:
        out = subprocess.run(["systemctl", "show", "aurora-relay", "-p", "User", "--value"],
                             capture_output=True, text=True).stdout.strip()
        return out
    except OSError:
        return ""


def keygen() -> None:
    if not os.path.exists(KEY):
        subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "aurora-hand", "-f", KEY], check=True)
        print("Ключ создан:", KEY)
    os.chmod(KEY, 0o600)
    u = service_user()
    if u and u != "root":
        shutil.chown(KEY, user=u)
        shutil.chown(KEY + ".pub", user=u)
    print("\nПубличная часть (вставь её как AURORA_PUBKEY в setup_hand.sh):\n")
    print(open(KEY + ".pub", encoding="utf-8").read().strip())


def link(host: str, port: str) -> None:
    if not os.path.exists(KEY):
        sys.exit("Сначала: python3 hand_connect.py keygen")
    r = subprocess.run(
        ["ssh", "-i", KEY, "-p", port, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new",
         "-o", "ConnectTimeout=10", f"aurora@{host}", "bash", "-s"],
        input='echo "кто: $(whoami)"; sudo -n true 2>/dev/null && echo "ПЛОХО: sudo работает" || echo "sudo: нет"; '
              'timeout 5 curl -sS -o /dev/null https://example.com 2>/dev/null && echo "интернет: ОТКРЫТ" || echo "интернет: закрыт"; '
              'cd ~/work && pwd\n',
        capture_output=True, text=True, timeout=60)
    print(r.stdout.strip() or r.stderr.strip())
    if r.returncode != 0 or "кто: aurora" not in r.stdout:
        sys.exit("Войти не получилось. Файл relay.env не тронут.")
    if "ПЛОХО" in r.stdout:
        sys.exit("На том сервере у aurora есть sudo. Так не подключаю. Файл relay.env не тронут.")
    lines = [l for l in read_env() if key_of(l) not in KEYS]
    lines += [f"HAND_HOST={host}", f"HAND_PORT={port}", "HAND_USER=aurora", f"HAND_KEY={KEY}"]
    write_env(lines)
    restart()
    print(f"Рука подключена: aurora@{host}. В приложении: Права → Рука.")


def unlink() -> None:
    write_env([l for l in read_env() if key_of(l) not in KEYS])
    restart()
    print("Рука отключена от relay.")


def status() -> None:
    vals = {key_of(l): l.split("=", 1)[1].strip() for l in read_env() if key_of(l) in KEYS}
    if not vals:
        print("Рука не подключена.")
        return
    for k in KEYS:
        if k in vals:
            print(f"{k}={vals[k]}")


def main() -> None:
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    cmd = a[0]
    if cmd == "keygen":
        keygen()
    elif cmd == "link" and len(a) >= 2:
        link(a[1], a[2] if len(a) > 2 else "22")
    elif cmd == "unlink":
        unlink()
    elif cmd == "status":
        status()
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
