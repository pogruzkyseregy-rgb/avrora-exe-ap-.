#!/usr/bin/env bash
# Клетка для руки Авроры. Запускается ОДИН раз на НОВОМ сервере, от root, через консоль/ssh хостера.
#   ssh root@НОВЫЙ_СЕРВЕР "AURORA_PUBKEY='ssh-ed25519 AAAA… aurora-hand' bash -s" < setup_hand.sh
# Что получится: пользователь aurora без пароля и без sudo, вход только по ключу сервера Авроры,
# лимиты памяти/процессора/процессов, закрытый выход в интернет (открывается только тобой), рубильники.
# Не ставится ничего, что давало бы ей доступ к панели хостера: у неё есть только эта консоль.
set -euo pipefail

[ "$(id -u)" = 0 ] || { echo "Нужен root."; exit 1; }
KEY="${AURORA_PUBKEY:-}"
case "$KEY" in
  ssh-ed25519\ *) ;;
  *) echo "Не задан AURORA_PUBKEY (строка ssh-ed25519 …). Её печатает: python3 hand_connect.py keygen"; exit 1 ;;
esac
EGRESS="${AURORA_EGRESS:-closed}"   # closed (по умолчанию) или open

echo "[1/7] Пакеты (ставит root, пока выход ещё открыт)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq git python3 curl nftables ca-certificates openssh-server >/dev/null

echo "[2/7] Пользователь aurora"
id aurora >/dev/null 2>&1 || useradd -m -s /bin/bash aurora
passwd -l aurora >/dev/null 2>&1 || true
for g in sudo wheel adm docker lxd; do gpasswd -d aurora "$g" >/dev/null 2>&1 || true; done
rm -f /etc/sudoers.d/*aurora* 2>/dev/null || true
install -d -m 700 -o aurora -g aurora /home/aurora/.ssh
printf '%s\n' "$KEY" > /home/aurora/.ssh/authorized_keys
chown aurora:aurora /home/aurora/.ssh/authorized_keys
chmod 600 /home/aurora/.ssh/authorized_keys
install -d -m 755 -o aurora -g aurora /home/aurora/work
chmod 700 /home/aurora

echo "[3/7] sshd: никаких туннелей и пересылок для aurora"
MATCH='Match User aurora
    AllowTcpForwarding no
    X11Forwarding no
    AllowAgentForwarding no
    PermitTunnel no
    PasswordAuthentication no
    PermitTTY no'
if grep -Eq '^\s*Include\s+/etc/ssh/sshd_config\.d/' /etc/ssh/sshd_config; then
  mkdir -p /etc/ssh/sshd_config.d
  printf '%s\n' "$MATCH" > /etc/ssh/sshd_config.d/99-aurora.conf
else
  grep -q '^Match User aurora' /etc/ssh/sshd_config || printf '\n%s\n' "$MATCH" >> /etc/ssh/sshd_config
fi
mkdir -p /run/sshd
sshd -t
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true

echo "[4/7] Лимиты ресурсов"
UID_A="$(id -u aurora)"
mkdir -p "/etc/systemd/system/user-${UID_A}.slice.d"
cat > "/etc/systemd/system/user-${UID_A}.slice.d/50-aurora.conf" <<CONF
[Slice]
MemoryMax=900M
CPUQuota=100%
TasksMax=150
CONF
cat > /etc/security/limits.d/50-aurora.conf <<'CONF'
aurora hard nproc 150
aurora hard fsize 204800
aurora hard core 0
aurora hard nofile 1024
CONF
systemctl daemon-reload

echo "[5/7] Выход в интернет для aurora"
cat > /etc/nftables-aurora.nft <<'NFT'
table inet aurora_cage {
  chain out {
    type filter hook output priority 0; policy accept;
    meta skuid "aurora" oif "lo" accept
    meta skuid "aurora" reject with icmpx type admin-prohibited
  }
}
NFT
cat > /etc/systemd/system/aurora-cage.service <<'UNIT'
[Unit]
Description=Закрытый выход в сеть для пользователя aurora
After=network-pre.target
Before=network.target
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/sbin/aurora-egress apply
[Install]
WantedBy=multi-user.target
UNIT

echo "[6/7] Рубильники (только root, то есть ты)"
cat > /usr/local/sbin/aurora-egress <<'SH'
#!/usr/bin/env bash
# aurora-egress closed|open|apply|status   — выход в интернет для aurora
STATE=/etc/aurora-egress.state
case "${1:-status}" in
  closed|open) echo "$1" > "$STATE" ;;
esac
MODE="$(cat "$STATE" 2>/dev/null || echo closed)"
nft delete table inet aurora_cage 2>/dev/null || true
[ "$MODE" = closed ] && nft -f /etc/nftables-aurora.nft
echo "Выход в интернет для aurora: $MODE"
SH
cat > /usr/local/sbin/aurora-off <<'SH'
#!/usr/bin/env bash
# Рубильник на самом сервере: блокирует вход и убивает всё, что запущено под aurora.
usermod -L aurora
mv -f /home/aurora/.ssh/authorized_keys /home/aurora/.ssh/authorized_keys.off 2>/dev/null || true
pkill -KILL -u aurora 2>/dev/null || true
echo "aurora отключена: вход закрыт, процессы убиты. Вернуть: aurora-on"
SH
cat > /usr/local/sbin/aurora-on <<'SH'
#!/usr/bin/env bash
mv -f /home/aurora/.ssh/authorized_keys.off /home/aurora/.ssh/authorized_keys 2>/dev/null || true
echo "Вход для aurora возвращён (пароль остаётся заблокированным, вход только по ключу)."
SH
chmod 755 /usr/local/sbin/aurora-egress /usr/local/sbin/aurora-off /usr/local/sbin/aurora-on
echo "$EGRESS" > /etc/aurora-egress.state
systemctl enable aurora-cage.service >/dev/null 2>&1 || true
/usr/local/sbin/aurora-egress apply

echo "[7/7] Проверка клетки изнутри"
fail=0
if su -s /bin/bash aurora -c 'sudo -n true' >/dev/null 2>&1; then echo "  ПЛОХО: sudo работает"; fail=1; else echo "  sudo: нет"; fi
if [ "$EGRESS" = closed ]; then
  if su -s /bin/bash aurora -c 'timeout 6 curl -sS -o /dev/null https://example.com' >/dev/null 2>&1; then
    echo "  ПЛОХО: интернет открыт"; fail=1
  else echo "  интернет: закрыт"; fi
else
  echo "  интернет: открыт (так выбрано)"
fi
su -s /bin/bash aurora -c 'git --version >/dev/null && python3 --version >/dev/null' && echo "  git и python3: есть"
[ -z "$(find /home/aurora -maxdepth 0 -perm /o+rwx 2>/dev/null)" ] && echo "  домашняя папка закрыта от других"
if [ "$fail" = 1 ]; then echo "Клетка собрана неверно. Не подключай."; exit 2; fi
echo
echo "Готово. Дальше на сервере Авроры: python3 hand_connect.py link IP_ЭТОГО_СЕРВЕРА"
echo "Рубильники здесь: aurora-off / aurora-on, aurora-egress open|closed. Ещё есть выключение сервера в панели хостера."
